#!/usr/bin/env bash
# QQ 官方机器人 · 一键部署 / 运维脚本
# 用法：bash deploy.sh [start|stop|restart|status|logs]
# 可通过 MODE=docker|systemd|venv 指定部署方式，默认自动检测。
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="$APP_DIR/venv"
SERVICE_NAME="qqbot"
UNIT="/etc/systemd/system/${SERVICE_NAME}.service"
LOG_DIR="$APP_DIR/logs"
DATA_DIR="$APP_DIR/data"
PID_FILE="$APP_DIR/data/qqbot.pid"

log()  { printf '\033[32m[qqbot]\033[0m %s\n' "$*"; }
warn() { printf '\033[33m[warn]\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[31m[error]\033[0m %s\n' "$*" >&2; exit 1; }

detect_mode() {
  if [ -n "${MODE:-}" ]; then echo "$MODE"; return; fi
  if command -v docker >/dev/null 2>&1 && \
     { docker compose version >/dev/null 2>&1 || command -v docker-compose >/dev/null 2>&1; }; then
    echo docker; return
  fi
  if command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ]; then
    echo systemd; return
  fi
  echo venv
}

docker_cmd() {
  if docker compose version >/dev/null 2>&1; then
    docker compose "$@"
  else
    docker-compose "$@"
  fi
}

ensure_env() {
  mkdir -p "$LOG_DIR" "$DATA_DIR"
  if [ ! -f "$APP_DIR/.env" ]; then
    cp "$APP_DIR/.env.example" "$APP_DIR/.env"
    chmod 600 "$APP_DIR/.env"
    warn "已生成 .env：$APP_DIR/.env"
    warn "请先填写 QQ_APP_ID / QQ_APP_SECRET（可选 LLM_API_KEY）再执行 bash deploy.sh start"
    return 1
  fi
  chmod 600 "$APP_DIR/.env"
  grep -Eq '^QQ_APP_ID=.+' "$APP_DIR/.env" || die ".env 里 QQ_APP_ID 为空"
  grep -Eq '^QQ_APP_SECRET=.+' "$APP_DIR/.env" || die ".env 里 QQ_APP_SECRET 为空"
  return 0
}

setup_venv() {
  local py
  py="$(command -v python3.11 || command -v python3 || true)"
  [ -n "$py" ] || die "未找到 python3，请先安装 Python 3.10+"
  if [ ! -x "$VENV/bin/python" ]; then
    log "创建虚拟环境：$VENV （$py）"
    "$py" -m venv "$VENV" || die "创建虚拟环境失败；Ubuntu 可执行：apt install -y python3-venv"
  fi
  log "安装依赖…"
  "$VENV/bin/pip" install -q --upgrade pip
  "$VENV/bin/pip" install -q -r "$APP_DIR/requirements.txt"
}

write_unit() {
  log "写入 systemd 服务：$UNIT"
  cat > "$UNIT" <<EOF
[Unit]
Description=QQ Official Bot (WebSocket)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$APP_DIR
Environment=PYTHONUNBUFFERED=1
Environment=TZ=Asia/Shanghai
Environment=QQ_DB_PATH=$DATA_DIR/bot.db
Environment=LOG_DIR=$LOG_DIR
ExecStart=$VENV/bin/python -m bot.main
Restart=always
RestartSec=10
StandardOutput=append:$LOG_DIR/systemd.out.log
StandardError=append:$LOG_DIR/systemd.err.log

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable "$SERVICE_NAME" >/dev/null 2>&1 || true
}

cmd_start() {
  ensure_env || return 1
  local mode
  mode="$(detect_mode)"
  log "部署方式：$mode ｜ 项目目录：$APP_DIR"
  case "$mode" in
    docker)
      (cd "$APP_DIR" && docker_cmd up -d --build)
      ;;
    systemd)
      setup_venv
      write_unit
      systemctl restart "$SERVICE_NAME"
      ;;
    venv)
      setup_venv
      if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
        warn "已在运行（PID $(cat "$PID_FILE")）"; return 0
      fi
      (cd "$APP_DIR" && \
        QQ_DB_PATH="$DATA_DIR/bot.db" LOG_DIR="$LOG_DIR" PYTHONUNBUFFERED=1 \
        nohup "$VENV/bin/python" -m bot.main >> "$LOG_DIR/venv.out.log" 2>&1 & \
        echo $! > "$PID_FILE")
      log "已后台启动，PID $(cat "$PID_FILE")"
      ;;
    *) die "未知 MODE：$mode" ;;
  esac
  log "启动完成。查看日志：bash deploy.sh logs"
}

cmd_stop() {
  local mode
  mode="$(detect_mode)"
  case "$mode" in
    docker)  (cd "$APP_DIR" && docker_cmd down) ;;
    systemd) systemctl stop "$SERVICE_NAME" ;;
    venv)
      if [ -f "$PID_FILE" ]; then kill "$(cat "$PID_FILE")" 2>/dev/null || true; rm -f "$PID_FILE"; fi
      ;;
  esac
  log "已停止"
}

cmd_status() {
  local mode
  mode="$(detect_mode)"
  case "$mode" in
    docker)  (cd "$APP_DIR" && docker_cmd ps) ;;
    systemd) systemctl status "$SERVICE_NAME" --no-pager || true ;;
    venv)
      if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
        log "运行中，PID $(cat "$PID_FILE")"
      else
        warn "未运行"
      fi
      ;;
  esac
  if [ -f "$APP_DIR/.env" ]; then
    if grep -q 'HEALTH_ENABLED=false' "$APP_DIR/.env"; then
      warn "健康检查已关闭"
    else
      local port
      port="$(grep -E '^HEALTH_PORT=' "$APP_DIR/.env" | cut -d= -f2 | tr -d '\r' || true)"
      port="${port:-8080}"
      log "健康检查：curl http://127.0.0.1:${port}/healthz"
    fi
  fi
}

cmd_logs() {
  local mode
  mode="$(detect_mode)"
  case "$mode" in
    docker)  (cd "$APP_DIR" && docker_cmd logs -f --tail=100) ;;
    systemd) journalctl -u "$SERVICE_NAME" -f -n 100 ;;
    venv)    tail -n 100 -f "$LOG_DIR/bot.log" 2>/dev/null || tail -n 100 -f "$LOG_DIR/venv.out.log" ;;
  esac
}

case "${1:-start}" in
  start)   cmd_start ;;
  stop)    cmd_stop ;;
  restart) cmd_stop; cmd_start ;;
  status)  cmd_status ;;
  logs)    cmd_logs ;;
  *) echo "用法：bash deploy.sh [start|stop|restart|status|logs]"; exit 1 ;;
esac
