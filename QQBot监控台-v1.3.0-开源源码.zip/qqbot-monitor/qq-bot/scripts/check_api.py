"""连通性自检：验证凭据、access_token 与 WSS 接入点（不建立长连接）。

用法：venv/bin/python scripts/check_api.py
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import aiohttp  # noqa: E402

from bot.config import Config  # noqa: E402
from bot.api import QQApi  # noqa: E402


async def main() -> int:
    cfg = Config.from_env()
    cfg.validate()
    print(f"AppID : {cfg.app_id}")
    print(f"API   : {cfg.api_base}")
    print(f"沙箱  : {'是' if 'sgroup' in cfg.api_base else '否'}")
    print(f"LLM   : {'已配置 ' + cfg.llm_model if cfg.llm_api_key else '未配置（AI 聊天降级）'}")
    async with aiohttp.ClientSession() as session:
        api = QQApi(cfg, session)
        try:
            token = await api.get_token()
            print(f"[OK]   access_token 获取成功：{token[:12]}…")
        except Exception as exc:  # noqa: BLE001
            print(f"[FAIL] 鉴权失败：{exc}")
            print("       检查 .env 里的 QQ_APP_ID / QQ_APP_SECRET，以及是否误用了已弃用的 Token。")
            return 1
        try:
            url = await api.gateway_url()
            print(f"[OK]   WSS 接入点：{url}")
        except Exception as exc:  # noqa: BLE001
            print(f"[FAIL] 网关地址获取失败：{exc}")
            return 1
    print("[OK]   凭据与网络连通性正常。若仍收不到消息，请检查开放平台「事件订阅」与机器人是否已进群。")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
