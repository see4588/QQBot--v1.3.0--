"""命令行推送一条通知（可用于服务器 crontab 或外部系统集成）。

用法：
  python scripts/notify.py --scene group --target <group_openid> --text "内容"
  python scripts/notify.py --scene c2c   --target <user_openid>  --text "内容"

主动消息若被平台拒绝，会自动写入待发队列，机器人下次收到消息时带出。
"""
from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import aiohttp  # noqa: E402

from bot.config import Config  # noqa: E402
from bot.api import QQApi  # noqa: E402
from bot.store import Store  # noqa: E402


async def run(args: argparse.Namespace) -> int:
    cfg = Config.from_env()
    cfg.validate()
    async with aiohttp.ClientSession() as session:
        api = QQApi(cfg, session)
        result = await api.send(
            scene=args.scene, target_id=args.target, content=args.text
        )
        if result.ok:
            print("已送达")
            return 0
        Store(cfg.db_path).add_pending(args.scene, args.target, args.text)
        print(
            f"主动消息未送达（code={result.code} {result.message}），"
            "已写入待发队列，将在下次交互时带出。"
        )
        return 1


def main() -> int:
    p = argparse.ArgumentParser(description="向 QQ 群/单聊推送一条通知")
    p.add_argument("--scene", choices=["group", "c2c"], required=True)
    p.add_argument("--target", required=True, help="group_openid 或 user_openid")
    p.add_argument("--text", required=True, help="通知内容")
    args = p.parse_args()
    try:
        return asyncio.run(run(args))
    except RuntimeError as exc:
        print(f"[配置错误] {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
