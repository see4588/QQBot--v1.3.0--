"""本地模拟自测：不连接 QQ 服务器，验证事件分发与各功能路径。

运行：python3.11 scripts/mock_test.py
"""
from __future__ import annotations

import asyncio
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

os.environ["QQ_APP_ID"] = "mock"
os.environ["QQ_APP_SECRET"] = "mock"
os.environ["LLM_API_KEY"] = ""
os.environ["HEALTH_ENABLED"] = "false"

from bot.config import Config  # noqa: E402
from bot.api import SendResult  # noqa: E402
from bot.store import Store  # noqa: E402
from bot.llm import LLMClient  # noqa: E402
from bot.dispatcher import Bot  # noqa: E402
from bot.events import (  # noqa: E402
    C2C_MESSAGE_CREATE,
    GROUP_AT_MESSAGE_CREATE,
    GROUP_ADD_ROBOT,
)

PASS, FAIL = 0, 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  PASS  {name}")
    else:
        FAIL += 1
        print(f"  FAIL  {name} {detail}")


class MockApi:
    """模拟官方 API：主动消息默认失败，用于测试待发队列降级。"""

    def __init__(self, active_fail: bool = True):
        self.sent: list[dict] = []
        self.active_fail = active_fail

    async def send(
        self, *, scene, target_id, content, msg_id=None, event_id=None,
        msg_seq=1, msg_type=0,
    ) -> SendResult:
        passive = bool(msg_id or event_id)
        if not passive and self.active_fail:
            return SendResult(False, code=40034105, message="主动消息发送失败，无权限")
        self.sent.append(
            {"scene": scene, "target": target_id, "content": content,
             "passive": passive, "seq": msg_seq}
        )
        return SendResult(True, data={"id": "MOCKMSG"})

    async def mute_member(self, *_args, **_kwargs):
        return 200, {}

    async def recall(self, *_args, **_kwargs):
        return 200, {}

    async def gateway_url(self):
        return "wss://mock.invalid"

    def invalidate_token(self):
        pass


class MockLLM(LLMClient):
    def __init__(self):
        pass

    @property
    def enabled(self) -> bool:
        return True

    async def chat(self, messages):
        return "模拟回复：" + messages[-1]["content"]


def c2c_event(text: str, msg_id: str, role: str = "member") -> tuple:
    return (
        C2C_MESSAGE_CREATE,
        {
            "id": msg_id,
            "author": {"user_openid": "USER_OPENID_0001", "username": "测试用户",
                       "member_role": role},
            "content": text,
            "timestamp": "2026-11-13T15:00:00+08:00",
        },
        "EVT-" + msg_id,
        1,
    )


def group_event(text: str, msg_id: str, mentions=None) -> tuple:
    return (
        GROUP_AT_MESSAGE_CREATE,
        {
            "id": msg_id,
            "author": {"member_openid": "MEMBER_OPENID_0001", "username": "群友",
                       "member_role": "admin"},
            "content": text,
            "group_openid": "GROUP_OPENID_0001",
            "mentions": mentions or [],
            "timestamp": "2026-11-13T15:00:00+08:00",
        },
        "EVT-" + msg_id,
        2,
    )


async def main_async() -> None:
    tmp = tempfile.mkdtemp(prefix="qqbot-test-")
    cfg = Config.from_env()
    cfg.db_path = str(Path(tmp) / "test.db")
    cfg.keyword_rules = {"签到": "签到成功！"}
    cfg.admin_openids = {"USER_OPENID_0001", "MEMBER_OPENID_0001"}

    api = MockApi(active_fail=True)
    store = Store(cfg.db_path)
    bot = Bot(cfg, api, store, MockLLM())
    bot.start_services()

    print("\n== 1. 指令与 AI 聊天 ==")
    await bot.handle_event(*c2c_event("/帮助", "M1"))
    check("/帮助 返回菜单", "指令" in api.sent[-1]["content"])

    await bot.handle_event(*c2c_event("你好呀", "M2"))
    check("普通消息交给 AI", api.sent[-1]["content"].startswith("模拟回复"))

    await bot.handle_event(*c2c_event("我要签到", "M3"))
    check("关键词命中", api.sent[-1]["content"] == "签到成功！")

    print("\n== 2. 消息去重 ==")
    before = len(api.sent)
    await bot.handle_event(*c2c_event("重复消息", "M4"))
    await bot.handle_event(*c2c_event("重复消息", "M4"))
    check("同一 msg_id 只处理一次", len(api.sent) == before + 1)

    print("\n== 3. 定时提醒 ==")
    await bot.handle_event(*c2c_event("/提醒 添加 0 9 * * * :: 早上好记得打卡", "M5"))
    check("添加定时提醒", "已添加" in api.sent[-1]["content"]
          and len(store.list_reminders()) == 1)
    await bot.handle_event(*c2c_event("/提醒 列表", "M6"))
    check("列出定时提醒", "早上好记得打卡" in api.sent[-1]["content"])
    await bot.handle_event(*c2c_event("/提醒 添加 这不是cron :: 内容", "M7"))
    check("非法 cron 被拒绝", "不合法" in api.sent[-1]["content"])

    print("\n== 4. 主动消息降级与待发队列 ==")
    ok, info = await bot.notify.push("c2c", "USER_OPENID_0001", "服务器续费提醒")
    check("主动消息失败转待发", (not ok) and store.count_pending() == 1, info)
    await bot.handle_event(*c2c_event("在吗", "M8"))
    check("下次交互带出积压通知", "服务器续费提醒" in api.sent[-1]["content"])
    check("队列已清空", store.count_pending() == 0)

    print("\n== 5. 群管理与入群欢迎 ==")
    await bot.handle_event(*group_event("/禁言 60 @某人", "M9",
                                        mentions=[{"member_openid": "TARGET_MEMBER_0001"}]))
    check("禁言指令调用成功", "已禁言" in api.sent[-1]["content"])
    await bot.handle_event(*group_event("/撤回", "M10"))
    check("撤回指令调用成功", "已撤回" in api.sent[-1]["content"])
    await bot.handle_event(
        GROUP_ADD_ROBOT,
        {"group_openid": "GROUP_OPENID_0001", "op_member_openid": "X", "timestamp": 1},
        "EVT-ADD",
        3,
    )
    check("入群发送欢迎语", any("大家好" in s["content"] for s in api.sent))

    print("\n== 6. 其他 ==")
    await bot.handle_event(*c2c_event("/状态", "M11"))
    check("状态指令", "运行中" in api.sent[-1]["content"])
    await bot.handle_event(*c2c_event("/不存在的指令", "M12"))
    check("未知指令有提示", "不认识" in api.sent[-1]["content"])

    bot.stop_services()
    store.close()
    print(f"\n结果：{PASS} 通过，{FAIL} 失败")


def main() -> int:
    asyncio.run(main_async())
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
