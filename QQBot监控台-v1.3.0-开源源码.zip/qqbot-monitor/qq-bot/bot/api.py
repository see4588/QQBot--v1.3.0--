"""QQ 开放平台 HTTP API 封装：鉴权、发送消息、群管理。

参考：https://bot.q.qq.com/wiki/develop/api-v2/
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any

import aiohttp

log = logging.getLogger("qqbot.api")

# 主动消息被平台拒绝时的典型错误码（用于日志诊断）
ACTIVE_BLOCKED_CODES = frozenset(
    {
        304064,    # 订阅消息未授权
        40034100,  # 主动消息超过频控
        40034101,  # 机器人非群成员
        40034105,  # 主动消息发送失败，无权限
        40034128,  # 被动回复时间或次数超限
        40054002,  # 机器人被禁言
        40054003,  # 机器人不是群成员
        40054016,  # 机器人已下线
    }
)


@dataclass
class SendResult:
    ok: bool
    code: int | None = None
    message: str = ""
    data: dict = field(default_factory=dict)

    @property
    def active_blocked(self) -> bool:
        return (not self.ok) and (
            self.code in ACTIVE_BLOCKED_CODES or self.code is None
        )


class QQApiError(RuntimeError):
    """鉴权或网关接口异常。"""


class QQApi:
    def __init__(self, cfg, session: aiohttp.ClientSession):
        self.cfg = cfg
        self.session = session
        self._token = ""
        self._expires_at = 0.0
        self._lock = asyncio.Lock()

    # ---------- 鉴权 ----------
    def invalidate_token(self) -> None:
        """遇到 4004（无效 token）时强制下次重新获取。"""
        self._token = ""
        self._expires_at = 0.0

    async def get_token(self) -> str:
        """获取并缓存 access_token，提前 5 分钟刷新，并发只刷新一次。"""
        if self._token and time.time() < self._expires_at - 300:
            return self._token
        async with self._lock:
            if self._token and time.time() < self._expires_at - 300:
                return self._token
            payload = {
                "appId": self.cfg.app_id,
                "clientSecret": self.cfg.app_secret,
            }
            async with self.session.post(
                self.cfg.token_url,
                json=payload,
                timeout=aiohttp.ClientTimeout(total=15),
            ) as r:
                raw = await r.text()
                try:
                    data = json.loads(raw) if raw else {}
                except ValueError:
                    raise QQApiError(f"鉴权接口返回非 JSON：{raw[:200]}")
            token = data.get("access_token") if isinstance(data, dict) else None
            if not token:
                # 该接口错误时仍返回 HTTP 200，错误在 body 里
                raise QQApiError(
                    "获取 access_token 失败：code=%s message=%s"
                    % (data.get("code"), data.get("message"))
                )
            self._token = str(token)
            try:
                expires = int(data.get("expires_in") or 7200)
            except (TypeError, ValueError):
                expires = 7200
            self._expires_at = time.time() + expires
            log.info("access_token 获取成功，有效期 %ss", expires)
            return self._token

    # ---------- 通用请求 ----------
    async def request(
        self, method: str, path: str, payload: dict | None = None
    ) -> tuple[int, dict]:
        token = await self.get_token()
        headers = {
            "Authorization": f"QQBot {token}",
            "Content-Type": "application/json",
        }
        url = self.cfg.api_base + path
        kwargs: dict[str, Any] = {
            "headers": headers,
            "timeout": aiohttp.ClientTimeout(total=20),
        }
        if payload is not None:
            kwargs["json"] = payload
        async with self.session.request(method, url, **kwargs) as r:
            raw = await r.text()
            try:
                data = json.loads(raw) if raw else {}
            except ValueError:
                data = {"raw": raw[:500]}
            if not isinstance(data, dict):
                data = {"raw": str(data)[:500]}
            return r.status, data

    async def gateway_url(self) -> str:
        status, data = await self.request("GET", "/gateway")
        url = data.get("url")
        if not url or status >= 400:
            raise QQApiError(f"获取 WSS 接入点失败：status={status} body={data}")
        return str(url)

    # ---------- 发消息 ----------
    async def send(
        self,
        *,
        scene: str,
        target_id: str,
        content: str,
        msg_id: str | None = None,
        event_id: str | None = None,
        msg_seq: int = 1,
        msg_type: int = 0,
    ) -> SendResult:
        """发送消息。

        msg_id / event_id 存在时为被动回复（带 msg_seq 去重）；
        都不传则为主动消息（受平台权限与频控限制）。
        """
        if scene == "group":
            path = f"/v2/groups/{target_id}/messages"
        else:
            path = f"/v2/users/{target_id}/messages"

        body: dict[str, Any] = {"msg_type": msg_type, "content": content}
        if msg_id:
            body["msg_id"] = msg_id
            body["msg_seq"] = msg_seq
        elif event_id:
            body["event_id"] = event_id
            body["msg_seq"] = msg_seq

        try:
            status, data = await self.request("POST", path, body)
        except Exception as exc:  # noqa: BLE001 - 网络层统一转成结果对象
            log.warning("发消息请求异常：%s", exc)
            return SendResult(False, message=str(exc))

        body_code = data.get("code") if isinstance(data, dict) else None
        if 200 <= status < 300 and not body_code:
            return SendResult(True, data=data)

        try:
            code = int(body_code) if body_code is not None else status
        except (TypeError, ValueError):
            code = status
        message = str(
            (data.get("message") or data.get("msg") or data.get("raw") or "")
            if isinstance(data, dict)
            else ""
        )
        if not (msg_id or event_id):
            log.info(
                "主动消息未送达（code=%s %s），将转入待发队列", code, message
            )
        else:
            log.warning("被动回复失败（code=%s %s）", code, message)
        return SendResult(False, code=code, message=message, data=data)

    # ---------- 富媒体：上传 + 发语音 ----------
    async def upload_media(
        self,
        *,
        scene: str,
        target_id: str,
        file_type: int,
        url: str | None = None,
        file_data: str | None = None,
        file_name: str | None = None,
    ) -> str | None:
        """上传媒体获取 file_info。

        file_type: 1 图片 / 2 视频 / 3 语音 / 4 文件
        两种上传方式二选一（QQ 官方接口）：
          · file_data: base64 后的二进制内容 + file_name，直传，≤5MB，无需公网地址（首选）
          · url: 公网可访问地址，平台回拉转存（直传失败时的兜底）
        返回 file_info 字符串；失败返回 None。
        """
        if scene == "group":
            path = f"/v2/groups/{target_id}/files"
        else:
            path = f"/v2/users/{target_id}/files"
        body: dict[str, Any] = {"file_type": file_type, "srv_send_msg": False}
        if file_data:
            body["file_data"] = file_data
            body["file_name"] = file_name or "voice.mp3"
        elif url:
            body["url"] = url
        else:
            log.warning("富媒体上传缺少 file_data 或 url，已跳过")
            return None
        status, data = await self.request("POST", path, body)
        if 200 <= status < 300 and isinstance(data, dict):
            file_info = data.get("file_info")
            if file_info:
                return str(file_info)
        log.warning("富媒体上传失败 status=%s %s", status, data)
        return None

    async def send_media(
        self,
        *,
        scene: str,
        target_id: str,
        file_info: str,
        msg_id: str | None = None,
        event_id: str | None = None,
        msg_seq: int = 1,
    ) -> SendResult:
        """发送富媒体消息（msg_type=7，media 携带 file_info）。用于发语音/图片。"""
        if scene == "group":
            path = f"/v2/groups/{target_id}/messages"
        else:
            path = f"/v2/users/{target_id}/messages"
        body: dict[str, Any] = {"msg_type": 7, "media": {"file_info": file_info}}
        if msg_id:
            body["msg_id"] = msg_id
            body["msg_seq"] = msg_seq
        elif event_id:
            body["event_id"] = event_id
            body["msg_seq"] = msg_seq
        try:
            status, data = await self.request("POST", path, body)
        except Exception as exc:  # noqa: BLE001
            log.warning("富媒体消息请求异常：%s", exc)
            return SendResult(False, message=str(exc))
        body_code = data.get("code") if isinstance(data, dict) else None
        if 200 <= status < 300 and not body_code:
            return SendResult(True, data=data)
        try:
            code = int(body_code) if body_code is not None else status
        except (TypeError, ValueError):
            code = status
        message = str(
            (data.get("message") or data.get("msg") or data.get("raw") or "")
            if isinstance(data, dict)
            else ""
        )
        log.warning("富媒体消息发送失败（code=%s %s）", code, message)
        return SendResult(False, code=code, message=message, data=data)

    # ---------- 群管理 ----------
    async def mute_member(
        self,
        group_openid: str,
        member_openid: str,
        seconds: int,
        op: str = "add",
    ) -> tuple[int, dict]:
        """设置/解除群成员禁言。需要机器人是群管理员，最长 30 天。"""
        if op == "del":
            item: dict[str, Any] = {
                "op": "del",
                "member_openid": member_openid,
                "mute_expire_at": "",
            }
        else:
            seconds = max(1, min(int(seconds), 30 * 86400))
            expire = datetime.now(timezone(timedelta(hours=8))) + timedelta(
                seconds=seconds
            )
            item = {
                "op": op,
                "member_openid": member_openid,
                "mute_expire_at": expire.isoformat(timespec="seconds"),
            }
        return await self.request(
            "POST",
            f"/v2/groups/{group_openid}/restrict_chat_setting",
            {"members": [item]},
        )

    async def recall(
        self, group_openid: str, message_id: str
    ) -> tuple[int, dict]:
        """撤回群消息（发送超过 2 分钟不可撤回）。"""
        return await self.request(
            "DELETE", f"/v2/groups/{group_openid}/messages/{message_id}"
        )

    # ---------- 资源下载（图片等附件） ----------
    async def fetch_attachment(self, url: str) -> bytes | None:
        """下载消息附件（图片等）。QQ 资源地址通常需带机器人 token。"""
        try:
            token = await self.get_token()
        except Exception as exc:  # noqa: BLE001
            log.warning("获取 token 失败，无法下载附件：%s", exc)
            token = ""
        headers = {"Authorization": f"QQBot {token}"} if token else {}
        try:
            async with self.session.get(
                url, headers=headers, timeout=aiohttp.ClientTimeout(total=20)
            ) as r:
                if r.status >= 400:
                    # 部分资源地址无需鉴权，重试一次不带 token
                    if token:
                        async with self.session.get(
                            url, timeout=aiohttp.ClientTimeout(total=20)
                        ) as r2:
                            return await r2.read() if r2.status < 400 else None
                    return None
                return await r.read()
        except Exception as exc:  # noqa: BLE001
            log.warning("下载附件异常：%s", exc)
            return None
