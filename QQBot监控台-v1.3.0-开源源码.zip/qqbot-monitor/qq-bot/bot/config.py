"""配置加载：环境变量优先，其次读取项目根目录下的 .env 文件。"""
from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
_LOG = logging.getLogger("qqbot.config")


def _parse_dotenv_value(raw: str) -> str:
    """解析 .env 的值：兼容裸值、JSON 双引号（含转义）与单引号包裹。"""
    raw = raw.strip()
    if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] == '"':
        try:
            val = json.loads(raw)
            if isinstance(val, str):
                return val
        except (ValueError, TypeError):
            pass
        return raw[1:-1]
    if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] == "'":
        return raw[1:-1].replace("\\'", "'")
    return raw


def load_dotenv(path: Path | None = None) -> None:
    """把 .env 中的键写入 os.environ，不覆盖已经存在的环境变量。"""
    p = path or BASE_DIR / ".env"
    if not p.exists():
        return
    for raw in p.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = _parse_dotenv_value(value)
        if key and key not in os.environ:
            os.environ[key] = value


def _bool(key: str, default: bool = False) -> bool:
    v = os.getenv(key)
    if v is None:
        return default
    return v.strip().lower() in {"1", "true", "yes", "on"}


def _int(key: str, default: int) -> int:
    try:
        return int(os.getenv(key, "").strip() or default)
    except (ValueError, TypeError):
        return default


def _float(key: str, default: float) -> float:
    try:
        return float(os.getenv(key, "").strip() or default)
    except (ValueError, TypeError):
        return default


@dataclass
class Config:
    # QQ 开放平台
    app_id: str = ""
    app_secret: str = ""
    api_base: str = "https://api.bot.qq.com"
    token_url: str = "https://bots.qq.com/app/getAppAccessToken"
    intents: int = 1 << 25
    shard: tuple[int, int] = (0, 1)

    # 大模型（OpenAI 兼容接口）
    llm_api_key: str = ""
    llm_base_url: str = "https://api.openai.com/v1"
    llm_model: str = "gpt-4o-mini"
    llm_system_prompt: str = (
        "你是 QQ 上的智能助手。回答要简洁、友好、口语化，"
        "不要使用 Markdown 标题与代码块，用纯文本回复，单次不超过 300 字。"
    )
    llm_timeout: int = 60
    history_limit: int = 12
    # 人格配置文件；每次对话前重读，实现「保存即生效、无需重启」
    persona_path: str = ""

    # 行为
    bot_name: str = "小助手"
    admin_openids: set[str] = field(default_factory=set)
    welcome_text: str = ""

    # 识图 / 多模态
    vision_enabled: bool = True
    vision_use_ocr: bool = True
    vision_base_url: str = ""      # OpenAI 兼容多模态接口，留空则用本地 OCR
    vision_api_key: str = ""
    vision_model: str = ""

    # 默认城市（/天气 不写城市时使用）
    weather_default_city: str = "北京"

    # 语音合成（BreezeBlue TTS）
    tts_enabled: bool = False
    tts_api_key: str = ""
    tts_base_url: str = "https://api.breeze.blue/v1"
    tts_voice_id: str = ""                    # 必填：BreezeBlue 控制台 Voice 页复制（形如 voc_xxx）
    tts_model: str = "breeze-tts-2"
    tts_instructions: str = ""                 # 可选，引导音色/语气（如人设声线）
    # 指令遵循强度：官方推荐 4.0，越高越听 instructions 的话，过高可能音色失真
    tts_guidance_scale: float = 4.0
    tts_timeout: int = 30
    # 临时文件服务：把合成的 mp3 暴露为公网 URL，供 QQ 富媒体接口回拉上传
    # 仅「URL 回拉兜底」模式才需要：填服务器公网 IP/域名，并放行端口 + 安全组
    tts_serve_host: str = "127.0.0.1"
    tts_serve_port: int = 18080
    tts_max_chars: int = 300                   # 超过此长度的文字不转语音（避免刷屏/超时长）

    keyword_rules: dict[str, str] = field(default_factory=dict)
    max_reply_chars: int = 1500
    max_pending_flush: int = 3

    # 运行
    db_path: str = ""
    log_dir: str = ""
    log_level: str = "INFO"
    health_enabled: bool = True
    health_host: str = "127.0.0.1"
    health_port: int = 8080

    @classmethod
    def from_env(cls) -> "Config":
        load_dotenv()
        sandbox = _bool("QQ_SANDBOX", False)
        api_base = os.getenv("QQ_API_BASE", "").strip() or (
            "https://api.sgroup.qq.com" if sandbox else "https://api.bot.qq.com"
        )
        admins = {
            x.strip()
            for x in os.getenv("BOT_ADMIN_OPENIDS", "").split(",")
            if x.strip()
        }
        rules: dict[str, str] = {}
        raw_rules = os.getenv("KEYWORD_RULES", "").strip()
        if raw_rules:
            try:
                parsed = json.loads(raw_rules)
                if isinstance(parsed, dict):
                    rules = {str(k): str(v) for k, v in parsed.items()}
            except (ValueError, TypeError):
                _LOG.warning("KEYWORD_RULES 不是合法 JSON 对象，已忽略")

        default_prompt = cls.llm_system_prompt
        default_welcome = (
            "大家好，我是{name}～ @我或私聊我都能聊天，发 /帮助 查看全部功能。"
        )
        return cls(
            app_id=os.getenv("QQ_APP_ID", "").strip(),
            app_secret=os.getenv("QQ_APP_SECRET", "").strip(),
            api_base=api_base.rstrip("/"),
            token_url=os.getenv(
                "QQ_TOKEN_URL", "https://bots.qq.com/app/getAppAccessToken"
            ).strip(),
            intents=_int("QQ_INTENTS", 1 << 25),
            llm_api_key=os.getenv("LLM_API_KEY", "").strip(),
            llm_base_url=os.getenv("LLM_BASE_URL", "https://api.openai.com/v1")
            .strip()
            .rstrip("/"),
            llm_model=os.getenv("LLM_MODEL", "gpt-4o-mini").strip(),
            llm_system_prompt=(
                os.getenv("LLM_SYSTEM_PROMPT", "").strip() or default_prompt
            ),
            llm_timeout=_int("LLM_TIMEOUT", 60),
            history_limit=_int("HISTORY_LIMIT", 12),
            persona_path=os.getenv("PERSONA_PATH", "").strip()
            or str(BASE_DIR / "persona.json"),
            bot_name=os.getenv("BOT_NAME", "小助手").strip() or "小助手",
            admin_openids=admins,
            welcome_text=os.getenv("WELCOME_TEXT", "").strip() or default_welcome,
            vision_enabled=_bool("VISION_ENABLED", True),
            vision_use_ocr=_bool("VISION_USE_OCR", True),
            vision_base_url=os.getenv("VISION_BASE_URL", "").strip().rstrip("/"),
            vision_api_key=os.getenv("VISION_API_KEY", "").strip(),
            vision_model=os.getenv("VISION_MODEL", "").strip(),
            weather_default_city=os.getenv("WEATHER_DEFAULT_CITY", "北京").strip()
            or "北京",
            tts_enabled=_bool("TTS_ENABLED", False),
            tts_api_key=os.getenv("TTS_API_KEY", "").strip(),
            tts_base_url=os.getenv("TTS_BASE_URL", "https://api.breeze.blue/v1")
            .strip().rstrip("/"),
            tts_voice_id=os.getenv("TTS_VOICE_ID", "").strip(),
            tts_model=os.getenv("TTS_MODEL", "breeze-tts-2").strip(),
            tts_instructions=os.getenv("TTS_INSTRUCTIONS", "").strip(),
            tts_guidance_scale=_float("TTS_GUIDANCE_SCALE", 4.0),
            tts_timeout=_int("TTS_TIMEOUT", 30),
            tts_serve_host=os.getenv("TTS_SERVE_HOST", "127.0.0.1").strip(),
            tts_serve_port=_int("TTS_SERVE_PORT", 18080),
            tts_max_chars=_int("TTS_MAX_CHARS", 300),
            keyword_rules=rules,
            max_reply_chars=_int("MAX_REPLY_CHARS", 1500),
            max_pending_flush=_int("MAX_PENDING_FLUSH", 3),
            db_path=os.getenv("QQ_DB_PATH", "").strip()
            or str(BASE_DIR / "data" / "bot.db"),
            log_dir=os.getenv("LOG_DIR", "").strip() or str(BASE_DIR / "logs"),
            log_level=os.getenv("LOG_LEVEL", "INFO").strip().upper(),
            health_enabled=_bool("HEALTH_ENABLED", True),
            health_host=os.getenv("HEALTH_HOST", "127.0.0.1").strip(),
            health_port=_int("HEALTH_PORT", 8080),
        )

    def validate(self) -> None:
        missing = [
            k
            for k, v in (("QQ_APP_ID", self.app_id), ("QQ_APP_SECRET", self.app_secret))
            if not v
        ]
        if missing:
            raise RuntimeError(
                "缺少必要配置：" + ", ".join(missing)
                + "。请把 .env.example 复制为 .env 并填写后再启动。"
            )
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        Path(self.log_dir).mkdir(parents=True, exist_ok=True)
