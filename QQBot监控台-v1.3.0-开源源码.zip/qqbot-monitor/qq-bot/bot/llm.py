"""OpenAI 兼容大模型客户端（不依赖官方 SDK，直接用 aiohttp）。"""
from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any

import aiohttp

log = logging.getLogger("qqbot.llm")


class LLMClient:
    def __init__(self, cfg, session: aiohttp.ClientSession):
        self.cfg = cfg
        self.session = session

    @property
    def enabled(self) -> bool:
        return bool(self.cfg.llm_api_key)

    def _system_prompt(self) -> str:
        """优先读取 persona.json，每次对话重读 —— 手机上保存人设后立即生效。

        文件不存在、内容为空或解析失败时，回退到 .env 的 LLM_SYSTEM_PROMPT。
        """
        raw_path = getattr(self.cfg, "persona_path", "") or ""
        if not raw_path:
            return self.cfg.llm_system_prompt
        path = Path(raw_path)
        if not path.is_file():
            return self.cfg.llm_system_prompt
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            prompt = str(data.get("prompt", "")).strip() if isinstance(data, dict) else ""
            return prompt or self.cfg.llm_system_prompt
        except (OSError, ValueError, TypeError) as exc:
            log.warning("读取人格配置失败，回退默认人设：%s", exc)
            return self.cfg.llm_system_prompt

    async def chat(self, messages: list[dict[str, str]]) -> str | None:
        """返回模型回复；未配置或调用失败返回 None，由上层降级。"""
        if not self.enabled:
            return None

        payload = {
            "model": self.cfg.llm_model,
            "messages": [
                {"role": "system", "content": self._system_prompt()},
                *messages,
            ],
            "temperature": 0.7,
        }
        headers = {
            "Authorization": f"Bearer {self.cfg.llm_api_key}",
            "Content-Type": "application/json",
        }
        url = self.cfg.llm_base_url.rstrip("/") + "/chat/completions"

        for attempt in range(2):
            try:
                async with self.session.post(
                    url,
                    json=payload,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=self.cfg.llm_timeout),
                ) as r:
                    raw = await r.text()
                    try:
                        data: Any = json.loads(raw) if raw else {}
                    except ValueError:
                        data = {}
                    if r.status >= 400 or (isinstance(data, dict) and data.get("error")):
                        log.warning(
                            "大模型接口异常（status=%s）：%s",
                            r.status,
                            str(data.get("error") or raw)[:200],
                        )
                        return None
                    choices = data.get("choices") if isinstance(data, dict) else None
                    if not choices:
                        log.warning("大模型返回无 choices：%s", raw[:200])
                        return None
                    content = (
                        choices[0].get("message", {}).get("content", "")
                        if isinstance(choices[0], dict)
                        else ""
                    )
                    return str(content).strip() or None
            except asyncio.TimeoutError:
                log.warning("大模型调用超时（第 %s 次）", attempt + 1)
            except Exception as exc:  # noqa: BLE001
                log.warning("大模型调用异常（第 %s 次）：%s", attempt + 1, exc)
        return None

    # ---------- 多模态（识图） ----------
    @property
    def vision_enabled(self) -> bool:
        cfg = self.cfg
        return bool(getattr(cfg, "vision_base_url", "") and cfg.vision_api_key)

    async def vision(
        self, prompt: str, image_bytes: bytes, image_type: str = "image/jpeg"
    ) -> str | None:
        """调用 OpenAI 兼容的多模态接口识别图片。未配置视觉端点返回 None。"""
        cfg = self.cfg
        if not self.vision_enabled:
            return None
        data_uri = (
            f"data:{image_type};base64,"
            + __import__("base64").b64encode(image_bytes).decode("ascii")
        )
        payload = {
            "model": cfg.vision_model or "gpt-4o-mini",
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": data_uri}},
                    ],
                }
            ],
            "temperature": 0.4,
        }
        headers = {
            "Authorization": f"Bearer {cfg.vision_api_key}",
            "Content-Type": "application/json",
        }
        url = cfg.vision_base_url.rstrip("/") + "/chat/completions"
        try:
            async with self.session.post(
                url,
                json=payload,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=cfg.llm_timeout),
            ) as r:
                raw = await r.text()
                try:
                    data = json.loads(raw) if raw else {}
                except ValueError:
                    data = {}
                if r.status >= 400 or data.get("error"):
                    log.warning(
                        "视觉接口异常（status=%s）：%s",
                        r.status, str(data.get("error") or raw)[:200],
                    )
                    return None
                choices = data.get("choices") or []
                if not choices:
                    return None
                return str(
                    choices[0].get("message", {}).get("content", "")
                ).strip() or None
        except Exception as exc:  # noqa: BLE001
            log.warning("视觉接口调用失败：%s", exc)
            return None
