"""BreezeBlue TTS 客户端：文本转语音，返回 mp3 二进制。

接口：POST {base_url}/text-to-speech/{voice_id}
认证：请求头 xi-api-key
返回：音频二进制（mp3）
文档：https://breezeblue.ai/docs/api-reference/text-to-speech/convert
"""
from __future__ import annotations

import logging

import aiohttp

log = logging.getLogger("qqbot.tts")


class TTSClient:
    def __init__(self, session: aiohttp.ClientSession, cfg) -> None:
        self.session = session
        self.cfg = cfg

    @property
    def enabled(self) -> bool:
        # 三项齐全才启用：总开关 + API Key + 真实音色 ID。
        # 音色 ID 不能用示例值（会返回 404 Voice not found），留空即静默关闭。
        return (
            self.cfg.tts_enabled
            and bool(self.cfg.tts_api_key)
            and bool((self.cfg.tts_voice_id or "").strip())
        )

    async def synth(self, text: str) -> bytes | None:
        """把文字合成成语音，成功返回 mp3 字节，失败返回 None。"""
        if not self.enabled:
            return None
        text = (text or "").strip()
        if not text:
            return None
        if len(text) > self.cfg.tts_max_chars:
            log.info("文字过长（%d>%d），跳过语音合成", len(text), self.cfg.tts_max_chars)
            return None

        url = f"{self.cfg.tts_base_url.rstrip('/')}/text-to-speech/{self.cfg.tts_voice_id}"
        headers = {
            "xi-api-key": self.cfg.tts_api_key,
            "Content-Type": "application/json",
        }
        body: dict = {
            "text": text,
            "model_id": self.cfg.tts_model,
        }
        if self.cfg.tts_instructions:
            body["instructions"] = self.cfg.tts_instructions
            # 官方推荐 guidance_scale=4.0 强化指令遵循。不配引导时完全不传，
            # 保持纯音色合成的默认行为不变。
            body["voice_settings"] = {
                "guidance_scale": self.cfg.tts_guidance_scale
            }

        try:
            async with self.session.post(
                url,
                headers=headers,
                json=body,
                timeout=aiohttp.ClientTimeout(total=self.cfg.tts_timeout),
            ) as r:
                if r.status >= 400:
                    raw = await r.text()
                    log.warning("TTS 请求失败 status=%s %s", r.status, raw[:200])
                    return None
                return await r.read()
        except Exception as exc:  # noqa: BLE001
            log.warning("TTS 请求异常：%s", exc)
            return None
