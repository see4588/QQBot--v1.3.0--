"""事件名、intents 位与入站消息数据结构。"""
from __future__ import annotations

from dataclasses import dataclass, field

# 事件订阅 intents（官方定义，按需位或运算）
INTENT_GUILDS = 1 << 0
INTENT_GUILD_MEMBERS = 1 << 1
INTENT_GUILD_MESSAGES = 1 << 9
INTENT_GUILD_MESSAGE_REACTIONS = 1 << 10
INTENT_DIRECT_MESSAGE = 1 << 12
INTENT_GROUP_AND_C2C = 1 << 25
INTENT_INTERACTION = 1 << 26
INTENT_MESSAGE_AUDIT = 1 << 27
INTENT_FORUMS = 1 << 28

# 事件名
READY = "READY"
RESUMED = "RESUMED"
C2C_MESSAGE_CREATE = "C2C_MESSAGE_CREATE"
GROUP_AT_MESSAGE_CREATE = "GROUP_AT_MESSAGE_CREATE"
AT_MESSAGE_CREATE = "AT_MESSAGE_CREATE"
GROUP_ADD_ROBOT = "GROUP_ADD_ROBOT"
GROUP_DEL_ROBOT = "GROUP_DEL_ROBOT"
FRIEND_ADD = "FRIEND_ADD"
FRIEND_DEL = "FRIEND_DEL"
GROUP_MSG_RECEIVE = "GROUP_MSG_RECEIVE"
GROUP_MSG_REJECT = "GROUP_MSG_REJECT"
C2C_MSG_RECEIVE = "C2C_MSG_RECEIVE"
C2C_MSG_REJECT = "C2C_MSG_REJECT"

MESSAGE_EVENTS = frozenset({C2C_MESSAGE_CREATE, GROUP_AT_MESSAGE_CREATE})


@dataclass
class IncomingMessage:
    event_type: str
    msg_id: str
    event_id: str
    seq: int
    content: str
    scene: str                 # "c2c" | "group"
    target_id: str             # user_openid | group_openid
    sender_openid: str
    sender_name: str
    role: str                  # member | admin | owner
    timestamp: str
    mentions: list[str] = field(default_factory=list)
    attachments: list[dict] = field(default_factory=list)

    @property
    def is_group(self) -> bool:
        return self.scene == "group"

    @property
    def images(self) -> list[dict]:
        """消息里的图片附件（仅取 content_type 以 image/ 开头的）。"""
        return [
            a for a in (self.attachments or [])
            if isinstance(a, dict)
            and str(a.get("content_type") or "").lower().startswith("image/")
            and a.get("url")
        ]

    @property
    def short_sender(self) -> str:
        return self.sender_name or (self.sender_openid[-6:] if self.sender_openid else "某人")

    @classmethod
    def from_payload(
        cls, t: str, d: dict, event_id: str, seq: int
    ) -> "IncomingMessage":
        author = d.get("author") or {}
        if t == C2C_MESSAGE_CREATE:
            scene = "c2c"
            target = author.get("user_openid") or author.get("id") or ""
            sender = target
        else:
            scene = "group"
            target = d.get("group_openid") or ""
            sender = author.get("member_openid") or author.get("id") or ""
        mentions = [
            (u.get("member_openid") or u.get("id") or "")
            for u in (d.get("mentions") or [])
        ]
        return cls(
            event_type=t,
            msg_id=d.get("id") or "",
            event_id=event_id,
            seq=seq,
            content=(d.get("content") or "").strip(),
            scene=scene,
            target_id=target,
            sender_openid=sender,
            sender_name=author.get("username") or "",
            role=author.get("member_role") or "member",
            timestamp=d.get("timestamp") or "",
            mentions=[m for m in mentions if m],
            attachments=_extract_attachments(d.get("attachments")),
        )


def _extract_attachments(raw) -> list[dict]:
    """QQ v2 消息的 attachments 字段，可能包含图片/视频/文件等。"""
    if not isinstance(raw, list):
        return []
    out: list[dict] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        url = item.get("url") or item.get("attachment_url") or ""
        ctype = item.get("content_type") or item.get("type") or ""
        if url:
            out.append({"url": str(url), "content_type": str(ctype)})
    return out
