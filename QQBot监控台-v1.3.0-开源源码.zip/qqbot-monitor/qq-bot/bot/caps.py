"""功能开关：capabilities.json 热读，手机控制台保存即生效、无需重启。"""
from __future__ import annotations

import json
import logging

from .config import BASE_DIR

log = logging.getLogger("qqbot.caps")

CAPS_FILE = BASE_DIR / "capabilities.json"
_cache: dict = {"raw": None, "data": {}}


def load_caps() -> dict:
    """按文件内容比对（同一秒连续写入时 mtime 精度不够）。"""
    try:
        raw = CAPS_FILE.read_text(encoding="utf-8")
    except OSError:
        _cache["raw"] = None
        _cache["data"] = {}
        return {}
    if raw == _cache["raw"] and _cache["data"] is not None:
        return dict(_cache["data"])
    try:
        data = json.loads(raw)
        if not isinstance(data, dict):
            data = {}
    except (ValueError, TypeError):
        log.warning("capabilities.json 解析失败，按全部开启处理")
        data = {}
    _cache["raw"] = raw
    _cache["data"] = data
    return dict(data)


def enabled(key: str, default: bool = True) -> bool:
    return bool(load_caps().get(key, default))
