"""入口：装配配置、API、存储、插件、网关与健康检查端点。"""
from __future__ import annotations

import asyncio
import logging
import signal
import sys
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path

import aiohttp
from aiohttp import web

from .config import Config
from .api import QQApi
from .store import Store
from .llm import LLMClient
from .dispatcher import Bot
from .gateway import Gateway


def setup_logging(cfg: Config) -> None:
    level = getattr(logging, cfg.log_level, logging.INFO)
    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        "%Y-%m-%d %H:%M:%S",
    )
    root = logging.getLogger()
    root.setLevel(level)
    for handler in list(root.handlers):
        root.removeHandler(handler)
    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(fmt)
    root.addHandler(stream)
    file_handler = RotatingFileHandler(
        Path(cfg.log_dir) / "bot.log",
        maxBytes=5 * 1024 * 1024,
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setFormatter(fmt)
    root.addHandler(file_handler)
    logging.getLogger("apscheduler").setLevel(logging.WARNING)
    logging.getLogger("aiohttp").setLevel(logging.WARNING)


async def start_health(bot: Bot, cfg: Config):
    app = web.Application()

    async def healthz(_request):
        return web.json_response(
            {
                "status": "ok",
                "bot": cfg.bot_name,
                "uptime": int(time.time() - bot.started_at),
                "ai": bot.llm.enabled,
                "reminders": len(bot.store.list_reminders()),
                "pending": bot.store.count_pending(),
            }
        )

    app.router.add_get("/healthz", healthz)
    runner = web.AppRunner(app, access_log=None)
    await runner.setup()
    site = web.TCPSite(runner, cfg.health_host, cfg.health_port)
    await site.start()
    return runner


async def start_tts_serve(bot: Bot, cfg: Config):
    """临时文件服务：把合成的 mp3 暴露为公网 URL，供 QQ 富媒体接口回拉上传。

    仅通过一次性 token 访问，文件被取走即删除；不暴露目录列表。
    """
    app = web.Application()

    async def serve(request: web.Request):
        token = request.match_info["token"]
        name = request.match_info["name"]
        path = bot.pop_tts_file(token, name)
        if path is None or not path.exists():
            raise web.HTTPNotFound()
        try:
            data = path.read_bytes()
        finally:
            try:
                path.unlink()
            except OSError:
                pass
        return web.Response(body=data, content_type="audio/mpeg")

    app.router.add_get("/tts/{token}/{name}", serve)
    runner = web.AppRunner(app, access_log=None)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", cfg.tts_serve_port)
    await site.start()
    return runner


async def amain() -> None:
    cfg = Config.from_env()
    cfg.validate()
    setup_logging(cfg)
    log = logging.getLogger("qqbot")
    log.info("启动 %s（接入环境 %s）", cfg.bot_name, cfg.api_base)

    timeout = aiohttp.ClientTimeout(total=None, sock_connect=15)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        api = QQApi(cfg, session)
        store = Store(cfg.db_path)
        llm = LLMClient(cfg, session)
        bot = Bot(cfg, api, store, llm)
        bot.start_services()

        runner = None
        if cfg.health_enabled:
            try:
                runner = await start_health(bot, cfg)
                log.info(
                    "健康检查：http://%s:%s/healthz",
                    cfg.health_host,
                    cfg.health_port,
                )
            except OSError as exc:
                log.warning(
                    "健康检查端口启动失败（可设 HEALTH_ENABLED=false）：%s", exc
                )

        gateway = Gateway(cfg, api, session, bot.handle_event)

        # 默认走二进制直传，不监听额外端口；只有显式配了公网回传地址
        # （URL 兜底模式）才启动临时文件服务。
        tts_runner = None
        if cfg.tts_serve_host not in ("127.0.0.1", "localhost", "", "0.0.0.0"):
            try:
                tts_runner = await start_tts_serve(bot, cfg)
                log.info("TTS URL 兜底服务：http://0.0.0.0:%s", cfg.tts_serve_port)
            except OSError as exc:
                log.warning(
                    "TTS URL 兜底服务启动失败（不影响二进制直传，需放行该端口）：%s",
                    exc,
                )

        stop = asyncio.Event()
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, stop.set)
            except (NotImplementedError, RuntimeError):
                pass

        gw_task = asyncio.create_task(gateway.run())
        stop_task = asyncio.create_task(stop.wait())
        done, _ = await asyncio.wait(
            {gw_task, stop_task}, return_when=asyncio.FIRST_COMPLETED
        )
        if gw_task in done and not stop_task.done():
            log.error("网关连接已终止，机器人退出（请查看上方错误日志）")

        log.info("正在关闭…")
        gateway.stop()
        gw_task.cancel()
        try:
            await gw_task
        except asyncio.CancelledError:
            pass
        stop_task.cancel()
        bot.stop_services()
        if runner is not None:
            await runner.cleanup()
        if tts_runner is not None:
            await tts_runner.cleanup()
        store.cleanup()
        store.close()


def main() -> None:
    try:
        asyncio.run(amain())
    except KeyboardInterrupt:
        pass
    except RuntimeError as exc:
        print(f"[配置错误] {exc}", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
