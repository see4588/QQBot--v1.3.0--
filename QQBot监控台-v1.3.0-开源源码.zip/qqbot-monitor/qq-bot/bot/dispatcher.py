"""事件分发与机器人主体：装配插件、统一回复、待发通知合并。"""
from __future__ import annotations

import asyncio
import base64
import logging
import secrets
import time
from pathlib import Path

from .config import Config
from .caps import load_caps
from .api import QQApi, SendResult
from .store import Store
from .llm import LLMClient
from .tts import TTSClient
from .events import (
    IncomingMessage,
    MESSAGE_EVENTS,
    GROUP_ADD_ROBOT,
    FRIEND_ADD,
    GROUP_MSG_RECEIVE,
    GROUP_MSG_REJECT,
    C2C_MSG_RECEIVE,
    C2C_MSG_REJECT,
)
from .plugins.commands import CommandPlugin
from .plugins.chat import ChatPlugin
from .plugins.group import GroupService
from .plugins.notify import NotifyService
from .plugins.reminder import ReminderService
from .plugins.vision import VisionPlugin
from .plugins.checkin import CheckinPlugin
from .plugins.fun import FunPlugin
from .plugins.tools import ToolsPlugin

log = logging.getLogger("qqbot.bot")

# URL 兜底模式下，一次性语音文件的保留时长（秒）。
# QQ 服务端可能在上传接口返回后才回拉 URL，必须留足时间，避免提前删除导致 404。
TTS_FILE_TTL = 180


class Bot:
    def __init__(
        self, cfg: Config, api: QQApi, store: Store, llm: LLMClient
    ) -> None:
        self.cfg = cfg
        self.api = api
        self.store = store
        self.llm = llm
        self.started_at = time.time()
        self._seq: dict[str, int] = {}
        # 语音合成客户端 + 临时文件注册表（供 QQ 富媒体回拉上传）
        self.tts = TTSClient(self.api.session, cfg)
        self.tts_tmp_dir = Path(cfg.db_path).resolve().parent / "tts_tmp"
        self._tts_tokens: dict[str, Path] = {}

        self.group = GroupService(self)
        self.notify = NotifyService(self)
        self.reminders = ReminderService(self)
        # 插件链：指令 → 识图（图片附件自动触发）→ AI 聊天
        self.plugins = [
            CommandPlugin(self),
            VisionPlugin(self),
            ChatPlugin(self),
        ]
        # 指令二级分发（/帮助 里未收录的指令交由这些插件处理）
        self.feature_plugins = [
            VisionPlugin(self),
            CheckinPlugin(self),
            FunPlugin(self),
            ToolsPlugin(self),
        ]

    # ---------- 指令二级分发 ----------
    async def dispatch_feature_command(
        self, cmd: str, arg: str, msg: IncomingMessage
    ) -> str | None:
        for plugin in self.feature_plugins:
            cap = getattr(plugin, "CAP", None)
            if cap and not load_caps().get(cap, True):
                continue
            try:
                reply = await plugin.command(cmd, arg, msg, self)
            except Exception:  # noqa: BLE001
                log.exception("插件 %s 指令处理异常", type(plugin).__name__)
                continue
            if reply is not None:
                return reply
        return None

    # ---------- 生命周期 ----------
    def start_services(self) -> None:
        self.reminders.start()
        log.info(
            "服务就绪：AI=%s，定时任务=%s 条",
            "启用" if self.llm.enabled else "未配置",
            len(self.store.list_reminders(enabled_only=True)),
        )

    def stop_services(self) -> None:
        self.reminders.stop()

    # ---------- 工具 ----------
    def is_admin(self, msg: IncomingMessage) -> bool:
        return msg.sender_openid in self.cfg.admin_openids or msg.role in (
            "admin",
            "owner",
        )

    def status_text(self) -> str:
        up = int(time.time() - self.started_at)
        ai = f"已启用（{self.cfg.llm_model}）" if self.llm.enabled else "未配置 LLM_API_KEY"
        return (
            f"【{self.cfg.bot_name}】运行中\n"
            f"已运行：{up // 3600} 小时 {(up % 3600) // 60} 分钟\n"
            f"AI 聊天：{ai}\n"
            f"定时任务：{len(self.store.list_reminders())} 条\n"
            f"待送达通知：{self.store.count_pending()} 条\n"
            f"接入环境：{self.cfg.api_base}"
        )

    async def reply(self, msg: IncomingMessage, text: str) -> SendResult:
        """被动回复，自动维护同一 msg_id 下的 msg_seq（避免被平台去重）。"""
        text = text[: self.cfg.max_reply_chars]
        seq = self._seq.get(msg.msg_id, 0) + 1
        self._seq[msg.msg_id] = seq
        if len(self._seq) > 1000:
            for key in list(self._seq)[:500]:
                self._seq.pop(key, None)
        return await self.api.send(
            scene=msg.scene,
            target_id=msg.target_id,
            content=text,
            msg_id=msg.msg_id,
            msg_seq=seq,
        )

    # ---------- 语音合成 ----------
    async def speak(self, msg: IncomingMessage, text: str) -> None:
        """把文字合成语音并以语音消息发回。

        受 .env 的 TTS_ENABLED/TTS_API_KEY 与热开关 tts_auto 双重控制；
        任何异常都不影响文字回复。上传优先用 file_data 二进制直传
        （无需公网地址/端口），失败时回退到 URL 回拉。
        """
        if not self.tts.enabled:
            return
        if not load_caps().get("tts_auto", True):
            return
        try:
            audio = await self.tts.synth(text)
        except Exception:  # noqa: BLE001
            log.exception("TTS 合成异常")
            return
        if not audio:
            return

        token = secrets.token_hex(16)
        file_info: str | None = None
        # ① 首选：二进制直传（QQ 限制 5MB，300 字语音的 mp3 远低于此）
        try:
            b64 = base64.b64encode(audio).decode("ascii")
            file_info = await self.api.upload_media(
                scene=msg.scene,
                target_id=msg.target_id,
                file_type=3,  # 语音
                file_data=b64,
                file_name=f"{token}.mp3",
            )
        except Exception:  # noqa: BLE001
            log.exception("语音二进制直传异常，回退 URL 方式")
        # ② 兜底：一次性文件 URL 回拉
        if not file_info:
            file_info = await self._upload_voice_via_url(msg, audio, token)
        if not file_info:
            return
        try:
            await self.send_voice(msg, file_info)
        except Exception:  # noqa: BLE001
            log.exception("语音消息发送异常")

    async def _upload_voice_via_url(
        self, msg: IncomingMessage, audio: bytes, token: str
    ) -> str | None:
        """把 mp3 暴露为一次性 URL 供 QQ 回拉；延时清理，避免与回拉竞态。"""
        path = self.tts_tmp_dir / f"{token}.mp3"
        try:
            self.tts_tmp_dir.mkdir(parents=True, exist_ok=True)
            path.write_bytes(audio)
            self._tts_tokens[token] = path
            url = (
                f"http://{self.cfg.tts_serve_host}:{self.cfg.tts_serve_port}"
                f"/tts/{token}/{token}.mp3"
            )
            file_info = await self.api.upload_media(
                scene=msg.scene,
                target_id=msg.target_id,
                file_type=3,
                url=url,
            )
        except Exception:  # noqa: BLE001
            log.exception("语音 URL 上传异常")
            self._tts_tokens.pop(token, None)
            path.unlink(missing_ok=True)
            return None
        # 不立即删除：QQ 可能在接口返回后异步回拉，延时回收留足时间
        asyncio.get_running_loop().call_later(
            TTS_FILE_TTL, self._gc_tts_token, token, path
        )
        return file_info

    def _gc_tts_token(self, token: str, path: Path) -> None:
        """过期回收一次性语音文件（serve 已取走时为空操作）。"""
        if self._tts_tokens.pop(token, None) is not None:
            try:
                path.unlink()
            except OSError:
                pass

    async def send_voice(self, msg: IncomingMessage, file_info: str) -> SendResult:
        """发语音消息，复用同一 msg_id 的 msg_seq 防止被平台去重。"""
        seq = self._seq.get(msg.msg_id, 0) + 1
        self._seq[msg.msg_id] = seq
        return await self.api.send_media(
            scene=msg.scene,
            target_id=msg.target_id,
            file_info=file_info,
            msg_id=msg.msg_id,
            msg_seq=seq,
        )

    def pop_tts_file(self, token: str, name: str) -> Path | None:
        """临时文件服务回调：校验 token 后取出文件路径，用完即删。"""
        path = self._tts_tokens.pop(token, None)
        if path is None:
            return None
        if name != path.name:
            self._tts_tokens[token] = path  # 名称不符，放回防误删
            return None
        return path

    # ---------- 事件入口 ----------
    async def handle_event(
        self, t: str, d: dict, event_id: str, seq: int
    ) -> None:
        if t in MESSAGE_EVENTS:
            await self._on_message(t, d, event_id, seq)
        else:
            await self._on_other(t, d, event_id)

    async def _on_message(
        self, t: str, d: dict, event_id: str, seq: int
    ) -> None:
        msg = IncomingMessage.from_payload(t, d, event_id, seq)
        if not msg.msg_id:
            log.warning("消息缺少 id，已忽略：%s", t)
            return
        caps = load_caps()
        if caps.get("dedupe", True) and self.store.is_duplicate(msg.msg_id):
            log.debug("重复推送，已忽略 %s…", msg.msg_id[:16])
            return
        if not msg.target_id:
            log.warning("消息缺少目标 openid，已忽略：%s", t)
            return

        log.info(
            "收到消息 [%s/%s] %s: %s",
            t,
            msg.short_sender,
            msg.target_id[-8:],
            msg.content[:80],
        )

        reply: str | None = None
        for plugin in self.plugins:
            if isinstance(plugin, ChatPlugin) and not caps.get("ai_chat", True):
                continue
            try:
                reply = await plugin.handle(msg, self)
            except Exception:  # noqa: BLE001
                log.exception("插件 %s 处理异常", type(plugin).__name__)
            if reply:
                break

        # 主动消息没发出去的通知，借这次被动回复机会带出来
        pending = (
            self.store.pop_pending(
                msg.scene, msg.target_id, self.cfg.max_pending_flush
            )
            if caps.get("pending_flush", True)
            else []
        )
        if pending:
            block = "【之前没发出去的通知】\n" + "\n".join(
                f"· {p}" for p in pending
            )
            reply = f"{reply}\n\n{block}" if reply else block

        if reply:
            result = await self.reply(msg, reply)
            if not result.ok:
                log.warning(
                    "回复发送失败：code=%s %s", result.code, result.message
                )

    async def _on_other(self, t: str, d: dict, event_id: str) -> None:
        if t in (GROUP_ADD_ROBOT, FRIEND_ADD) and not load_caps().get(
            "welcome", True
        ):
            return
        if t == GROUP_ADD_ROBOT:
            group = d.get("group_openid")
            if group:
                text = self.cfg.welcome_text.format(name=self.cfg.bot_name)
                result = await self.api.send(
                    scene="group",
                    target_id=group,
                    content=text,
                    event_id=event_id,
                    msg_seq=1,
                )
                log.info(
                    "入群欢迎：%s",
                    "成功" if result.ok else f"失败 code={result.code}",
                )
        elif t == FRIEND_ADD:
            user = d.get("user_openid") or (d.get("author") or {}).get(
                "user_openid"
            )
            if user:
                await self.api.send(
                    scene="c2c",
                    target_id=user,
                    content=f"你好，我是{self.cfg.bot_name}～发 /帮助 看看我能做什么。",
                    event_id=event_id,
                    msg_seq=1,
                )
        elif t in (
            GROUP_MSG_RECEIVE,
            GROUP_MSG_REJECT,
            C2C_MSG_RECEIVE,
            C2C_MSG_REJECT,
        ):
            log.info("主动消息授权状态变更：%s", t)
        else:
            log.debug("未处理事件：%s", t)
