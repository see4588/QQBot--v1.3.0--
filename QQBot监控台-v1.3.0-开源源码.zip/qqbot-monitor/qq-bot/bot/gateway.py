"""QQ 网关 WebSocket 长连接：登录鉴权、心跳、断线重连与会话恢复。

协议参考：https://bot.qq.com/wiki/develop/api-v2/dev-prepare/event-emit/websocket.html
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Awaitable, Callable

import aiohttp

log = logging.getLogger("qqbot.gateway")

# 不可自行恢复、必须人工处理的关闭码
FATAL_CODES = {4013, 4014, 4914, 4915}
# 需要清空 session 并重新 IDENTIFY 的关闭码
REIDENTIFY_CODES = {4006, 4007, 4004} | set(range(4900, 4914))

EventHandler = Callable[[str, dict, str, int], Awaitable[None]]


class Gateway:
    def __init__(
        self,
        cfg,
        api,
        session: aiohttp.ClientSession,
        on_event: EventHandler,
    ):
        self.cfg = cfg
        self.api = api
        self.session = session
        self.on_event = on_event
        self.session_id = ""
        self.last_seq: int | None = None
        self._ws: aiohttp.ClientWebSocketResponse | None = None
        self._closed = False
        self._fatal = False
        self._backoff = 1
        self._hb_task: asyncio.Task | None = None

    # ---------- 对外 ----------
    def stop(self) -> None:
        self._closed = True
        if self._ws is not None and not self._ws.closed:
            asyncio.create_task(self._ws.close())

    @property
    def fatal(self) -> bool:
        return self._fatal

    async def run(self) -> None:
        """带指数退避的主循环。"""
        while not self._closed and not self._fatal:
            try:
                await self._connect_once()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                log.exception("网关连接异常：%s", exc)
            if self._closed or self._fatal:
                break
            wait = min(self._backoff, 60)
            log.info("%s 秒后重连网关…", wait)
            await asyncio.sleep(wait)
            self._backoff = min(self._backoff * 2, 60)
        if self._fatal:
            log.error("网关终止：请根据上方错误提示到 QQ 开放平台检查配置。")

    # ---------- 连接 ----------
    async def _connect_once(self) -> None:
        url = await self.api.gateway_url()
        log.info("连接 QQ 网关：%s", url)
        async with self.session.ws_connect(
            url, heartbeat=None, autoping=True, max_msg_size=8 * 1024 * 1024
        ) as ws:
            self._ws = ws
            self._backoff = 1
            await self._loop(ws)
        self._handle_close(ws.close_code)

    async def _loop(self, ws: aiohttp.ClientWebSocketResponse) -> None:
        try:
            async for msg in ws:
                if msg.type == aiohttp.WSMsgType.TEXT:
                    try:
                        payload: dict[str, Any] = json.loads(msg.data)
                    except (ValueError, TypeError):
                        log.warning("收到非 JSON 帧，已忽略")
                        continue
                    if await self._handle_payload(ws, payload):
                        break
                elif msg.type in (
                    aiohttp.WSMsgType.CLOSE,
                    aiohttp.WSMsgType.CLOSED,
                    aiohttp.WSMsgType.ERROR,
                ):
                    break
        finally:
            if self._hb_task is not None:
                self._hb_task.cancel()
                self._hb_task = None

    async def _handle_payload(
        self, ws: aiohttp.ClientWebSocketResponse, payload: dict[str, Any]
    ) -> bool:
        """返回 True 表示需要断开当前连接。"""
        op = payload.get("op")
        if op == 10:  # Hello
            interval = int(
                (payload.get("d") or {}).get("heartbeat_interval", 45000)
            ) / 1000.0
            if self._hb_task is not None:
                self._hb_task.cancel()
            self._hb_task = asyncio.create_task(self._heartbeat(ws, interval))
            if self.session_id and self.last_seq is not None:
                await self._resume(ws)
            else:
                await self._identify(ws)
            return False

        if op == 0:  # Dispatch
            seq = payload.get("s")
            if isinstance(seq, int):
                self.last_seq = seq
            t = payload.get("t") or ""
            d = payload.get("d") or {}
            event_id = payload.get("id") or ""
            if t in ("READY", "RESUMED"):
                if t == "READY":
                    self.session_id = (d.get("session_id") or "") if isinstance(d, dict) else ""
                log.info(
                    "登录成功（%s），session_id=%s…", t, self.session_id[:8]
                )
            if t and isinstance(d, dict) and d:
                asyncio.create_task(self._safe_dispatch(t, d, event_id, seq or 0))
            return False

        if op == 1:  # 服务端要求立即心跳
            await self._send(ws, {"op": 1, "d": self.last_seq})
            return False

        if op == 7:  # 服务端要求重连（保留 session，走 RESUME）
            log.info("服务端要求重连，准备 RESUME")
            return True

        if op == 9:  # 会话失效
            resumable = bool(payload.get("d"))
            log.warning("会话失效（可恢复=%s）", resumable)
            if not resumable:
                self._clear_session()
            await asyncio.sleep(3)
            return True

        if op == 11:  # Heartbeat ACK
            return False

        log.debug("未处理的 opcode=%s", op)
        return False

    async def _safe_dispatch(
        self, t: str, d: dict, event_id: str, seq: int
    ) -> None:
        try:
            await self.on_event(t, d, event_id, seq)
        except Exception:  # noqa: BLE001
            log.exception("处理事件 %s 时出错", t)

    # ---------- 鉴权与心跳 ----------
    async def _identify(self, ws: aiohttp.ClientWebSocketResponse) -> None:
        token = await self.api.get_token()
        await self._send(
            ws,
            {
                "op": 2,
                "d": {
                    "token": f"QQBot {token}",
                    "intents": self.cfg.intents,
                    "shard": list(self.cfg.shard),
                    "properties": {
                        "$os": "linux",
                        "$browser": "qqbot-python",
                        "$device": "qqbot-python",
                    },
                },
            },
        )
        log.info("已发送 IDENTIFY，intents=%s", self.cfg.intents)

    async def _resume(self, ws: aiohttp.ClientWebSocketResponse) -> None:
        token = await self.api.get_token()
        await self._send(
            ws,
            {
                "op": 6,
                "d": {
                    "token": f"QQBot {token}",
                    "session_id": self.session_id,
                    "seq": self.last_seq,
                },
            },
        )
        log.info("已发送 RESUME，seq=%s", self.last_seq)

    async def _heartbeat(
        self, ws: aiohttp.ClientWebSocketResponse, interval: float
    ) -> None:
        try:
            while not ws.closed:
                await asyncio.sleep(max(interval, 5))
                if ws.closed:
                    return
                await self._send(ws, {"op": 1, "d": self.last_seq})
        except asyncio.CancelledError:
            return
        except Exception as exc:  # noqa: BLE001
            log.warning("心跳异常：%s", exc)

    async def _send(
        self, ws: aiohttp.ClientWebSocketResponse, payload: dict
    ) -> None:
        try:
            await ws.send_json(payload)
        except Exception as exc:  # noqa: BLE001
            log.warning("发送 opcode=%s 失败：%s", payload.get("op"), exc)

    # ---------- 关闭处理 ----------
    def _clear_session(self) -> None:
        self.session_id = ""
        self.last_seq = None

    def _handle_close(self, code: int | None) -> None:
        if code is None:
            return
        log.info("WebSocket 关闭，code=%s", code)
        if code in (4013, 4014):
            log.error(
                "intents 无权限（code=%s，当前 QQ_INTENTS=%s）。"
                "请到 QQ 开放平台「事件订阅」勾选对应权限，或把 QQ_INTENTS 改回 33554432。",
                code,
                self.cfg.intents,
            )
            self._fatal = True
        elif code in (4914, 4915):
            log.error(
                "机器人已下架或被封禁（code=%s）。若仍在调试，请把 QQ_SANDBOX=true 连接沙箱环境。",
                code,
            )
            self._fatal = True
        elif code == 4004:
            log.warning("token 无效，刷新后重新登录")
            self.api.invalidate_token()
            self._clear_session()
        elif code == 4008:
            log.warning("触发频控，60 秒后重连")
            self._backoff = 60
        elif code == 4009:
            log.info("连接过期，将尝试 RESUME")
        elif code in REIDENTIFY_CODES:
            log.info("会话不可用，将重新 IDENTIFY")
            self._clear_session()
