"""QQ 官方机器人（WebSocket 接入）· 工程包。"""
__version__ = "1.0.0"
