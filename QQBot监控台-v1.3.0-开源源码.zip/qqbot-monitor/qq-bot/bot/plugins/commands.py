"""指令与关键词插件（优先级最高，命中后不再进入 AI 聊天）。"""
from __future__ import annotations

import json
import logging

from ..config import BASE_DIR
from ..caps import enabled
from ..events import IncomingMessage

log = logging.getLogger("qqbot.cmd")

# 手机控制台把关键词写到项目根目录的独立 JSON，机器人按内容热读，改完立即生效。
# 与 Config.BASE_DIR 保持同一基准；文件不存在时回退到 .env 的 KEYWORD_RULES。
KEYWORDS_FILE = BASE_DIR / "keywords.json"
# 按文件内容比对而非 mtime（同一秒内连续写入时 mtime 精度不够）
_kw_cache: dict = {"raw": None, "rules": None}


def load_keyword_rules(bot) -> dict:
    try:
        raw = KEYWORDS_FILE.read_text(encoding="utf-8")
    except OSError:
        _kw_cache["raw"] = None
        _kw_cache["rules"] = None
        return dict(bot.cfg.keyword_rules)
    if raw == _kw_cache["raw"] and _kw_cache["rules"] is not None:
        return dict(_kw_cache["rules"])
    try:
        data = json.loads(raw)
        rules = (
            {str(k): str(v) for k, v in data.items()}
            if isinstance(data, dict)
            else {}
        )
    except (ValueError, TypeError):
        log.warning("keywords.json 解析失败，已回退 .env 规则")
        return dict(bot.cfg.keyword_rules)
    _kw_cache["raw"] = raw
    _kw_cache["rules"] = rules
    return dict(rules)


class CommandPlugin:
    def __init__(self, bot):
        self.bot = bot

    def _help(self, bot) -> str:
        return (
            f"【{bot.cfg.bot_name} 指令】\n"
            "—— 基础 ——\n"
            "/帮助              显示本菜单\n"
            "/状态              查看运行状态\n"
            "/清空              清空本会话聊天记忆\n"
            "/关键词            查看关键词回复规则\n"
            "—— 管理（管理员） ——\n"
            "/通知 <内容>       发一条通知\n"
            "/广播 <内容>       广播到所有会话\n"
            "/禁言 <分钟> @成员 /解禁 <openid> /撤回\n"
            "—— 定时 ——\n"
            "/提醒 列表｜添加 <cron> :: <内容>｜删除/暂停/恢复 <id>\n"
            "—— 识图 ——\n"
            "/识图 [问题]       识别图片（直接发图也可自动识别）\n"
            "—— 积分 ——\n"
            "/签到  /积分  /排行榜  /打赏 @成员 <数量>\n"
            "—— 娱乐 ——\n"
            "/抽签  /运势 [星座]  /掷骰子 [n]d[m]  /猜拳 [出拳]  /成语 [词语]\n"
            "—— 工具 ——\n"
            "/翻译 <文字>  /天气 [城市]  /计算 <表达式>  /百科 <词条>\n"
            "————————————\n"
            "其余消息交给 AI 聊天；群聊需要 @我。\n"
            "开启语音后，AI 回复会同时发一条语音消息。\n"
            "cron 示例：0 9 * * * 每天9点；*/30 * * * * 每30分钟"
        )

    async def handle(self, msg: IncomingMessage, bot):
        text = msg.content.strip()
        if not text:
            return None
        commands_on = enabled("commands", True)
        keywords_on = enabled("keywords", True)
        if not commands_on and not keywords_on:
            return None

        # 非指令：先匹配关键词规则，未命中则交给聊天插件
        if not text.startswith("/"):
            if not keywords_on:
                return None
            for keyword, answer in load_keyword_rules(bot).items():
                if keyword and keyword in text:
                    return answer
            return None

        if not commands_on:
            return None

        parts = text.split(None, 1)
        cmd = parts[0].lstrip("/").lower()
        arg = (parts[1] if len(parts) > 1 else "").strip()

        if cmd in ("帮助", "help", "菜单", "menu"):
            return self._help(bot)
        if cmd in ("状态", "status", "info"):
            return bot.status_text()
        if cmd in ("清空", "clear", "重置"):
            bot.store.clear_history(msg.scene, msg.target_id)
            return "已清空当前会话的聊天上下文～"
        if cmd == "关键词":
            rules = load_keyword_rules(bot)
            if not rules:
                return "当前没有关键词规则，可在手机控制台「自动化 → 关键词回复」里添加。"
            return "【关键词规则】\n" + "\n".join(
                f"· {k} → {v}" for k, v in rules.items()
            )
        if cmd == "通知":
            if not arg:
                return "用法：/通知 <内容>"
            if not bot.is_admin(msg):
                return "只有管理员能发通知。"
            ok, info = await bot.notify.push(msg.scene, msg.target_id, arg)
            return f"通知{'已送达' if ok else '未送达'}：{info}"
        if cmd == "广播":
            if not arg:
                return "用法：/广播 <内容>"
            if not bot.is_admin(msg):
                return "只有管理员能广播。"
            total, sent = await bot.notify.broadcast(arg)
            return (
                f"广播完成：共 {total} 个会话，直接送达 {sent} 个，"
                "其余已转入待发队列。"
            )
        if cmd == "提醒":
            if not enabled("reminder", True):
                return "定时提醒功能当前已关闭（可在手机控制台开启）。"
            return await self._reminder(arg, msg, bot)
        if cmd in ("禁言", "解禁", "撤回", "recall"):
            if not enabled("group_admin", True):
                return "群管理指令当前已关闭（可在手机控制台开启）。"
        if cmd == "禁言":
            return await self._mute(arg, msg, bot)
        if cmd == "解禁":
            return await self._unmute(arg, msg, bot)
        if cmd in ("撤回", "recall"):
            return await self._recall(msg, bot)

        # 未收录的指令交给扩展插件（识图/积分/娱乐/工具）处理
        dispatched = await self.bot.dispatch_feature_command(cmd, arg, msg)
        if dispatched is not None:
            return dispatched

        return f"不认识的指令「/{cmd}」，发 /帮助 查看可用指令。"

    # ---------- 定时提醒 ----------
    async def _reminder(self, arg: str, msg: IncomingMessage, bot) -> str:
        if not arg or arg.split()[0] in ("列表", "list", "ls"):
            rows = bot.store.list_reminders()
            if not rows:
                return (
                    "还没有定时提醒。\n"
                    "添加：/提醒 添加 0 9 * * * :: 早上好，记得打卡"
                )
            lines = [
                f"#{r['id']} [{'开' if r['enabled'] else '关'}] "
                f"{r['cron']} → {r['content']}"
                for r in rows
            ]
            return "【定时提醒】\n" + "\n".join(lines)

        verb, _, rest = arg.partition(" ")
        rest = rest.strip()

        if verb in ("添加", "add"):
            if not bot.is_admin(msg):
                return "只有管理员能添加定时提醒。"
            if "::" not in rest:
                return (
                    "格式：/提醒 添加 <cron表达式> :: <提醒内容>\n"
                    "例：/提醒 添加 0 9 * * * :: 早上好，记得打卡"
                )
            cron, _, content = rest.partition("::")
            cron, content = cron.strip(), content.strip()
            if not cron or not content:
                return "cron 表达式和提醒内容都不能为空。"
            ok, info, rid = bot.reminders.add(
                msg.scene, msg.target_id, cron, content
            )
            return (
                f"已添加定时提醒 #{rid}：{cron} → {content}"
                if ok
                else f"添加失败：{info}"
            )

        if verb in ("删除", "del", "remove", "rm"):
            if not bot.is_admin(msg):
                return "只有管理员能删除定时提醒。"
            if not rest.isdigit():
                return "用法：/提醒 删除 <id>"
            return (
                f"已删除 #{rest}"
                if bot.reminders.remove(int(rest))
                else f"没找到 #{rest}"
            )

        if verb in ("暂停", "pause") and rest.isdigit():
            if not bot.is_admin(msg):
                return "只有管理员能修改定时提醒。"
            return (
                f"已暂停 #{rest}"
                if bot.reminders.set_enabled(int(rest), False)
                else f"没找到 #{rest}"
            )
        if verb in ("恢复", "resume") and rest.isdigit():
            if not bot.is_admin(msg):
                return "只有管理员能修改定时提醒。"
            return (
                f"已恢复 #{rest}"
                if bot.reminders.set_enabled(int(rest), True)
                else f"没找到 #{rest}"
            )

        return (
            "用法：/提醒 列表 ｜ /提醒 添加 <cron> :: <内容> ｜ "
            "/提醒 删除 <id> ｜ /提醒 暂停 <id> ｜ /提醒 恢复 <id>"
        )

    # ---------- 群管理 ----------
    @staticmethod
    def _extract_member(arg: str, msg: IncomingMessage) -> tuple[str, int]:
        tokens = arg.split()
        minutes = 10
        member = ""
        for tok in tokens:
            if tok.isdigit() and len(tok) <= 4:
                minutes = max(1, min(int(tok), 43200))
                break
        for tok in tokens:
            if len(tok) >= 16 and not tok.startswith("@"):
                member = tok
                break
        if not member and msg.mentions:
            member = msg.mentions[0]
        return member, minutes

    async def _mute(self, arg: str, msg: IncomingMessage, bot) -> str:
        if not msg.is_group:
            return "禁言只能在群聊里使用。"
        if not bot.is_admin(msg):
            return "只有管理员能使用禁言。"
        member, minutes = self._extract_member(arg, msg)
        if not member:
            return (
                "没找到要禁言的成员。请 @ 对方，或直接给 member_openid。\n"
                "用法：/禁言 60 @某人"
            )
        _, text = await bot.group.mute(msg.target_id, member, minutes)
        return text

    async def _unmute(self, arg: str, msg: IncomingMessage, bot) -> str:
        if not msg.is_group:
            return "解禁只能在群聊里使用。"
        if not bot.is_admin(msg):
            return "只有管理员能使用解禁。"
        tokens = arg.split()
        member = tokens[0] if tokens else ""
        if not member and msg.mentions:
            member = msg.mentions[0]
        if not member:
            return "用法：/解禁 <member_openid> 或 /解禁 @某人"
        _, text = await bot.group.unmute(msg.target_id, member)
        return text

    async def _recall(self, msg: IncomingMessage, bot) -> str:
        if not msg.is_group:
            return "撤回只在群聊里可用。"
        if not bot.is_admin(msg):
            return "只有管理员能撤回消息。"
        _, text = await bot.group.recall(msg.target_id, msg.msg_id)
        return text
