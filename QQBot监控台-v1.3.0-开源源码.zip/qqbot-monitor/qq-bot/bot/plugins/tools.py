"""实用工具插件：翻译 / 天气 / 计算 / 百科。

指令：
  /翻译 <文本>        中英互译（用大模型）
  /天气 [城市]        查询城市天气（默认配置里的城市）
  /计算 <表达式>      安全算术（支持 + - * / % ** 和括号）
  /百科 <词条>        一句话百科（用大模型）
"""
from __future__ import annotations

import ast
import logging
import re

import aiohttp

from ..caps import enabled
from ..events import IncomingMessage

log = logging.getLogger("qqbot.tools")

COMMANDS = {"翻译", "天气", "计算", "算", "百科", "百科问答"}

_WX_DESC = {
    "Sunny": "晴", "Clear": "晴", "Partly cloudy": "多云", "Cloudy": "阴",
    "Mist": "薄雾", "Fog": "雾", "Patchy rain possible": "可能有阵雨",
    "Patchy rain nearby": "局部有雨", "Light rain": "小雨", "Moderate rain": "中雨",
    "Heavy rain": "大雨", "Light drizzle": "毛毛雨", "Thundery outbreaks": "雷阵雨",
    "Light snow": "小雪", "Moderate snow": "中雪", "Heavy snow": "大雪",
    "Overcast": "阴",
}


class ToolsPlugin:
    CAP = "tools"

    def __init__(self, bot):
        self.bot = bot

    async def command(self, cmd: str, arg: str, msg: IncomingMessage, bot) -> str | None:
        if cmd == "翻译":
            return await self._translate(arg, bot)
        if cmd == "天气":
            return await self._weather(arg.strip(), bot)
        if cmd in ("计算", "算"):
            return self._calc(arg.strip())
        if cmd in ("百科", "百科问答"):
            return await self._wiki(arg, bot)
        return None

    async def _translate(self, text: str, bot) -> str:
        if not text.strip():
            return "用法：/翻译 <要翻译的文字>"
        if not bot.llm.enabled:
            return "翻译需要配置大模型（LLM_API_KEY），目前未开启。"
        ans = await bot.llm.chat([
            {"role": "user", "content":
             f"请把下面这段文字翻译为另一种语言（中文翻英文、英文翻中文）：\n{text}"}
        ])
        return ans or "翻译失败，稍后再试。"

    async def _weather(self, city: str, bot) -> str:
        city = city or bot.cfg.weather_default_city or "北京"
        url = "https://wttr.in/" + _quote(city) + "?format=j1&lang=zh"
        try:
            async with bot.api.session.get(
                url, timeout=aiohttp.ClientTimeout(total=18),
                headers={"User-Agent": "curl/8.0"},
            ) as r:
                if r.status >= 400:
                    return f"没查到「{city}」的天气，换个写法试试？"
                data = await r.json()
        except Exception as exc:  # noqa: BLE001
            log.warning("天气查询失败：%s", exc)
            return "天气服务暂时连不上，稍后再试。"
        try:
            cur = data["current_condition"][0]
            area = data.get("nearest_area", [{}])[0]
            name = area.get("areaName", [{}])[0].get("value", city)
            region = area.get("region", [{}])[0].get("value", "")
            desc_en = cur["weatherDesc"][0]["value"]
            desc = _WX_DESC.get(desc_en, desc_en)
            temp = cur["temp_C"]
            feels = cur["FeelsLikeC"]
            hum = cur["humidity"]
            wind = cur["windspeedKmph"]
            return (
                f"【{name}{('·'+region) if region else ''} 天气】\n"
                f"{desc} {temp}°C（体感 {feels}°C）\n"
                f"湿度 {hum}% · 风速 {wind} km/h"
            )
        except (KeyError, IndexError, TypeError):
            return f"查到了「{city}」的天气数据但解析失败，换个城市试试。"

    def _calc(self, expr: str) -> str:
        if not expr.strip():
            return "用法：/计算 <表达式>，例如 /计算 (12+8)*3/2"
        try:
            val = _safe_eval(expr)
        except (ValueError, SyntaxError, ZeroDivisionError) as exc:
            return f"算不出来：{exc}"
        return f"{expr} = {val}"

    async def _wiki(self, text: str, bot) -> str:
        if not text.strip():
            return "用法：/百科 <词条>"
        if not bot.llm.enabled:
            return "百科问答需要配置大模型（LLM_API_KEY），目前未开启。"
        ans = await bot.llm.chat([
            {"role": "user", "content":
             f"用 1-3 句通俗中文解释「{text}」，不要使用 Markdown，口语化一点。"}
        ])
        return ans or "没查到相关解释，换个词条试试。"


def _quote(s: str) -> str:
    return __import__("urllib.parse", fromlist=["quote"]).quote(s)


def _safe_eval(expr: str) -> float:
    """仅允许数字与 + - * / % ** // 和圆括号，杜绝任意代码执行。"""
    allowed = set("0123456789+-*/%(). ")
    if not all(ch in allowed for ch in expr):
        raise ValueError("表达式里含有不支持的字符")
    if re.search(r"__|import|eval|exec|open|system|globals|locals|lambda", expr):
        raise ValueError("表达式不合法")
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as exc:
        raise ValueError(f"语法错误：{exc}")
    allowed_nodes = (
        ast.Expression, ast.Constant, ast.BinOp, ast.UnaryOp,
        ast.operator, ast.USub, ast.UAdd,
        ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Mod, ast.Pow, ast.FloorDiv,
    )
    for node in ast.walk(tree):
        if not isinstance(node, allowed_nodes):
            raise ValueError("表达式含有不支持的运算")
    result = eval(  # noqa: S307 - 已在 AST 层严格限制
        compile(tree, "<calc>", "eval"),
        {"__builtins__": {}},
        {},
    )
    return round(float(result), 6)
