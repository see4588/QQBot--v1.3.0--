"""AI 聊天插件：带会话上下文，未配置密钥时给出明确降级提示。"""
from __future__ import annotations

import logging

from ..events import IncomingMessage

log = logging.getLogger("qqbot.chat")


class ChatPlugin:
    def __init__(self, bot):
        self.bot = bot

    async def handle(self, msg: IncomingMessage, bot):
        if not msg.content:
            return None

        history = bot.store.get_history(
            msg.scene, msg.target_id, bot.cfg.history_limit
        )
        # 群聊里带上发送者，避免多人对话串味
        user_text = (
            f"[{msg.short_sender}] {msg.content}" if msg.is_group else msg.content
        )
        messages = [
            {"role": h["role"], "content": h["content"]} for h in history
        ]
        messages.append({"role": "user", "content": user_text})

        answer = await bot.llm.chat(messages)
        if not answer:
            return (
                "我还没配置大模型密钥，暂时只能使用指令功能～\n"
                "发 /帮助 看看我能做什么；在服务器 .env 里填上 LLM_API_KEY 就能开启 AI 聊天。"
            )

        bot.store.add_history(msg.scene, msg.target_id, "user", user_text)
        bot.store.add_history(msg.scene, msg.target_id, "assistant", answer)
        # AI 回复自动转语音（受 tts 开关控制；异常不影响文字回复）
        try:
            await bot.speak(msg, answer)
        except Exception:  # noqa: BLE001
            log.exception("自动语音触发异常")
        return answer
