"""群管理服务：禁言 / 解禁 / 撤回（官方 v2 接口封装）。"""
from __future__ import annotations

import logging

log = logging.getLogger("qqbot.group")


class GroupService:
    def __init__(self, bot):
        self.bot = bot

    @staticmethod
    def _fmt(status: int, data: dict, ok_text: str) -> tuple[bool, str]:
        if 200 <= status < 300 and not data.get("code"):
            return True, ok_text
        return False, (
            f"操作失败：code={data.get('code') or status} "
            f"{data.get('message') or data.get('raw') or ''}\n"
            "提示：机器人需要是该群管理员，且只能操作普通成员。"
        )

    async def mute(
        self, group_openid: str, member_openid: str, minutes: int
    ) -> tuple[bool, str]:
        status, data = await self.bot.api.mute_member(
            group_openid, member_openid, minutes * 60
        )
        return self._fmt(
            status,
            data,
            f"已禁言 {member_openid[-8:]} {minutes} 分钟。",
        )

    async def unmute(
        self, group_openid: str, member_openid: str
    ) -> tuple[bool, str]:
        status, data = await self.bot.api.mute_member(
            group_openid, member_openid, 0, op="del"
        )
        return self._fmt(
            status, data, f"已解除 {member_openid[-8:]} 的禁言。"
        )

    async def recall(
        self, group_openid: str, message_id: str
    ) -> tuple[bool, str]:
        status, data = await self.bot.api.recall(group_openid, message_id)
        return self._fmt(
            status,
            data,
            "已撤回该消息（仅支持 2 分钟内的消息）。",
        )
