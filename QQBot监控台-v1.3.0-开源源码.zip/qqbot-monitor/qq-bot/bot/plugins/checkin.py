"""签到积分插件：每日签到、积分余额、排行榜、积分转账。

指令：
  /签到            每日签到，连续天数越多奖励越多
  /积分            查看我的积分余额、累计与连续天数
  /排行榜          积分榜前 10
  /打赏 <@成员> <数量>   把自己的积分转给别人（需 @ 对方）
"""
from __future__ import annotations

import logging

from ..caps import enabled
from ..events import IncomingMessage

log = logging.getLogger("qqbot.checkin")

COMMANDS = {"签到", "积分", "积分榜", "排行榜", "打赏"}


def _short(tid: str) -> str:
    return "…" + tid[-6:] if len(tid) > 6 else tid


class CheckinPlugin:
    CAP = "checkin"

    def __init__(self, bot):
        self.bot = bot

    async def command(self, cmd: str, arg: str, msg: IncomingMessage, bot) -> str | None:
        if cmd == "签到":
            return self._do_checkin(msg, bot)
        if cmd in ("积分",):
            return self._show(msg, bot)
        if cmd in ("积分榜", "排行榜"):
            return self._rank(bot)
        if cmd == "打赏":
            return await self._transfer(arg, msg, bot)
        return None

    def _do_checkin(self, msg: IncomingMessage, bot) -> str:
        done, gain, streak, bal = bot.store.checkin(msg.scene, msg.target_id)
        if done:
            return f"你今天已经签到过啦～ 连续 {streak} 天，当前积分 {bal}。"
        return (
            f"签到成功！本次 +{gain} 积分（连续 {streak} 天）\n"
            f"当前积分余额：{bal}"
        )

    def _show(self, msg: IncomingMessage, bot) -> str:
        p = bot.store.get_points(msg.scene, msg.target_id)
        return (
            f"【我的积分】\n余额：{p['balance']}\n累计获得：{p['total']}\n"
            f"连续签到：{p['streak']} 天"
        )

    def _rank(self, bot) -> str:
        rows = bot.store.top_points(10)
        if not rows:
            return "还没有人攒到积分，发 /签到 抢首杀～"
        lines = []
        for i, r in enumerate(rows, 1):
            lines.append(
                f"{i}. {_short(r['target_id'])} — {r['balance']} 积分"
                f"（连{r['streak']}）"
            )
        return "【积分排行榜】\n" + "\n".join(lines)

    async def _transfer(self, arg: str, msg: IncomingMessage, bot) -> str:
        tokens = arg.split()
        if not tokens:
            return "用法：/打赏 @对方 <数量>"
        amount = None
        for t in tokens:
            if t.isdigit():
                amount = int(t)
                break
        if amount is None or amount <= 0:
            return "用法：/打赏 @对方 <正整数数量>"
        target = msg.mentions[0] if msg.mentions else ""
        if not target:
            # 容错：arg 里直接带了 openid
            for t in tokens:
                if len(t) >= 16 and not t.isdigit():
                    target = t
                    break
        if not target:
            return "没找到要打赏的对象，请 @ 对方，例如：/打赏 @小明 10"
        ok, info = bot.store.transfer_points(
            (msg.scene, msg.target_id), (msg.scene, target), amount
        )
        return ("打赏成功！" if ok else "打赏失败：") + info
