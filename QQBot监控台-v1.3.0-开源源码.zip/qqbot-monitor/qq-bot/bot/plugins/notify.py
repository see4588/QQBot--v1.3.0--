"""通知推送：主动消息失败时转入待发队列，下次交互自动带出。

背景：QQ 官方机器人对主动消息有权限与频控限制（40034105 / 40034100 等），
且没有群列表 / 好友列表接口。因此定时提醒和广播不能保证即时送达，
这里用「待发队列 + 下次被动回复搭车」的方式保证消息最终可见。
"""
from __future__ import annotations

import logging

log = logging.getLogger("qqbot.notify")


class NotifyService:
    def __init__(self, bot):
        self.bot = bot

    async def push(
        self, scene: str, target_id: str, content: str
    ) -> tuple[bool, str]:
        result = await self.bot.api.send(
            scene=scene, target_id=target_id, content=content
        )
        if result.ok:
            return True, "已直接送达"
        self.bot.store.add_pending(scene, target_id, content)
        log.info(
            "通知转入待发队列：%s/%s code=%s",
            scene,
            target_id[-8:],
            result.code,
        )
        return False, (
            f"主动消息受限（code={result.code} {result.message}），"
            "已存入待发队列，下次有人发言时自动带出"
        )

    async def broadcast(self, content: str) -> tuple[int, int]:
        targets = self.bot.store.known_targets()
        sent = 0
        for scene, target_id in targets:
            ok, _ = await self.push(scene, target_id, content)
            if ok:
                sent += 1
        return len(targets), sent
