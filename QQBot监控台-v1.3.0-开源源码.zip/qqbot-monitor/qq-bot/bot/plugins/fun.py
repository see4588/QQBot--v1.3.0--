"""娱乐插件：抽签 / 运势 / 掷骰子 / 猜拳 / 成语接龙。

指令：
  /抽签               来一签（大吉/中吉/小吉/凶 + 签文）
  /运势 [星座]        今日运势百分比
  /掷骰子 [n]d[m]     掷骰子，默认 1d6
  /猜拳 [石头|剪刀|布] 和机器人划拳
  /成语 [词语]        成语接龙（给词接龙，不给词随机抽一成语）
"""
from __future__ import annotations

import logging
import random

from ..caps import enabled
from ..events import IncomingMessage

log = logging.getLogger("qqbot.fun")

COMMANDS = {"抽签", "运势", "掷骰子", "掷骰", "猜拳", "成语", "手气"}

_FORTUNES = [
    ("大吉", "今日宜大胆尝试，想做的事都能成。"),
    ("中吉", "平稳顺遂，按部就班就有收获。"),
    ("小吉", "小确幸降临，留意身边的好消息。"),
    ("吉", "贵人相助，难题迎刃而解。"),
    ("凶", "宜低调谨慎，重要决定先放一放。"),
    ("末吉", "先苦后甜，熬过开头就是晴天。"),
]
_ZODIAC = ["白羊", "金牛", "双子", "巨蟹", "狮子", "处女", "天秤", "天蝎",
           "射手", "摩羯", "水瓶", "双鱼"]
_IDIOMS = [
    "一帆风顺", "画蛇添足", "守株待兔", "亡羊补牢", "井底之蛙",
    "对牛弹琴", "雪中送炭", "锦上添花", "水滴石穿", "百发百中",
]
_RPS = ["石头", "剪刀", "布"]


class FunPlugin:
    CAP = "fun"

    def __init__(self, bot):
        self.bot = bot

    async def command(self, cmd: str, arg: str, msg: IncomingMessage, bot) -> str | None:
        if cmd == "抽签":
            return self._draw()
        if cmd == "运势":
            return self._luck(arg.strip())
        if cmd in ("掷骰子", "掷骰", "手气"):
            return self._dice(arg.strip())
        if cmd == "猜拳":
            return self._rps(arg.strip())
        if cmd == "成语":
            return await self._idiom(arg.strip(), bot)
        return None

    def _draw(self) -> str:
        level, text = random.choice(_FORTUNES)
        return f"【抽签】{level}\n{text}"

    def _luck(self, zodiac: str) -> str:
        if not zodiac:
            zodiac = random.choice(_ZODIAC)
        score = random.randint(40, 99)
        if score >= 85:
            mood = "运势爆棚，冲就完事了"
        elif score >= 65:
            mood = "整体不错，注意把握机会"
        elif score >= 50:
            mood = "中规中矩，稳扎稳打"
        else:
            mood = "今天宜佛系，别硬刚"
        return f"【{zodiac}座今日运势】{score} 分\n{mood}"

    def _dice(self, arg: str) -> str:
        n, m = 1, 6
        if arg:
            try:
                left, _, right = arg.lower().partition("d")
                if right:
                    n = max(1, min(int(left or 1), 10))
                    m = max(2, min(int(right), 100))
                else:
                    n = 1
                    m = max(2, min(int(arg), 100))
            except (ValueError, TypeError):
                return "格式：/掷骰子 [数量]d[面数]，例如 /掷骰子 2d6"
        rolls = [random.randint(1, m) for _ in range(n)]
        tail = f"\n合计：{sum(rolls)}" if n > 1 else ""
        return f"🎲 {n}d{m}：{' + '.join(map(str, rolls))}{tail}"

    def _rps(self, arg: str) -> str:
        bot_choice = random.choice(_RPS)
        arg = arg.strip()
        if arg not in _RPS:
            return f"我出：{bot_choice}。再来？你发「/猜拳 石头/剪刀/布」和我比。"
        win = {
            ("石头", "剪刀"): "你赢",
            ("剪刀", "布"): "你赢",
            ("布", "石头"): "你赢",
        }
        if arg == bot_choice:
            res = "平局"
        elif win.get((arg, bot_choice)):
            res = "你赢 🎉"
        else:
            res = "我赢 😎"
        return f"你出 {arg}，我出 {bot_choice} —— {res}"

    async def _idiom(self, word: str, bot) -> str:
        if word:
            if bot.llm.enabled:
                ans = await bot.llm.chat([
                    {"role": "user", "content":
                     f"我们在玩成语接龙。上一个成语是「{word}」，"
                     f"请接一个以「{word[-1]}」字开头的成语，只输出那个成语，"
                     f"不要解释。"}
                ])
                if ans:
                    return f"接龙：「{word}」→ {ans.strip()}"
            return f"「{word}」这个我接不上来～（没开 AI 时接龙需要大模型）"
        pick = random.choice(_IDIOMS)
        return f"成语时间：「{pick}」\n轮到你接以「{pick[-1]}」开头的成语啦～"
