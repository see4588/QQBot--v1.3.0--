"""定时提醒：APScheduler cron 任务，持久化在 SQLite，重启自动恢复。

外部（手机控制台 / scripts）直接改 reminders 表后，这里通过 3 秒轮询
把数据库同步到调度器，因此增删改启停都无需重启机器人进程。
"""
from __future__ import annotations

import asyncio
import logging

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

log = logging.getLogger("qqbot.reminder")

TZ = "Asia/Shanghai"
SYNC_INTERVAL = 3.0


class ReminderService:
    def __init__(self, bot):
        self.bot = bot
        self.scheduler = AsyncIOScheduler(timezone=TZ)
        self._started = False
        self._sync_task: asyncio.Task | None = None
        # id -> (cron, enabled, content)，用于判断是否需要重建 job
        self._sig: dict[int, tuple] = {}

    # ---------- 生命周期 ----------
    def start(self) -> None:
        rows = self.bot.store.list_reminders()
        for row in rows:
            if row["enabled"]:
                self._add_job(row)
            self._sig[row["id"]] = self._sig_of(row)
        self.scheduler.start()
        self._started = True
        try:
            loop = asyncio.get_running_loop()
            self._sync_task = loop.create_task(self._sync_loop())
        except RuntimeError:  # 非事件循环环境（例如本地脚本自检）
            log.warning("未运行在事件循环中，定时任务外部热同步不可用")
        log.info(
            "定时调度器已启动，加载 %s 个任务，热同步已开启",
            len(self.scheduler.get_jobs()),
        )

    def stop(self) -> None:
        if self._sync_task is not None:
            self._sync_task.cancel()
            self._sync_task = None
        if self._started:
            self.scheduler.shutdown(wait=False)
            self._started = False

    # ---------- 同步 ----------
    @staticmethod
    def _sig_of(row: dict) -> tuple:
        return (row["cron"], int(row["enabled"]), row["content"])

    def _job_id(self, rid: int) -> str:
        return f"rem-{rid}"

    def _drop_job(self, rid: int) -> None:
        try:
            self.scheduler.remove_job(self._job_id(rid))
        except Exception:  # noqa: BLE001 - 任务不存在时忽略
            pass

    def sync(self) -> dict:
        """把数据库里的提醒同步到调度器，返回变更统计。"""
        rows = self.bot.store.list_reminders()
        desired = {int(r["id"]): r for r in rows}
        added = updated = removed = 0

        for rid, row in desired.items():
            sig = self._sig_of(row)
            job = self.scheduler.get_job(self._job_id(rid))
            changed = self._sig.get(rid) != sig
            if row["enabled"]:
                if changed or job is None:
                    if self._add_job(row):
                        updated += 1 if changed and job is not None else 0
                        added += 1 if job is None else 0
                    self._sig[rid] = sig
            else:
                if job is not None:
                    self._drop_job(rid)
                    removed += 1
                self._sig[rid] = sig

        for rid in list(self._sig):
            if rid not in desired:
                self._drop_job(rid)
                self._sig.pop(rid, None)
                removed += 1
        return {"added": added, "updated": updated, "removed": removed}

    async def _sync_loop(self) -> None:
        while True:
            await asyncio.sleep(SYNC_INTERVAL)
            try:
                diff = await asyncio.to_thread(self.sync)
                if any(diff.values()):
                    log.info("定时任务已热同步：%s", diff)
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                log.exception("定时任务热同步失败")

    # ---------- 任务 ----------
    def _add_job(self, row: dict) -> bool:
        try:
            trigger = CronTrigger.from_crontab(row["cron"], timezone=TZ)
        except Exception as exc:  # noqa: BLE001
            log.warning("定时任务 #%s 的 cron 无效：%s", row.get("id"), exc)
            return False
        self.scheduler.add_job(
            self._fire,
            trigger,
            args=[row],
            id=self._job_id(row["id"]),
            replace_existing=True,
            misfire_grace_time=300,
            coalesce=True,
            max_instances=1,
        )
        return True

    async def _fire(self, row: dict) -> None:
        log.info("触发定时提醒 #%s：%s", row["id"], row["content"][:40])
        await self.bot.notify.push(
            row["scene"], row["target_id"], f"⏰ {row['content']}"
        )

    # ---------- 机器人指令调用的本地操作 ----------
    def add(
        self, scene: str, target_id: str, cron: str, content: str
    ) -> tuple[bool, str, int | None]:
        try:
            CronTrigger.from_crontab(cron, timezone=TZ)
        except Exception as exc:  # noqa: BLE001
            return False, f"cron 表达式不合法：{exc}", None
        rid = self.bot.store.add_reminder(scene, target_id, cron, content)
        row = {
            "id": rid,
            "scene": scene,
            "target_id": target_id,
            "cron": cron,
            "content": content,
            "enabled": 1,
        }
        if self._started:
            self._add_job(row)
        self._sig[rid] = self._sig_of(row)
        return True, "已添加", rid

    def remove(self, rid: int) -> bool:
        ok = self.bot.store.delete_reminder(rid)
        self._drop_job(rid)
        self._sig.pop(rid, None)
        return ok

    def set_enabled(self, rid: int, enabled: bool) -> bool:
        ok = self.bot.store.set_reminder_enabled(rid, enabled)
        if not ok:
            return False
        if enabled:
            row = next(
                (r for r in self.bot.store.list_reminders() if r["id"] == rid),
                None,
            )
            if row:
                self._add_job(row)
                self._sig[rid] = self._sig_of(row)
        else:
            self._drop_job(rid)
            row = next(
                (r for r in self.bot.store.list_reminders() if r["id"] == rid),
                None,
            )
            if row:
                self._sig[rid] = self._sig_of(row)
        return True
