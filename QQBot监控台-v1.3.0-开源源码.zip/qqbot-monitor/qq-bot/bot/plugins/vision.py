"""识图插件：识别图片（本地 OCR + 可选多模态大模型）。

触发方式：
  · 消息带图片附件（无指令文本时自动识别）
  · /识图 [问题]   /看图 [问题]   /ocr [问题]
识图逻辑：若配置了 OpenAI 兼容的多模态端点（VISION_BASE_URL+KEY），优先用大模型
理解图片；否则（或大模型失败时）用本地 Tesseract OCR 提取图中文字。
"""
from __future__ import annotations

import io
import logging

from ..caps import enabled
from ..events import IncomingMessage

log = logging.getLogger("qqbot.vision")

COMMANDS = {"识图", "看图", "ocr", "识别", "describe"}


class VisionPlugin:
    CAP = "vision"

    def __init__(self, bot):
        self.bot = bot

    # ---------- 指令入口（由 commands.py 二级分发调用） ----------
    async def command(self, cmd: str, arg: str, msg: IncomingMessage, bot) -> str | None:
        if cmd not in COMMANDS:
            return None
        return await self._describe(msg, bot, arg.strip() or None)

    # ---------- 附件自动识别（在插件链中先于 AI 聊天） ----------
    async def handle(self, msg: IncomingMessage, bot) -> str | None:
        if not enabled("vision", True):
            return None
        if not msg.images:
            return None
        # 纯文本指令（/识图 等）交给 command() 处理，这里只处理「无指令的图片」
        text = msg.content.strip()
        if text and not text.startswith("/"):
            # 带说明文字的图片：把文字当作提问
            return await self._describe(msg, bot, text)
        if text.startswith("/"):
            return None
        return await self._describe(msg, bot, None)

    # ---------- 核心 ----------
    async def _describe(
        self, msg: IncomingMessage, bot, question: str | None
    ) -> str:
        if not msg.images:
            return "请把要识别的图片发给我（直接发图，或配合 /识图 使用）。"
        img = msg.images[0]
        try:
            data = await bot.api.fetch_attachment(img["url"])
        except Exception as exc:  # noqa: BLE001
            log.warning("下载图片失败：%s", exc)
            data = None
        if not data:
            return "图片下载失败了，可能是链接过期或没权限，稍后再试试。"

        prompt = question or "请描述这张图片里的主要内容。"
        # 1) 多模态大模型优先
        vision_text = None
        if bot.llm.vision_enabled:
            vision_text = await bot.llm.vision(prompt, data, "image/jpeg")
        if vision_text:
            return f"【看图】{vision_text}"

        # 2) 本地 OCR 兜底
        if bot.cfg.vision_use_ocr:
            ocr = _ocr(data)
            if ocr:
                head = f"问题：{question}\n" if question else ""
                return head + "【图片中的文字】\n" + ocr
            return (
                "我暂时没法「看懂」这张图（没有配置视觉模型）。\n"
                "已在手机控制台「插件」里开启 OCR 后，至少能识别图中的文字；"
                "若想看图说话，可配置一个 OpenAI 兼容的多模态接口。"
            )
        return "图片识别未启用（OCR 与视觉模型均关闭）。"


def _ocr(data: bytes) -> str:
    """用本地 Tesseract 做中英文 OCR；未安装则返回空串。"""
    try:
        from PIL import Image
        import pytesseract
    except Exception as exc:  # noqa: BLE001
        log.warning("OCR 依赖缺失（pillow/pytesseract）：%s", exc)
        return ""
    try:
        img = Image.open(io.BytesIO(data))
        text = pytesseract.image_to_string(img, lang="chi_sim+eng")
        text = "\n".join(line.strip() for line in text.splitlines() if line.strip())
        return text[:800]
    except Exception as exc:  # noqa: BLE001
        log.warning("OCR 执行失败：%s", exc)
        return ""
