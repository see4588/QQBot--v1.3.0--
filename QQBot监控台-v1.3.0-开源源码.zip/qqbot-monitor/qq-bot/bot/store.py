"""SQLite 持久化：消息去重、会话上下文、待发通知、定时提醒。

数据量很小，这里使用同步 sqlite3（check_same_thread=False）。机器人并发量低，
同步调用对事件循环的影响可忽略，换来的是零额外依赖和更少的出错面。
"""
from __future__ import annotations

import logging
import sqlite3
import time
from pathlib import Path
from typing import Any

log = logging.getLogger("qqbot.store")

SCHEMA = """
CREATE TABLE IF NOT EXISTS seen (
    msg_id TEXT PRIMARY KEY,
    ts REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scene TEXT NOT NULL,
    target_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    ts REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_chat ON chat_history(scene, target_id, id);
CREATE TABLE IF NOT EXISTS pending_notice (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scene TEXT NOT NULL,
    target_id TEXT NOT NULL,
    content TEXT NOT NULL,
    ts REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_pending ON pending_notice(scene, target_id);
CREATE TABLE IF NOT EXISTS reminders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scene TEXT NOT NULL,
    target_id TEXT NOT NULL,
    content TEXT NOT NULL,
    cron TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS points (
    scene TEXT NOT NULL,
    target_id TEXT NOT NULL,
    balance INTEGER NOT NULL DEFAULT 0,
    total INTEGER NOT NULL DEFAULT 0,
    streak INTEGER NOT NULL DEFAULT 0,
    last_checkin TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (scene, target_id)
);
"""


class Store:
    def __init__(self, path: str):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()
        log.info("数据库已就绪：%s", path)

    # ---------- 去重 ----------
    def is_duplicate(self, msg_id: str) -> bool:
        """同一 msg_id 平台可能重复推送；返回 True 表示已处理过。"""
        if not msg_id:
            return False
        cur = self.conn.execute(
            "INSERT OR IGNORE INTO seen(msg_id, ts) VALUES(?, ?)",
            (msg_id, time.time()),
        )
        self.conn.commit()
        return cur.rowcount == 0

    # ---------- 会话上下文 ----------
    def add_history(self, scene: str, target_id: str, role: str, content: str) -> None:
        with self.conn:
            self.conn.execute(
                "INSERT INTO chat_history(scene,target_id,role,content,ts) "
                "VALUES(?,?,?,?,?)",
                (scene, target_id, role, content, time.time()),
            )

    def get_history(self, scene: str, target_id: str, limit: int) -> list[dict]:
        rows = self.conn.execute(
            "SELECT role, content FROM chat_history "
            "WHERE scene=? AND target_id=? ORDER BY id DESC LIMIT ?",
            (scene, target_id, limit),
        ).fetchall()
        return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]

    def clear_history(self, scene: str, target_id: str) -> None:
        with self.conn:
            self.conn.execute(
                "DELETE FROM chat_history WHERE scene=? AND target_id=?",
                (scene, target_id),
            )

    def known_targets(self) -> list[tuple[str, str]]:
        rows = self.conn.execute(
            "SELECT DISTINCT scene, target_id FROM chat_history"
        ).fetchall()
        return [(r["scene"], r["target_id"]) for r in rows]

    # ---------- 待发通知 ----------
    def add_pending(self, scene: str, target_id: str, content: str) -> None:
        with self.conn:
            self.conn.execute(
                "INSERT INTO pending_notice(scene,target_id,content,ts) VALUES(?,?,?,?)",
                (scene, target_id, content, time.time()),
            )

    def pop_pending(self, scene: str, target_id: str, limit: int) -> list[str]:
        rows = self.conn.execute(
            "SELECT id, content FROM pending_notice "
            "WHERE scene=? AND target_id=? ORDER BY id ASC LIMIT ?",
            (scene, target_id, limit),
        ).fetchall()
        if not rows:
            return []
        ids = [r["id"] for r in rows]
        with self.conn:
            self.conn.execute(
                "DELETE FROM pending_notice WHERE id IN (%s)"
                % ",".join("?" * len(ids)),
                ids,
            )
        return [r["content"] for r in rows]

    def count_pending(self) -> int:
        return int(
            self.conn.execute("SELECT COUNT(*) FROM pending_notice").fetchone()[0]
        )

    # ---------- 定时提醒 ----------
    def add_reminder(
        self, scene: str, target_id: str, cron: str, content: str
    ) -> int:
        cur = self.conn.execute(
            "INSERT INTO reminders(scene,target_id,content,cron,enabled,created_at) "
            "VALUES(?,?,?,?,1,?)",
            (scene, target_id, content, cron, time.time()),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def list_reminders(self, enabled_only: bool = False) -> list[dict[str, Any]]:
        sql = "SELECT * FROM reminders"
        if enabled_only:
            sql += " WHERE enabled=1"
        sql += " ORDER BY id ASC"
        return [dict(r) for r in self.conn.execute(sql).fetchall()]

    def delete_reminder(self, rid: int) -> bool:
        with self.conn:
            cur = self.conn.execute("DELETE FROM reminders WHERE id=?", (rid,))
        return cur.rowcount > 0

    def set_reminder_enabled(self, rid: int, enabled: bool) -> bool:
        with self.conn:
            cur = self.conn.execute(
                "UPDATE reminders SET enabled=? WHERE id=?",
                (1 if enabled else 0, rid),
            )
        return cur.rowcount > 0

    # ---------- 积分 / 签到 ----------
    def _ensure_points(self, scene: str, target_id: str) -> None:
        with self.conn:
            self.conn.execute(
                "INSERT OR IGNORE INTO points(scene,target_id,balance,total,"
                "streak,last_checkin) VALUES(?,?,0,0,0,'')",
                (scene, target_id),
            )

    def get_points(self, scene: str, target_id: str) -> dict:
        self._ensure_points(scene, target_id)
        r = self.conn.execute(
            "SELECT balance,total,streak,last_checkin FROM points "
            "WHERE scene=? AND target_id=?",
            (scene, target_id),
        ).fetchone()
        return {
            "balance": int(r["balance"]),
            "total": int(r["total"]),
            "streak": int(r["streak"]),
            "last_checkin": r["last_checkin"] or "",
        }

    def add_points(self, scene: str, target_id: str, delta: int) -> dict:
        self._ensure_points(scene, target_id)
        with self.conn:
            self.conn.execute(
                "UPDATE points SET balance=balance+?, total=total+? "
                "WHERE scene=? AND target_id=?",
                (delta, delta, scene, target_id),
            )
        return self.get_points(scene, target_id)

    def checkin(self, scene: str, target_id: str) -> tuple[bool, int, int, int]:
        """返回 (是否已签到, 本次获得, 连续天数, 当前余额)。"""
        self._ensure_points(scene, target_id)
        today = time.strftime("%Y-%m-%d", time.localtime())
        row = self.conn.execute(
            "SELECT streak,last_checkin,balance,total FROM points "
            "WHERE scene=? AND target_id=?",
            (scene, target_id),
        ).fetchone()
        streak, last, bal, total = (
            int(row["streak"]), row["last_checkin"] or "",
            int(row["balance"]), int(row["total"]),
        )
        if last == today:
            return True, 0, streak, bal
        yesterday = time.strftime(
            "%Y-%m-%d", time.localtime(time.time() - 86400)
        )
        new_streak = (streak + 1) if last == yesterday else 1
        gain = 5 + min(new_streak, 20)  # 连续天数加成，最多 +20
        with self.conn:
            self.conn.execute(
                "UPDATE points SET balance=balance+?, total=total+?, "
                "streak=?, last_checkin=? WHERE scene=? AND target_id=?",
                (gain, gain, new_streak, today, scene, target_id),
            )
        return False, gain, new_streak, bal + gain

    def transfer_points(
        self, src: tuple[str, str], dst: tuple[str, str], amount: int
    ) -> tuple[bool, str]:
        if amount <= 0:
            return False, "积分必须为正整数"
        s = self.get_points(*src)
        if s["balance"] < amount:
            return False, f"你的余额只有 {s['balance']} 积分，不够转"
        with self.conn:
            self.conn.execute(
                "UPDATE points SET balance=balance-?, total=total-? "
                "WHERE scene=? AND target_id=?",
                (amount, amount, *src),
            )
            self._ensure_points(*dst)
            self.conn.execute(
                "UPDATE points SET balance=balance+?, total=total+? "
                "WHERE scene=? AND target_id=?",
                (amount, amount, *dst),
            )
        return True, f"已转给对方 {amount} 积分"

    def top_points(self, limit: int = 10) -> list[dict]:
        rows = self.conn.execute(
            "SELECT scene,target_id,balance,total,streak FROM points "
            "ORDER BY balance DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]

    # ---------- 维护 ----------
    def cleanup(self, days: int = 7) -> None:
        cutoff = time.time() - days * 86400
        with self.conn:
            self.conn.execute("DELETE FROM seen WHERE ts < ?", (cutoff,))
            self.conn.execute("DELETE FROM chat_history WHERE ts < ?", (cutoff,))
        log.info("已清理 %s 天前的历史数据", days)

    def close(self) -> None:
        self.conn.close()
