# QQ 官方机器人 · 完整工程

基于 **QQ 开放平台官方 API（WebSocket 长连接）** 的机器人，不依赖任何第三方协议端，**无封号风险**。纯 Python 实现，只依赖 `aiohttp` + `apscheduler`。

## 功能

| 能力 | 说明 |
|---|---|
| AI 聊天 / 智能问答 | 接入任意 OpenAI 兼容大模型，带多轮会话上下文；未配密钥时自动降级为指令提示 |
| 群管理 | 入群自动欢迎、关键词自动回复、禁言 / 解禁、撤回消息（管理员权限） |
| 通知推送 | `/通知`、`/广播`、命令行 `scripts/notify.py`、外部 crontab 均可触发 |
| 定时提醒 | cron 表达式，持久化到 SQLite，重启自动恢复 |
| 待发队列 | 主动消息被平台拒绝时自动入队，下次有人发言时借被动回复带出，保证消息最终可见 |
| 高可用 | 心跳保活、断线重连、会话恢复（RESUME）、access_token 自动刷新、消息去重 |

## 为什么不需要域名 / SSL / 入站端口

WebSocket 模式下，是**机器人主动外连** `wss://api.bot.qq.com/websocket/`，QQ 不回调你的服务器。因此不需要公网域名、备案、SSL 证书、反向代理，也不用放行任何入站端口（云安全组入站保持原样即可）。项目自带的 `8080` 只是本机健康检查，绑定 `127.0.0.1`，外部访问不到。

---

## 一、前置条件（必须你本人操作，约 5 分钟）

1. 打开 [QQ 开放平台](https://q.qq.com/) 用手机 QQ 扫码注册，完成主体认证（个人入口即可）。
2. 创建机器人，拿到 **AppID** 和 **AppSecret**，填入 `.env`。
3. 在「开发设置 → 事件订阅」勾选 **群聊/单聊消息事件**（对应 `GROUP_AND_C2C_EVENT = 1<<25`）。没勾选会出现 `4014 intent 无权限`。
4. 沙箱调试阶段：在「沙箱配置」里把测试群 / 测试成员加进白名单，并把 `.env` 里 `QQ_SANDBOX=true`（此时连 `api.sgroup.qq.com`）。机器人发布上线后改回 `false`。
5. 把机器人加进群（群设置里添加机器人），或直接与机器人单聊。群聊需要 **@机器人** 才会触发 `GROUP_AT_MESSAGE_CREATE`。

> 一个 QQ 号最多创建 5 个机器人。官方平台没有「群列表 / 好友列表」接口，`group_openid` / `user_openid` 只能从收到的消息事件里获得，可在日志里查看。

---

## 当前部署状态（2026-11-13，已完成部署）

这台服务器已经部署完毕，**不需要再执行下面的「快速开始」**：

| 项 | 值 |
|---|---|
| 服务器 | `你的服务器公网IP或域名`（Ubuntu 24.04 / Python 3.12 / 2G 内存 / 40G 磁盘） |
| 部署路径 | `/opt/qqbot` |
| 运行方式 | venv + systemd 服务 `qqbot`（`active` + `enabled`，开机自启、崩溃自动重启） |
| 连接状态 | 已 `IDENTIFY` → `READY`，心跳保活中 |
| 接入环境 | **沙箱** `https://api.sgroup.qq.com`（`/gateway` 返回沙箱域名，说明机器人尚未发布上线） |
| 健康检查 | `curl http://127.0.0.1:8080/healthz` → `{"status":"ok","ai":true}` |
| 日志 | `/opt/qqbot/logs/bot.log`、`journalctl -u qqbot -f` |
| AI 聊天 | **已启用**：DeepSeek `deepseek-flash`，带多轮上下文；`/帮助` 等指令仍优先、不消耗 AI |
| 凭据 | 已写入 `/opt/qqbot/.env`，权限 `600`（QQ 凭据 + 大模型 Key） |

服务器上常用命令：

```bash
cd /opt/qqbot
bash deploy.sh status          # 状态
bash deploy.sh logs            # 实时日志
bash deploy.sh restart         # 改完 .env 后重启
venv/bin/python scripts/check_api.py   # 凭据 / 网关连通性自检
```

### AI 大模型（已配置并验证）

`/opt/qqbot/.env` 中已写入（Key 仅在服务器上，不随工程包分发）：

```ini
LLM_API_KEY=<DeepSeek Key，见服务器 .env>
LLM_BASE_URL=https://api.deepseek.com/v1
LLM_MODEL=deepseek-flash
LLM_TIMEOUT=60
HISTORY_LIMIT=12
```

- 已实测：Key 有效（HTTP 200）、端到端「私聊消息 → 大模型 → 回复」跑通，服务日志显示 `服务就绪：AI=启用`，监控台「AI 聊天」显示「已启用」。
- DeepSeek 当前可用模型：`deepseek-flash`（快、便宜，聊天推荐）、`deepseek-v4-pro`（更强，响应更慢）；`deepseek-chat` 为兼容别名，当前指向 flash。
- 换模型：改 `LLM_MODEL` 后 `bash deploy.sh restart` 即可。
- 私聊直接发文字就走 AI；群聊需 **@机器人**；以 `/` 开头的指令优先，不会调用大模型。

### 人格定制（在手机 App 里改，无需重启）

`LLMClient.chat()` 每次对话前都会重读 `<工程目录>/persona.json`（默认 `/opt/qqbot/persona.json`）：

```json
{
  "name": "猫娘喵喵",
  "prompt": "你是一只活泼的猫娘，每句话结尾都要带喵…",
  "updated_at": "2026-11-13T17:10:34"
}
```

- 文件存在且 `prompt` 非空时优先使用；不存在、为空或解析失败时回退到 `.env` 的 `LLM_SYSTEM_PROMPT`
- 可用 `PERSONA_PATH` 环境变量改路径
- 监控台「AI 人格」面板会**原子写入**（`os.replace` + 权限 `600`）这个文件，因此换人格**不用重启 `qqbot`、不会断线**
- 该文件由监控服务管理，操作记入审计日志；详见 `server-monitor/README.md` 第九节

### 关键词 / 定时提醒（手机 App 里改，同样无需重启）

手机控制台的「自动化」页面能直接管理这两项，机器人侧已改为热生效：

- **关键词**：`<工程目录>/keywords.json`（默认 `/opt/qqbot/keywords.json`）。`CommandPlugin` 每条消息按**文件内容**比对热读，文件不存在或解析失败时回退 `.env` 的 `KEYWORD_RULES`。App 里增删后**下一条消息**即生效。
- **定时提醒**：`bot.db` 的 `reminders` 表。`ReminderService` 启动时加载已启用任务，并每 3 秒轮询一次，把外部的增删改启停同步到 APScheduler；日志会打印 `定时任务已热同步`。
- QQ 里的 `/关键词`、`/提醒 添加|删除|暂停|恢复` 指令仍可用，两边写的是同一份文件 / 同一张表，不会冲突。
- 当前示例人格为 **朽叶千咲（《鸣潮》）**，仅用于演示配置格式、与游戏官方无关，可随时替换；完整设定见 `server-monitor/persona-chisa.md`。

### 你还需要做 2 件事

1. **让机器人收到消息**：当前是沙箱环境，到 QQ 开放平台「沙箱配置」把测试 QQ 号和测试群加入白名单，再把机器人加进群；群聊必须 **@机器人**。机器人发布上线后，把 `.env` 里 `QQ_SANDBOX` 改回 `false` 并重启。
2. **妥善保管凭据**：AppSecret、服务器 root 密码、监控台 Token 与大模型 API Key 只保存在服务器 `.env` / `config.json` 中，切勿写入代码仓库或公开文档；建议 root 改用 SSH 密钥登录。换 Key 后改 `.env` 并 `bash deploy.sh restart`。

---

## 二、快速开始（迁移到新服务器时用，3 步）

```bash
# 1. 上传整个目录到服务器（或用宝塔「文件」上传 zip 后解压）
scp -r qq-bot root@<你的公网IP>:/opt/qqbot

# 2. 编辑配置
cd /opt/qqbot && nano .env      # 填 QQ_APP_ID / QQ_APP_SECRET / 可选 LLM_API_KEY

# 3. 一键部署（自动选 Docker / systemd / venv，并配置开机自启）
bash deploy.sh start
bash deploy.sh status
bash deploy.sh logs
```

`deploy.sh` 会自动：创建 venv → 安装依赖 → 写 systemd 服务（或起 Docker 容器）→ 开机自启 + 崩溃自动重启 → 修正数据/日志路径。

运维命令：`bash deploy.sh [start|stop|restart|status|logs]`。可强制指定方式：`MODE=docker|systemd|venv bash deploy.sh start`。

---

## 三、宝塔面板部署（三种方式任选）

> 宝塔只是服务器管理面板，不影响运行 Python 进程。WebSocket 外连模式**不需要建站点、不需要域名、不需要反向代理**。

### 方式 A：Docker 管理器（推荐）

1. 软件商店安装 **Docker** 插件。
2. 「文件」上传工程到 `/www/wwwroot/qqbot`，确保 `.env` 已填好。
3. 终端执行 `cd /www/wwwroot/qqbot && bash deploy.sh start`（脚本检测到 Docker 会自动 `docker compose up -d --build`）。
4. 在 Docker 管理器里看容器状态与日志。`restart: unless-stopped` 已配置，开机自启、崩溃自动拉起。

### 方式 B：Supervisor 管理器（最轻量）

1. 软件商店安装 **Supervisor 管理器**。
2. 终端执行：
   ```bash
   cd /www/wwwroot/qqbot
   python3 -m venv venv
   venv/bin/pip install -r requirements.txt
   ```
3. 面板里「添加守护进程」，把 `supervisor.conf.example` 的内容粘进去（把路径改成你的实际目录），启动用户 `root`，勾选开机自启。
4. 面板里直接看日志、重启。

### 方式 C：Python 项目管理器

上传代码 → 创建项目 → 选 Python 3.10+ → 安装 `requirements.txt` → 启动命令 `python -m bot.main`。注意它默认把项目当 Web 应用要端口和域名，对纯后台进程略绕，建议改用 A 或 B。

### 宝塔注意事项

- **密钥安全**：`.env` 放项目目录，权限 `600`，**不要放进网站根目录 / 静态可访问目录**，不要提交 git。
- **端口**：不用放行入站端口；宝塔自己占 888 / 8888 / 80 / 443，健康检查默认用 8080，冲突就在 `.env` 改 `HEALTH_PORT` 或设 `HEALTH_ENABLED=false`。
- 如果改用 **WebHook 回调**接入（本工程未启用），才需要域名 + SSL + 反向代理 + 放行 443。
- 日志：面板里看容器/进程日志，另有一份 `logs/bot.log`。
- 建议用 venv 隔离依赖，别 `pip install` 到系统 Python（宝塔自身依赖系统环境）。

---

## 四、配置项（.env）

| 变量 | 默认 | 说明 |
|---|---|---|
| `QQ_APP_ID` / `QQ_APP_SECRET` | 空 | **必填**，开放平台凭据 |
| `QQ_SANDBOX` | `false` | true 连沙箱 `api.sgroup.qq.com` |
| `QQ_API_BASE` | 自动 | 可手动覆盖 API 域名 |
| `QQ_INTENTS` | `33554432` | `1<<25`，群+单聊事件；报 4014 说明未开通 |
| `LLM_API_KEY` | 空 | 任意 OpenAI 兼容服务；留空则 AI 聊天降级 |
| `LLM_BASE_URL` | `https://api.openai.com/v1` | 国内可换 `https://api.deepseek.com/v1` |
| `LLM_MODEL` | `gpt-4o-mini` | 模型名，如 `deepseek-chat` |
| `BOT_ADMIN_OPENIDS` | 空 | 管理员 openid，逗号分隔；群主/管理员自动识别 |
| `KEYWORD_RULES` | 见模板 | JSON 对象，消息「包含」关键词即回复 |
| `WELCOME_TEXT` | 见模板 | 入群欢迎语，支持 `{name}` 占位 |
| `HEALTH_ENABLED` / `HEALTH_PORT` | `true` / `8080` | 本机健康检查 `curl http://127.0.0.1:8080/healthz` |

---

## 五、指令列表

| 指令 | 权限 | 说明 |
|---|---|---|
| `/帮助` | 所有人 | 指令菜单 |
| `/状态` | 所有人 | 运行时长、AI 状态、任务数、待发通知数 |
| `/清空` | 所有人 | 清空当前会话上下文 |
| `/关键词` | 所有人 | 查看关键词规则 |
| `/通知 <内容>` | 管理员 | 向当前会话推送 |
| `/广播 <内容>` | 管理员 | 向所有已知会话推送 |
| `/提醒 列表` | 所有人 | 查看定时任务 |
| `/提醒 添加 <cron> :: <内容>` | 管理员 | 如 `/提醒 添加 0 9 * * * :: 早上好，记得打卡` |
| `/提醒 删除 / 暂停 / 恢复 <id>` | 管理员 | 管理定时任务 |
| `/禁言 <分钟> @成员` | 管理员（群） | 也可直接给 member_openid |
| `/解禁 <openid>` | 管理员（群） | 解除禁言 |
| `/撤回` | 管理员（群） | 撤回触发的那条消息（2 分钟内） |

其他消息交给 AI 聊天；群聊须 @机器人。

命令行推送（可挂 crontab）：
```bash
venv/bin/python scripts/notify.py --scene group --target <group_openid> --text "今晚 8 点维护"
```

---

## 六、主动消息限制与「待发队列」（重要）

官方机器人对**主动消息**（非被动回复）有权限与频控限制，且没有群列表接口，定时提醒 / 广播**不保证即时送达**。典型错误码：`40034105`（无权限）、`40034100`（超频控）、`304064`（未授权订阅）。

本工程的处理方式：

1. 定时提醒 / 广播触发时先尝试主动发送；
2. 失败则把消息写入 SQLite 的 `pending_notice` 表；
3. 该会话下次有人发言时，借**被动回复**机会把最多 3 条积压通知一起带出（被动回复群聊 5 分钟内最多 5 次、单聊 60 分钟内最多 4 次，本项目每次只回 1 条）。

想提高主动消息送达率：在开放平台申请主动消息权限 / 让群管理员在机器人资料页开启通知，并引导用户先与机器人互动。

---

## 七、日常运维

```bash
bash deploy.sh status                  # 状态
bash deploy.sh logs                    # 实时日志
bash deploy.sh restart                 # 重启
systemctl status qqbot                 # systemd 原生状态（systemd 模式）
curl http://127.0.0.1:8080/healthz     # 健康检查
sqlite3 data/bot.db "SELECT * FROM reminders;"   # 查看定时任务
```

备份：直接打包 `data/bot.db`（含定时任务、会话、待发通知）与 `.env`。

---

## 八、故障排查

| 现象 | 原因与处理 |
|---|---|
| `4013 / 4014 intent 无权限` | 开放平台「事件订阅」没勾选对应事件；或把 `QQ_INTENTS` 调回 `33554432` |
| `4914 机器人已下架 / 4915 已封禁` | 调试期请先设 `QQ_SANDBOX=true` 连沙箱；正式需发布上线 |
| `获取 access_token 失败` | AppID / AppSecret 填错，或用了已弃用的 Token；检查 `.env` |
| `机器人不回消息` | 群聊必须 @机器人；确认机器人已进群；`bash deploy.sh logs` 看是否收到事件 |
| `主动消息发不出去` | 见第六节，属平台限制，消息会进待发队列而非丢失 |
| `禁言 / 撤回失败 40062003` | 机器人需要是该群管理员，且只能操作普通成员 |
| `回复被去重 40054005` | 同一 `msg_id` 的 `msg_seq` 重复；本项目已自动递增，正常不会触发 |
| `健康检查端口占用` | 改 `HEALTH_PORT` 或 `HEALTH_ENABLED=false` |

---

## 九、安全建议

- **密钥不要写入代码仓库或公开文档**。若怀疑泄露，请立即到 QQ 开放平台**重置 AppSecret**，并修改服务器 root 密码 / 改用 SSH 密钥登录。
- `.env` 权限 `600`，不要提交 git（已在 `.gitignore` 排除）。
- 机器人建议用专门的小号创建，别用主号。
- 服务器只放行必要端口；WebSocket 模式不需要开新入站端口。

---

## 十、目录结构

```
qq-bot/
├── bot/
│   ├── config.py        配置加载（.env / 环境变量）
│   ├── api.py           官方 API：鉴权、发消息、禁言、撤回
│   ├── gateway.py       WebSocket：IDENTIFY / 心跳 / RESUME / 重连
│   ├── events.py        事件名、intents、入站消息结构
│   ├── dispatcher.py    事件分发、插件装配、回复与待发通知合并
│   ├── store.py         SQLite：去重、上下文、待发队列、定时提醒
│   ├── llm.py           OpenAI 兼容大模型客户端
│   ├── plugins/         指令、AI 聊天、群管理、通知、定时提醒
│   └── main.py          入口 + 健康检查端点
├── scripts/
│   ├── notify.py        命令行推送
│   └── mock_test.py     本地模拟自测（不连 QQ）
├── deploy.sh            一键部署 / 运维
├── Dockerfile / docker-compose.yml
├── supervisor.conf.example
└── .env.example / .env
```

参考文档：[QQ 机器人官方文档](https://bot.q.qq.com/wiki/develop/api-v2/) · [WebSocket 接入](https://bot.qq.com/wiki/develop/api-v2/dev-prepare/event-emit/websocket.html) · [发送群聊消息](https://bot.q.qq.com/wiki/develop/api-v2/autogen/api/v2_groups_group_openid_messages.post.html)


## 附录：手机控制台全量设置（v1.1.0）

- `bot/caps.py`：热读项目根目录 `capabilities.json`，控制 AI 聊天、关键词、指令、欢迎语、
  待发通知带出、定时提醒、群管理指令、消息去重 8 个开关；手机端保存即生效，无需重启。
- `bot/config.py` 的 `.env` 解析升级为支持 JSON 双引号包裹（含转义），因此手机端可以安全写入
  含空格、引号、井号的欢迎语与关键词 JSON。
- 监控台通过 `POST /api/settings` 改写 `.env`（自动备份 + 校验 + 可选重启），
  `/opt/monitor/backups/` 保留最近 12 份，可一键回滚。


## v1.2.0 插件（看图 / 签到 / 娱乐 / 工具）
- `bot/plugins/vision.py`：图片识别。附件下载走 `QQApi.fetch_attachment`（带机器人 token）；
  多模态走 `LLMClient.vision`（OpenAI 兼容）；本地 OCR 走 Tesseract（服务器已装 chi_sim）。
  `events.IncomingMessage.images` 提供图片附件解析。
- `bot/plugins/checkin.py`：`bot/store.py` 新增 `points` 表（余额/累计/连续/末次签到）。
- `bot/plugins/fun.py`、`bot/plugins/tools.py`：娱乐与工具指令。
- `bot/dispatcher.py` 的 `dispatch_feature_command` 实现指令二级分发，未收录指令交给扩展插件；
  `capabilities.json` 新增 `vision / checkin / fun / tools` 四个热生效开关。
