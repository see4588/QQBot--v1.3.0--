# QQBot 监控台（QQBot Monitor）

> 一个可自托管的 **QQ 官方机器人 + 手机网页控制台 + 安卓原生客户端** 完整方案。
> 机器人负责聊天与插件，控制台负责在手机上配置、监控与管理，安卓端把控制台装进一个原生壳。

![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Python](https://img.shields.io/badge/python-3.10%2B-blue.svg)
![Android](https://img.shields.io/badge/android-minSdk%2024-green.svg)

**当前版本：v1.3.0** · 更新记录见 [CHANGELOG.md](CHANGELOG.md)

---

## ✨ 功能一览

**机器人（`qq-bot/`）**
- WebSocket 网关接入 QQ 官方机器人 API v2，支持群聊 @ 与私聊
- AI 聊天：任意 OpenAI 兼容接口（DeepSeek 等），支持自定义人格、上下文历史
- 插件化架构，内置 5 类能力：识图、签到积分、娱乐、实用工具、AI 语音
- 关键词回复、定时提醒、欢迎语、群管理、消息去重、待发带出
- 配置热更新：能力开关写入 `capabilities.json`，保存即生效，无需重启

**手机控制台（`server-monitor/`）**
- PWA 单页应用，浅色设计系统，可「添加到主屏幕」当 App 用
- **42 项配置**在线编辑（7 个分组）、**13 个能力开关**、**5 个插件卡片**、**26 条指令**中心
- AI 人格编辑、官方平台接口调用、聊天历史、运行日志、服务启停、配置备份与回滚
- `X-Token` 鉴权；密钥字段只返回 `__SET__` 占位符与掩码，不回传明文

**安卓客户端（`qqbot-monitor-app/`）**
- 零第三方依赖的 WebView 壳，可在本机填写服务器地址与 Token
- 一条命令构建带 v1+v2 签名的 APK，不依赖 Gradle / Android Studio

---

## 🏗 架构

```mermaid
flowchart LR
    U[QQ 用户 / 群] -->|消息事件| GW[QQ 官方网关]
    GW <-->|WebSocket| BOT[QQBot 核心<br/>qq-bot]
    BOT --> LLM[大模型 API]
    BOT --> TTS[BreezeBlue TTS]
    BOT --> DB[(SQLite)]
    WEB[手机浏览器 / PWA] -->|HTTP + X-Token| MON[控制台后端<br/>server-monitor]
    APP[安卓 App<br/>WebView] -->|HTTP| MON
    MON -->|读写 .env / capabilities.json| BOT
    MON -->|systemctl| SYS[systemd 服务]
```

三个子工程通过**文件**解耦：控制台修改 `.env` / `capabilities.json` / 人格 JSON，机器人热读这些文件；控制台通过 systemd 管理服务启停。因此你可以只部署机器人，或只跑控制台。

---

## 🚀 快速开始

### 准备

- 一台有公网 IP 的 Linux 服务器（Ubuntu 22.04 验证通过），Python 3.10+、systemd
- QQ 开放平台创建的机器人：AppID、AppSecret（沙箱环境请先在「沙箱配置」加白名单）
- 一个 OpenAI 兼容的大模型 API Key（可选，用于 AI 聊天）

### 1. 部署机器人

```bash
cd qq-bot
cp .env.example .env
vim .env                      # 填入 QQ_APP_ID / QQ_APP_SECRET / LLM_API_KEY
bash deploy.sh start          # 自动识别 docker / systemd / venv
bash deploy.sh logs           # 看到网关 READY 即成功
```

### 2. 部署控制台

```bash
cd server-monitor
cp config.json.example config.json
bash deploy.sh start          # 首次启动会打印访问 Token
bash deploy.sh token          # 之后随时查看
bash deploy.sh token --reset  # 一键轮换（旧 Token 立即作废）
```

浏览器打开 `http://<你的服务器地址>/`，填入访问 Token 即可进入。手机浏览器「添加到主屏幕」可获得全屏 PWA。

> 默认监听 80 端口。若被占用，改 `config.json` 的 `port`、放行安全组，并在控制台 ⚙ 里同步改服务器地址。

### 3.（可选）构建安卓 APK

仓库不含预编译 APK（它内嵌你的服务器地址）。请先改默认地址，再构建：

```bash
# 编辑 qqbot-monitor-app/java/com/qqbot/monitor/MainActivity.java 里的 DEFAULT_URL
ANDROID_SDK=/path/to/android-sdk bash qqbot-monitor-app/build.sh
# 产物：qqbot-monitor-app/dist/QQBotMonitor-v1.3.0.apk
```

构建脚本首次会**随机生成**签名密码并保存到 `keystore/.ks_pass`（已加入 `.gitignore`）。请离线备份整个 `keystore/` 目录——丢失后用户将无法覆盖安装新版。把 APK 放到 `server-monitor/app/`，并同步 `download.html` 与 `server.py` 的版本/SHA 即可提供下载页。

---

## 📁 目录结构

```
.
├── LICENSE                  # MIT
├── README.md                # 本文件
├── CONTRIBUTING.md          # 贡献指南与改动契约
├── CHANGELOG.md             # 版本记录
├── SECURITY.md              # 安全策略与加固清单
├── CODE_OF_CONDUCT.md       # 社区行为准则
├── .gitignore
├── qq-bot/                  # 机器人
│   ├── bot/                 # gateway / dispatcher / plugins / config / store / llm / api / tts
│   ├── .env.example         # ⚠️ 复制为 .env 后填入自己的凭据
│   ├── deploy.sh            # 一键部署
│   ├── Dockerfile / docker-compose.yml / supervisor.conf.example
│   └── scripts/             # 自检与通知脚本
├── server-monitor/          # 控制台
│   ├── index.html           # 单文件 PWA（含设置中心全部子页）
│   ├── server.py            # aiohttp 后端与 API
│   ├── ext_settings.py      # 配置 schema / 能力开关 / 插件 / 指令定义
│   ├── config.json.example  # ⚠️ 复制为 config.json
│   ├── persona-chisa.*      # 示例人格（可替换）
│   ├── deploy.sh / monitor.service.example
│   └── download.html / sw.js / manifest.webmanifest / icons
└── qqbot-monitor-app/       # 安卓客户端
    ├── AndroidManifest.xml
    ├── java/com/qqbot/monitor/MainActivity.java
    ├── res/                 # 图标与样式
    └── build.sh             # 一键构建签名 APK
```

---

## ⚙️ 关键配置

所有配置都能在控制台的设置页里改，无需手动编辑文件。常用环境变量：

| 变量 | 说明 |
| --- | --- |
| `QQ_APP_ID` / `QQ_APP_SECRET` | QQ 开放平台机器人凭据 |
| `QQ_SANDBOX` | `true` 走沙箱网关，上线后改 `false` |
| `LLM_API_KEY` / `LLM_BASE_URL` / `LLM_MODEL` | OpenAI 兼容大模型接入 |
| `VISION_ENABLED` / `VISION_USE_OCR` / `VISION_*` | 识图：多模态 Vision 或本地 Tesseract OCR |
| `TTS_ENABLED` / `TTS_API_KEY` / `TTS_VOICE_ID` | AI 语音（BreezeBlue），**音色 ID 必填** |
| `TTS_INSTRUCTIONS` / `TTS_GUIDANCE_SCALE` | 语气引导文本与遵循强度（推荐 4.0） |
| `TTS_MAX_CHARS` | 超过该字数的回复只发文字，默认 300，建议 150 |
| `WEATHER_DEFAULT_CITY` | `/天气` 的默认城市 |

> **凭据安全**：`.env` 与 `config.json` 不进仓库（见 `.gitignore`）；密钥类字段在接口里只以 `__SET__` 占位符与掩码呈现。

---

## 🔌 插件与指令

| 插件 | 能力 | 代表指令 |
| --- | --- | --- |
| 识图 | 发图自动识别，支持多模态 Vision / 本地 OCR | `/识图` `/看图` `/ocr` |
| 签到积分 | 每日签到、积分、打赏、排行榜 | `/签到` `/积分` `/排行榜` `/打赏` |
| 娱乐 | 抽签、运势、掷骰、猜拳、成语 | `/抽签` `/运势` `/掷骰子` `/猜拳` `/成语` |
| 实用工具 | 翻译、天气、安全计算、百科 | `/翻译` `/天气` `/计算` `/百科` |
| AI 语音 | AI 回复自动合成语音消息（无需指令） | —（由能力开关控制） |

共 **26 条指令**，完整清单（含别名与管理员标记）在控制台「指令」子页，或查看 `server-monitor/ext_settings.py` 的 `COMMANDS`。

---

## ❓ 常见问题

**Q：Token 忘了 / 想换？**
A：`bash deploy.sh token` 查看，`bash deploy.sh token --reset` 一键轮换并重启；手机端重填新 Token。

**Q：AI 语音没声音？**
A：依次检查 ① `TTS_ENABLED=true` 且已填 `TTS_API_KEY`；② `TTS_VOICE_ID` 是控制台 Voice 页复制的**真实 ID**（形如 `voc_xxx`，仓库模板故意留空）；③ 控制台「功能」页的 `AI 回复自动语音` 已打开；④ 回复未超过 `TTS_MAX_CHARS`。默认走二进制直传，无需开端口；只有日志出现「回退 URL 方式」时才需配 `TTS_SERVE_HOST` 并放行 `TTS_SERVE_PORT`。

**Q：改了页面但手机还是旧样式？**
A：Service Worker 缓存。发布新版时把 `sw.js` 的缓存版本号 `+1`，或在浏览器里清缓存 / 强制刷新。

**Q：APK 安装提示「签名不一致」？**
A：说明用了不同 keystore。请保留首次构建的 `keystore/`，否则需要先卸载旧版。

**Q：机器人不回消息？**
A：群聊必须 **@机器人**；沙箱环境需把测试号/群加入白名单；`bash deploy.sh logs` 看网关状态。

---

## ⚠️ 免责声明

- 本项目是**非官方**的第三方实现，与腾讯 / QQ 官方没有关联、授权或背书。使用 QQ 官方机器人 API 需自行注册开发者账号并遵守平台条款与审核要求。
- `server-monitor/persona-chisa.*` 中的「朽叶千咲」及《鸣潮》相关名称与设定，**仅用于演示配置格式**，其知识产权归各自权利人所有，与库洛游戏及《鸣潮》官方无关。请替换为原创设定或自行确认授权。
- 大模型、BreezeBlue TTS、天气数据等均为独立第三方服务，需自行注册、遵守条款并承担调用费用。
- 仓库**不含任何真实凭据、服务器地址、预编译 APK 或签名密钥**；部署者需自备服务器与凭据，并自行承担运维与合规责任。安全建议见 [SECURITY.md](SECURITY.md)。

---

## 🤝 贡献

欢迎 Issue 与 Pull Request。改动前请阅读 [CONTRIBUTING.md](CONTRIBUTING.md)——尤其是前端 DOM 契约与「新增配置项需四处同步」的约定。

## 📜 许可证

[MIT](LICENSE) © 2026 QQBot Monitor Contributors
