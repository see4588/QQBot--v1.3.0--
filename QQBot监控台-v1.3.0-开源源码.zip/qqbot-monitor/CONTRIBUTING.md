# 贡献指南

感谢你愿意为 QQBot 监控台做贡献。本项目是三个相对独立的子工程的集合，改动前请先看清边界。

## 仓库结构

| 目录 | 职责 | 主要语言 |
| --- | --- | --- |
| `qq-bot/` | QQ 官方机器人核心（网关、分发、插件、配置、存储） | Python（aiohttp） |
| `server-monitor/` | 手机控制台（PWA 前端 + aiohttp 后端 + 设置中心） | Python / 原生 JS |
| `qqbot-monitor-app/` | 安卓客户端（WebView 壳，零第三方依赖） | Java / Bash |

## 本地开发

```bash
cp qq-bot/.env.example qq-bot/.env                 # 填自己的凭据
cp server-monitor/config.json.example server-monitor/config.json
cd qq-bot && python3 -m bot.main                   # 或 bash deploy.sh start
cd server-monitor && python3 server.py             # 或 bash deploy.sh start
```

安卓端构建需要 Android build-tools（aapt2 / d8 / zipalign / apksigner）与 JDK：

```bash
ANDROID_SDK=/path/to/android-sdk bash qqbot-monitor-app/build.sh
```

## 改动契约（重要）

1. **前端 DOM 契约**：`server-monitor/index.html` 是单文件应用，JS 依赖大量 `id` 与 `class`（`.hidden` / `.card` / `.tabbar` / `.sheet` / `.pill` / `.sw` / `data-cap` 等）。改样式请只重写 `<style>` 块，**不要改动 JS 与 DOM 结构**，否则功能会断。
2. **新增配置项必须四处同步**：
   - `qq-bot/bot/config.py`（字段 + `from_env` 解析）
   - `qq-bot/.env.example`（模板）
   - `server-monitor/ext_settings.py`（`SETTINGS_SCHEMA`；涉及开关还要改 `CAP_DEFS` / `PLUGINS` / `COMMANDS`）
   - `server-monitor/sw.js`（缓存版本号 `+1`，否则手机端拿不到新页面）
3. **新增插件**：在 `qq-bot/bot/plugins/` 建文件，带 `CAP` 属性，并在 `dispatcher.py` 注册；同时在 `ext_settings.py` 的 `PLUGINS` / `CAP_DEFS` / `COMMANDS` 里补齐。
4. **敏感配置**：密钥类字段必须加入 `SENSITIVE_KEYS`，接口只返回 `__SET__` 占位符与掩码，不得回传明文。

## 提交前自检

```bash
python3 -m compileall -q qq-bot/bot server-monitor/*.py
bash -n qqbot-monitor-app/build.sh
bash -n qq-bot/deploy.sh server-monitor/deploy.sh
```

隐私红线（**任何情况下都不要提交**）：

- `.env`、`config.json`、`*.db`、`data/`、`logs/`
- `keystore/`、`*.jks`、`*.apk`、`build/`、`dist/`
- 真实公网 IP、QQ AppID / AppSecret、任意平台 API Key、访问 Token、APK SHA-256、自签名证书指纹

提交前建议跑一次全量扫描：

```bash
grep -rIn "sk-\|xi-api-key: [A-Za-z0-9]\|[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}" . \
  --exclude-dir=.git --exclude='*.example'
```

## 提交与 PR

- 提交信息用简短的中文或英文祈使句，例如 `fix: 修复语音上传 token 竞态`。
- PR 请说明改动动机、影响范围、验证方式；涉及配置/数据库结构变化的请附上迁移说明。
- 不要把多个无关改动塞进同一个 PR。

## 行为准则

参与本项目即表示同意遵守 [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md)。
