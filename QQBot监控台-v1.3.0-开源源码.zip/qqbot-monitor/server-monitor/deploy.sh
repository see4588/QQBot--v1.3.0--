#!/usr/bin/env bash
# 服务器监督 · 一键部署 / 运维
# 用法：bash deploy.sh [start|stop|restart|status|logs|token [--reset]]
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="${INSTALL_DIR:-/opt/monitor}"
PY="${PY:-/opt/qqbot/venv/bin/python}"
SERVICE="qqbot-monitor"
UNIT="/etc/systemd/system/${SERVICE}.service"
PORT="${PORT:-80}"

log()  { printf '\033[32m[monitor]\033[0m %s\n' "$*"; }
warn() { printf '\033[33m[warn]\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[31m[error]\033[0m %s\n' "$*" >&2; exit 1; }

[ -x "$PY" ] || die "找不到 Python：$PY（需先部署 QQ 机器人的 venv）"

mkdir -p "$INSTALL_DIR/logs"
if [ "$SRC" != "$INSTALL_DIR" ]; then
  log "复制文件到 $INSTALL_DIR"
  for f in server.py index.html manifest.webmanifest sw.js icon-192.png icon-512.png; do
    [ -f "$SRC/$f" ] || die "缺少文件：$SRC/$f"
    cp "$SRC/$f" "$INSTALL_DIR/$f"
  done
fi

# 首次部署生成随机强 Token；已存在则保留，避免重启后手机端失效
if [ ! -f "$INSTALL_DIR/config.json" ]; then
  TOKEN="$("$PY" -c 'import secrets; print(secrets.token_urlsafe(24))')"
  cat > "$INSTALL_DIR/config.json" <<EOF
{
  "token": "$TOKEN",
  "host": "0.0.0.0",
  "port": $PORT,
  "qqbot_dir": "/opt/qqbot",
  "health_url": "http://127.0.0.1:8080/healthz",
  "service": "qqbot"
}
EOF
  chmod 600 "$INSTALL_DIR/config.json"
  log "已生成访问 Token（见下方 / 或执行 bash deploy.sh token）"
else
  chmod 600 "$INSTALL_DIR/config.json"
fi

write_unit() {
  cat > "$UNIT" <<EOF
[Unit]
Description=Server Monitor PWA (QQ Bot Dashboard)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
Environment=PYTHONUNBUFFERED=1
Environment=TZ=Asia/Shanghai
Environment=MONITOR_CONFIG=$INSTALL_DIR/config.json
ExecStart=$PY $INSTALL_DIR/server.py
Restart=always
RestartSec=5
StandardOutput=append:$INSTALL_DIR/logs/out.log
StandardError=append:$INSTALL_DIR/logs/err.log

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable "$SERVICE" >/dev/null 2>&1 || true
}

# ufw 若真的启用了规则，放行端口（本机 ufw status 为 inactive 时会跳过）
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q '^Status: active'; then
  ufw allow "${PORT}/tcp" >/dev/null 2>&1 || true
  log "ufw 已放行 ${PORT}/tcp"
fi

cmd_token() {
  "$PY" -c "import json;print(json.load(open('$INSTALL_DIR/config.json'))['token'])"
}

# 生成新 Token，安全写回 config.json（保留其它配置），重启服务使其生效
cmd_token_reset() {
  [ -f "$INSTALL_DIR/config.json" ] || die "config.json 不存在，请先执行 bash deploy.sh start"
  NEW="$("$PY" -c 'import secrets; print(secrets.token_urlsafe(24))')"
  "$PY" - "$INSTALL_DIR/config.json" "$NEW" <<'PYEOF'
import json, sys
p, t = sys.argv[1], sys.argv[2]
d = json.load(open(p))
d["token"] = t
json.dump(d, open(p, "w"), ensure_ascii=False, indent=2)
PYEOF
  chmod 600 "$INSTALL_DIR/config.json"
  log "已生成新 Token，正在重启服务…"
  systemctl restart "$SERVICE" 2>/dev/null || true
  sleep 1
  log "服务状态：$(systemctl is-active "$SERVICE" 2>/dev/null || echo unknown)"
  log "新的访问 Token：$NEW"
  log "请在手机 App / 网页用新 Token 重新登录（旧 Token 已作废）"
}

case "${1:-start}" in
  start|restart)
    write_unit
    systemctl restart "$SERVICE"
    sleep 2
    log "服务状态：$(systemctl is-active "$SERVICE")"
    PUBLIC_IP="$(curl -s --max-time 4 https://api.ipify.org 2>/dev/null || true)"
    [ -n "$PUBLIC_IP" ] || PUBLIC_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
    [ -n "$PUBLIC_IP" ] || PUBLIC_IP="<服务器公网IP>"
    log "访问地址：http://${PUBLIC_IP}:${PORT}/  （端口 80 时可省略 :80）"
    log "访问 Token：$(cmd_token)"
    log "手机打开后点右上角 ⚙ 填入 Token；iOS 用 Safari「添加到主屏幕」即可安装"
    ;;
  stop)    systemctl stop "$SERVICE"; log "已停止" ;;
  status)  systemctl status "$SERVICE" --no-pager || true ;;
  logs)    journalctl -u "$SERVICE" -f -n 100 ;;
  token)
    if [ "${2:-}" = "--reset" ]; then
      cmd_token_reset
    else
      cmd_token
    fi
    ;;
  *) echo "用法：bash deploy.sh [start|stop|restart|status|logs|token [--reset]]"; exit 1 ;;
esac
