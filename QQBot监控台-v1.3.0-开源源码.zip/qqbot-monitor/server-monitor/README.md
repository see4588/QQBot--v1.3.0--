# 服务器监督（手机端 PWA 监控台）

一个能「装到手机主屏幕」的服务器后台监督台：**独立图标、全屏运行、离线可打开**，实时查看服务器资源、`qqbot` 服务状态、QQ 机器人运行数据、实时日志，并支持远程重启服务。

> 为什么不是原生 App：iOS 安装原生应用需要 App Store / TestFlight / 企业签名，无法在这里签发。PWA 是 iOS/Android 都支持、且能立刻上线的方案，体验接近原生。
>
> **安卓用户现在有真正的原生 APK 了**：手机打开 `http://你的服务器公网IP或域名/app/` 即可下载安装，独立图标、全屏运行、自动记住 Token。详见第八节，源码与一键构建脚本在 `qqbot-monitor-app/`。

---

## 一、手机上安装（30 秒）

1. 用手机 **Safari（iOS）/ Chrome（Android）** 打开：`http://你的服务器公网IP或域名/`
2. 点右上角 **⚙**，填入部署时生成的 **访问 Token**，保存。
3. iOS：**分享 → 添加到主屏幕**；Android：Chrome 菜单 → **安装应用 / 添加到主屏幕**。
4. 之后从主屏幕图标打开，全屏无地址栏，自动每 10 秒刷新（可切 5s / 30s / 关闭）。

> 首次打开若显示「演示数据」说明没连上后端（本地预览时正常）；在真机上填好地址与 Token 即会切到真实数据。

---

## 二、已部署信息

| 项 | 值 |
|---|---|
| 服务器 | `你的服务器公网IP或域名`（Ubuntu 24.04） |
| 访问地址 | `http://你的服务器公网IP或域名/`（80 端口，通常云安全组默认放行，无需额外配置） |
| 安装目录 | `/opt/monitor` |
| 运行方式 | systemd 服务 `qqbot-monitor`，开机自启 + 崩溃自动重启 |
| 依赖 | 复用 `/opt/qqbot/venv`（aiohttp），**零新增 Python 依赖** |
| 配置 | `/opt/monitor/config.json`（权限 `600`，含随机 Token） |
| 访问 Token | **不随文档/压缩包分发**；服务器上 `cd /opt/monitor && bash deploy.sh token` 查看 |
| 安卓客户端下载页 | `http://你的服务器公网IP或域名/app/`（公开，无需 Token） |
| APK 文件 | `/opt/monitor/app/QQBotMonitor-v1.1.0.apk`（21,071 字节） |
| 审计日志 | `/opt/monitor/logs/actions.log`（记录每次远程操作与来源 IP） |

运维：

```bash
cd /opt/monitor
bash deploy.sh status|logs|restart|token
systemctl status qqbot-monitor
curl -H "X-Token: $(bash deploy.sh token)" http://127.0.0.1/api/status | head -c 500
```

---

## 三、手机控制台：5 个页面

底部导航切换。**安卓 APK 不用重装**——页面从服务器实时加载，Service Worker 已升到 `v3`，下次打开就是新界面（若仍是旧版，在「设置 → 清除页面缓存」后重启 App）。

| 页面 | 能做什么 |
|---|---|
| **总览** | 在线状态、运行时长/负载、CPU/内存/磁盘/负载/网络速率（阈值变色）、`qqbot` 服务与网关 `READY`、AI 与健康检查、今日消息/累计去重/定时任务/待发队列/最近消息、立即刷新、重启服务、自动刷新间隔 |
| **消息** | ① 发通知（选场景与已知会话，或手填 openid；预演开关）② 广播到所有会话 ③ **AI 试聊**（真实大模型 + 当前人格，气泡对话，不写入 QQ 会话）④ 会话列表与聊天记录、清空上下文 ⑤ 群管理（禁言/解禁/撤回，需手填 openid） |
| **自动化** | ① 定时提醒增删改启停（5 段 cron、Asia/Shanghai）② 关键词回复规则增删清空 ③ 待发通知队列查看 / 单条重试 / 删除 / 清空。**改动无需重启机器人** |
| **日志** | 实时日志（关键字搜索、级别筛选、最多 500 行）、操作审计（最近 120 条） |
| **设置** | 服务器地址 / Token / 刷新间隔、**AI 人格**（8 模板 + 自定义）、启动/停止/重启服务、脱敏配置摘要、客户端与版本、清除页面缓存 |

> 官方接口限制：没有群/好友列表，只能给**已经和机器人说过话**的会话发消息；主动消息受平台频控，发不出去会进待发队列，下次有人发言时自动带出。

---

## 四、架构与安全

```
手机客户端（安卓 APK / PWA，5 个 Tab）
        │  /api/*  (Header: X-Token)
        ▼
/opt/monitor/server.py  (aiohttp, 0.0.0.0:80)
        ├─ /proc/*                            系统指标（只读）
        ├─ systemctl show/start/stop/restart qqbot
        ├─ http://127.0.0.1:8080/healthz      机器人健康检查
        ├─ /opt/qqbot/data/bot.db              SQLite 读写（会话/提醒/队列）
        ├─ /opt/qqbot/keywords.json            关键词规则（原子写 600）
        ├─ /opt/qqbot/persona.json             人格（原子写 600）
        ├─ /opt/qqbot/bot/api.py               发消息 / 群管理（共用 venv 与 .env）
        ├─ /opt/qqbot/bot/llm.py               App 内 AI 试聊
        └─ /opt/qqbot/logs/bot.log             日志尾部
```

- 所有 `/api/*` 均需 `X-Token`，使用 `secrets.compare_digest` 恒定时间比较；静态页面与 APK 下载页公开，不含数据。
- 写操作（通知、广播、提醒、关键词、队列、人格、服务控制、群管理）均记录到 `/opt/monitor/logs/actions.log`。
- `/api/config` 对 AppSecret / LLM Key 一律不返回，AppID 打码。
- 支持 CORS，方便本地预览时连真实服务器调试。
- Service Worker 只缓存静态资源，`/api/` 永不缓存；首页与 `sw.js` 均 `no-cache`。

### 安全建议（重要）

1. **当前是 HTTP 明文**，Token 在公网传输。Token 已不随文档、压缩包或公开下载页分发，只在服务器上用 `bash deploy.sh token` 查看，请妥善保管；有条件建议后续套一层 HTTPS（Nginx + Let's Encrypt 或 Cloudflare），或改用 SSH 隧道访问。
2. 想换 Token：`/opt/monitor/config.json` 里改 `token`，`bash deploy.sh restart`，手机端在 ⚙ 里同步更新。
3. 想换端口：改 `config.json` 的 `port` 后重启，并在云安全组放行新端口。
4. 若以后装了宝塔占用 80，把端口改成如 `8899` 并放行即可；前端在 ⚙ 里把地址改成 `http://你的服务器公网IP或域名:8899`。
5. 服务器 root 建议使用 SSH 密钥登录，避免弱口令。

---

## 五、API

| 接口 | 方法 | 说明 |
|---|---|---|
| `/api/status` | GET | 全量状态（CPU 双采样约 0.35s） |
| `/api/logs?lines=&q=&level=` | GET | 日志：行数（1–500）、关键字、级别筛选 |
| `/api/audit` | GET | 操作审计（最近 120 条） |
| `/api/action` | POST | `{"action":"restart"\|"start"\|"stop"}` |
| `/api/persona` | GET | 当前人格 + 8 个预置模板 |
| `/api/persona` | POST | `{"name":"…","prompt":"…"}` 保存人设，立即生效 |
| `/api/config` | GET | 脱敏配置摘要（密钥不返回） |
| `/api/targets` | GET | 已知会话（聊天记录 + 队列 + 提醒去重） |
| `/api/history?scene=&target=&limit=` | GET | 某会话的聊天记录 |
| `/api/history/clear` | POST | `{"scene","target"}` 清空会话上下文 |
| `/api/chat/test` | POST | `{"message","history"}` App 内 AI 试聊（真实 LLM + 当前人格） |
| `/api/notify` | POST | `{"scene","target","content","dry_run"}` 发通知 |
| `/api/broadcast` | POST | `{"content","dry_run"}` 广播到所有会话 |
| `/api/queue` | GET | 待发通知队列 |
| `/api/queue` | POST | `{"action":"delete"\|"clear"\|"retry","id"}` |
| `/api/reminders` | GET | 定时提醒列表 |
| `/api/reminders` | POST | `{"action":"add"\|"toggle"\|"delete",…}` |
| `/api/keywords` | GET | 关键词规则 + 来源（`env` / `file`） |
| `/api/keywords` | POST | `{"action":"add"\|"delete"\|"clear",…}` |
| `/api/group` | POST | `{"action":"mute"\|"unmute"\|"recall",…}` 群管理 |

均需 Header `X-Token: <token>`（也支持 `?token=`）。示例：

```bash
TOKEN=$(cd /opt/monitor && bash deploy.sh token)
curl -s -H "X-Token: $TOKEN" http://127.0.0.1/api/status | python3 -m json.tool | head -30
curl -s -H "X-Token: $TOKEN" -H 'Content-Type: application/json' \
  -d '{"message":"打个招呼","history":[]}' http://127.0.0.1/api/chat/test
```

---

## 六、迁移到新服务器

```bash
scp -r server-monitor root@<新IP>:/opt/monitor
cd /opt/monitor && bash deploy.sh start
```

`deploy.sh` 会自动生成新 Token、写 systemd 服务、启动并打印访问地址。若新机器上没有 `/opt/qqbot/venv`，用 `PY=/path/to/python bash deploy.sh start` 指定已装 aiohttp 的解释器。

---

## 七、故障排查

| 现象 | 处理 |
|---|---|
| 页面一直「连接失败」 | 云安全组是否放行 80；`systemctl status qqbot-monitor`；`curl -I http://127.0.0.1/` |
| 提示 Token 无效 | `bash deploy.sh token` 查看，手机端 ⚙ 重新填 |
| 指标全为 0 / 业务数据为空 | 检查 `config.json` 的 `qqbot_dir`、`health_url` 是否正确 |
| 网关显示「未连接」 | 看 `/opt/qqbot/logs/bot.log` 是否有 `READY`；必要时重启机器人 |
| 重启按钮无效 | 服务以 root 运行，检查 `systemctl` 权限与 `logs/err.log` |
| PWA 图标不显示 | iOS 必须用 Safari 添加；确认 `/icon-192.png` 可访问 |

---

## 八、安卓客户端（APK）

除 PWA 外，另外构建了一个**原生 Android 安装包**（不是网页快捷方式）：独立图标、全屏 WebView、自动记住 Token、可改服务器地址、断网有可操作错误页。

| 项 | 值 |
|---|---|
| 下载页 | `http://你的服务器公网IP或域名/app/`（手机浏览器直接打开） |
| APK 直链 | `http://你的服务器公网IP或域名/app/QQBotMonitor-v1.1.0.apk` |
| 服务端位置 | `/opt/monitor/app/QQBotMonitor-v1.1.0.apk`、`/opt/monitor/download.html` |
| 包名 / 版本 | `com.qqbot.monitor` / `1.1.0` |
| 系统要求 | Android 7.0+（API 24），自签名 v2 + v3 |
| 权限 | 仅 `INTERNET`、`ACCESS_NETWORK_STATE` |

**安装**：手机打开下载页 → 下载 APK → 允许「安装未知应用」→ 安装 → 首次打开在 ⚙ 填 Token。

**后端改动（已部署）**：`server.py` 新增两个**公开**路由（页面与安装包本身不含数据，故无需 Token），其余 `/api/*` 鉴权不变：

- `GET /app/`、`GET /app` → `download.html`
- `GET /app/{name}.apk` → APK 文件，`Content-Type: application/vnd.android.package-archive` + `Content-Disposition: attachment`

`index.html` 新增「安装安卓客户端」横条；App 内通过 `window.MonitorApp` 自动隐藏该横条，并在设置面板显示客户端版本。

**更新 APK**：把新 APK 传到 `/opt/monitor/app/`，同步更新 `download.html` 里的版本/大小/SHA-256 与 `server.py` 的 `APK_NAME`，然后 `systemctl restart qqbot-monitor`。源码、签名证书与 `build.sh` 见 `qqbot-monitor-app/`（**保留 keystore**，否则用户无法覆盖升级）。

---

## 九、定制机器人人格（手机上直接改，立即生效）

> **当前生效人格：朽叶千咲（《鸣潮》）**，2026-11-13 设定，762 字，已加入 App 预置模板，切走后可一键切回。
> 设定依据、人设要点与完整 System Prompt 见 `persona-chisa.md`、可复用配置见 `persona-chisa.json`。

在监控台「服务与机器人」卡片点 **「AI 人格」** 那一行，打开人格面板：

- **8 个预置模板**：默认助手 / 毒舌损友 / 温柔姐姐 / 猫娘喵喵 / 极简冷酷 / 专业顾问 / 话痨搭子 / 朽叶千咲，点一下自动填入
- **完全自定义**：自己写人格名称（1–20 字）+ System Prompt（1–800 字）
- **保存即生效**：写入 `/opt/qqbot/persona.json`，机器人**下一次对话就按新人设回复，不重启、不掉线**
- 未自定义时回退到 `/opt/qqbot/.env` 的 `LLM_SYSTEM_PROMPT`
- 首页会显示当前生效的人格名与更新时间

**为什么不用重装 App**：安卓客户端是 WebView 壳，页面从服务器实时加载；Service Worker 已升级到 `v3`，首页加 `Cache-Control: no-cache`，所以已装的 APK 下次打开就是新界面，无需重新下载或签名。若仍看到旧界面，在「设置 → 清除页面缓存」后重启 App。

### 实现机制

```
手机 App / 网页 ── POST /api/persona ──▶ server.py
                                          │ 原子写 os.replace + chmod 600
                                          ▼
                                   /opt/qqbot/persona.json
                                          │ 每次对话前重读
                                          ▼
                                   bot/llm.py → system prompt → DeepSeek
```

机器人 `LLMClient.chat()` 每次构造请求时重读 `persona.json`，所以改人格无需重启进程。写入做了长度/类型校验、控制字符清理、原子替换与审计日志。

### 示例

```bash
TOKEN=$(cd /opt/monitor && bash deploy.sh token)
curl -s -H "X-Token: $TOKEN" http://127.0.0.1/api/persona | python3 -m json.tool | head -20
curl -s -X POST -H "X-Token: $TOKEN" -H 'Content-Type: application/json' \
  -d '{"name":"猫娘喵喵","prompt":"每句话结尾都要带喵，纯文本，不超过 60 字。"}' \
  http://127.0.0.1/api/persona
```

> 以 `/` 开头的指令不经过大模型，不受人格影响。人格切换后已有多轮上下文仍保留，但模型以新 system prompt 为准。所有保存都记录在 `/opt/monitor/logs/actions.log`。

---

## 十、全功能控制台：为什么改完不用重启

| 在 App 里改的东西 | 写到哪 | 机器人怎么感知 |
|---|---|---|
| AI 人格 | `/opt/qqbot/persona.json` | `LLMClient.chat()` 每次对话前重读 |
| 关键词规则 | `/opt/qqbot/keywords.json` | `CommandPlugin` 每条消息按**文件内容**比对热读；文件不存在时回退 `.env` 的 `KEYWORD_RULES` |
| 定时提醒 | `bot.db` → `reminders` 表 | `ReminderService` 每 3 秒轮询，把增删改启停同步到 APScheduler |
| 待发通知队列 | `bot.db` → `pending_notice` 表 | 机器人下次收到消息时在同一进程直接读表 |
| 通知 / 广播 | QQ 官方 API → 失败转队列 | 主动消息受限时自动入队，下次有人发言随回复带出 |

最慢 **3 秒**生效，全程不重启进程、QQ 不掉线。关键词与人格文件均为原子写入、权限 `600`；`/api/keywords` 首次读取会显示 `.env` 里的既有规则，保存一次后由控制台接管。

### 端到端验证记录（2026-11-13）

- 公网 **29/29** 接口校验通过：无 Token 401、配置脱敏、读写回环、`dry_run`、日志搜索、真实 DeepSeek 试聊（千咲人格）
- 机器人日志实见 `定时任务已热同步：{'added': 1, …}` 与 `{'removed': 1, …}`
- App 写入关键词后，服务器机器人同款代码读到 3 条规则（路径与 `Config.BASE_DIR` 对齐）
- 真实浏览器逐页点击：5 个 Tab、人格面板 8 模板、演示模式、AI 试聊均通过，**无 JS 运行时错误**
- 机器人侧 15 项模拟自测保持全绿

### 官方平台限制（影响 App 里的功能）

- **没有群/好友列表接口**：通知目标只能来自已交互会话，或手动粘贴 openid。
- **主动消息有权限与频控**（40034105 / 40034100 等）：发不出去会自动进待发队列，不会丢。
- **群管理**要求机器人是群管理员；撤回仅限 2 分钟内、需手填 `message_id`；禁言/解禁需手填 `member_openid`。
- 机器人当前仍在**沙箱环境**，正式上线后把 `/opt/qqbot/.env` 的 `QQ_SANDBOX` 改回 `false` 并重启。


## 附录：v1.1.0 设置中心（QQ 机器人设置全量搬进手机）

设置 → **配置 / 功能 / 平台 / 指令 / 插件 / 关于** 子页（配置表单内按 7 个分组渲染）：

| 子页 | 内容 |
| --- | --- |
| 配置 | `.env` 全部 42 项，分基础 / 接入 / AI / 运行 / 插件 / 语音 / 高级七组；文本、密码、开关、下拉、数字、JSON、intents 勾选；保存自动备份 `.env`、校验、写入审计日志并可自动重启机器人 |
| 功能 | 13 个能力开关（AI 聊天、关键词、指令、欢迎语、定时提醒、群管理、消息去重、识图、签到、娱乐、工具、AI 回复自动语音等），写 `capabilities.json` 热读生效，无需重启 |
| 平台 | 用 AppID/AppSecret 换取 token 调用官方 v2 接口：机器人资料、WSS 网关、已加入频道、单聊自定义菜单（可编辑保存）、指令面板、入群自动审批策略、群设置 / 成员 / 入群申请 / 黑名单 / 禁言、入群审批、白名单内任意官方接口调用 |
| 指令 | 26 条指令清单（含别名、说明、管理员标记） |
| 关于 | 连接设置、AI 人格、服务启停、配置摘要、备份 / 回滚、缓存清理 |

新增接口：`GET/POST /api/settings`、`/api/settings/backups`、`/api/settings/rollback`、
`GET/POST /api/capabilities`、`/api/commands`、`/api/platform`、`/api/platform/group`、
`/api/platform/join`、`/api/platform/menu`、`/api/platform/call`。全部需 `X-Token`，写操作记入
`/opt/monitor/logs/actions.log`。密钥一律不回传（返回 `__SET__`），留空即保持原值。

> `.env` 中的 `QQ_DB_PATH` / `LOG_DIR` 由 systemd 单元以 `Environment=` 固定，界面标为只读。
> 机器人仍处沙箱环境，正式上线需在「配置 → 接入」把「沙箱环境」关掉并保存重启。


## v1.2.0 新增：插件中心（看图 / 签到 / 娱乐 / 工具）

设置 → **插件** 子页可一键开关 4 个插件；**功能** 子页的能力开关增至 12 个。

| 插件 | 指令 | 说明 |
| --- | --- | --- |
| 识图 / 图片识别 | `/识图 [问题]` `/看图` `/ocr` | 直接发图也会自动识别。优先用「配置 → 插件」里填的 OpenAI 兼容多模态接口「看图说话」，没填也能用本地 Tesseract OCR 提取图中文字（服务器已装 `tesseract-ocr-chi-sim`） |
| 签到积分 | `/签到` `/积分` `/排行榜` `/打赏 @成员 <数量>` | 连续天数越多奖励越多，积分可互转 |
| 娱乐 | `/抽签` `/运势 [星座]` `/掷骰子 [n]d[m]` `/猜拳 [出拳]` `/成语 [词语]` | 活跃群气氛 |
| 实用工具 | `/翻译 <文字>` `/天气 [城市]` `/计算 <表达式>` `/百科 <词条>` | 天气用 wttr.in 无需额外 Key；计算做了 AST 沙箱防注入 |

新增接口：`/api/settings` 现在返回 `plugins` 清单（4 个）、`cap_defs`（12 个开关）、`commands`（26 条）。
插件总开关写入 `capabilities.json` 热生效；插件参数（VISION_*/WEATHER_DEFAULT_CITY）写在 `.env`，可在「配置 → 插件」分组编辑并自动重启。
