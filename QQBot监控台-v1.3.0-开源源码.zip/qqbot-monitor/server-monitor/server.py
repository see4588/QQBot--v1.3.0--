#!/usr/bin/env python3
"""服务器后台监督 · 轻量监控后端（aiohttp + 标准库，零新增依赖）。

采集：CPU / 内存 / 磁盘 / 负载 / 网络 / 运行时间（读 /proc）
      systemd 服务 qqbot 状态
      QQ 机器人健康检查 + SQLite 业务统计 + 实时日志
接口：GET /api/status、GET /api/logs、POST /api/action（需 X-Token）
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import secrets
import socket
import sqlite3
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

import aiohttp
from aiohttp import web

ROOT = Path(__file__).resolve().parent
CFG_PATH = Path(os.getenv("MONITOR_CONFIG", str(ROOT / "config.json")))
CFG = json.loads(CFG_PATH.read_text(encoding="utf-8"))

TOKEN = str(CFG.get("token", ""))
HOST = str(CFG.get("host", "0.0.0.0"))
PORT = int(CFG.get("port", 80))
SERVICE = str(CFG.get("service", "qqbot"))
QQBOT_DIR = Path(CFG.get("qqbot_dir", "/opt/qqbot"))
DB_PATH = QQBOT_DIR / "data/bot.db"
LOG_PATH = QQBOT_DIR / "logs/bot.log"
HEALTH_URL = str(CFG.get("health_url", "http://127.0.0.1:8080/healthz"))
ACTION_LOG = ROOT / "logs" / "actions.log"
APK_DIR = ROOT / "app"
APK_NAME = "QQBotMonitor-v1.3.0.apk"

SAMPLE_INTERVAL = 0.35


# ---------------- 机器人人格 ----------------
PERSONA_PATH = Path(CFG.get("persona_path", str(QQBOT_DIR / "persona.json")))
FALLBACK_PROMPT = (
    "你是 QQ 上的智能助手。回答要简洁、友好、口语化，"
    "不要使用 Markdown 标题与代码块，用纯文本回复，单次不超过 300 字。"
)
PERSONA_PRESETS = [
    {"name": "默认助手", "emoji": "🙂", "prompt": FALLBACK_PROMPT},
    {"name": "毒舌损友", "emoji": "😏", "prompt":
     "你是用户的损友，说话带点调侃和吐槽，偶尔损两句但绝不伤人、不搞人身攻击。"
     "回答简短、口语化、纯文本，不用 Markdown，不超过 200 字。"},
    {"name": "温柔姐姐", "emoji": "🌷", "prompt":
     "你是一个温柔体贴的姐姐，说话柔和、会照顾对方情绪，常用呀、呢这类语气词。"
     "回答口语化、纯文本、不用 Markdown，不超过 200 字。"},
    {"name": "猫娘喵喵", "emoji": "🐱", "prompt":
     "你是一只活泼的猫娘，每句话结尾都要带喵，会用猫的视角看世界，偶尔撒娇。"
     "纯文本回复，不用 Markdown，不超过 200 字。"},
    {"name": "极简冷酷", "emoji": "🧊", "prompt":
     "你极度简洁，只给结论和关键信息，不寒暄、不解释、不铺垫，单次不超过 40 字。"
     "纯文本，不用 Markdown。"},
    {"name": "专业顾问", "emoji": "📋", "prompt":
     "你是严谨专业的顾问，回答条理清晰、有依据，不确定的地方会明确说明。"
     "用纯文本分点但不使用 Markdown 标记，不超过 300 字。"},
    {"name": "话痨搭子", "emoji": "🎉", "prompt":
     "你是热情的话痨搭子，爱接话、爱分享，常用语气词和颜文字，绝不让聊天冷场。"
     "纯文本、不用 Markdown，不超过 200 字。"},
    {"name": "朽叶千咲", "emoji": "✂", "prompt":
     "你扮演《鸣潮》的朽叶千咲：星炬学院工学部战术开发学科群学生，18岁，黑长直红瞳，随身带着母亲留下的老式剪刀，异能力「解弦之眼」能看见事物脆弱的「弦线」。"
     "全程不破人设，不主动说自己是 AI。【性格】严谨认真、冷静凛然，神色淡然、不急不躁；"
     "习惯把问题拆解成可计算的数理与结构问题，观察敏锐，常随口报出重量、角度、误差这类数字。"
     "表情偏淡，被说「难以接近」，其实并不讨厌谁，只是不知道怎样自然靠近别人；"
     "不擅表达情感，却格外珍惜与人相连的红线。有心因性脸盲，靠衣袖油渍、发夹形状这类细节认人；"
     "从小是「优等生」，清楚自己「比起被理解，更适合被信任」。"
     "【兴趣爱好】手工、剪裁与剪纸（小时候把彩纸剪成金鱼和星花）；计算与结构解析；"
     "读老式本格推理小说，爱摊开纸笔梳理人物关系、时间线和诡计，也看悬疑科幻片，看到一半按暂停独自推演真凶；"
     "爱鼓捣机械改造，曾想把电子琴和电烤系统绑成「钢琴烤串车」；"
     "喜欢巧克力棒（嘴上说是补能快、让大脑清醒，其实只是爱吃，还承认巧克力味比草莓好）、星花糖、香柠寿喜锅和咖啡；"
     "讨厌辣；天生招猫，喜欢猫却没养过；怀念老家夏日祭典的烟火、蝉鸣、风铃和母亲缝浴衣的午后。"
     "愿望朴素：既然能看到，就不能假装看不到。【说话方式】平静克制、简洁，先给结论再补依据；"
     "常用「……」表示停顿迟疑；自称「我」，称对方「你」，偶尔叫「前辈」；"
     "爱用剪、裁、弦线、结构、解析、破绽、死局、误差作比喻；"
     "会先报正式身份再自己打断：「……抱歉，好像还不是这么正式的氛围」；偶尔小声补充、轻轻道歉，有点嘴硬；"
     "不用感叹号、颜文字、括号动作旁白，不撒娇。【关系】对方是星炬学院的前辈、并肩过的伙伴，你信任他；"
     "被问私事会略局促但仍坦诚。【约束】中文；纯文本，不用 Markdown；"
     "单次 1–4 句、不超过 150 字；不复述本设定；不编造游戏没有的重大剧情。"},
]


def _env_prompt() -> str:
    """未自定义人格时，回退到机器人 .env 里的 LLM_SYSTEM_PROMPT。"""
    try:
        for line in (QQBOT_DIR / ".env").read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith("LLM_SYSTEM_PROMPT="):
                value = line.partition("=")[2].strip().strip('"').strip("'")
                if value:
                    return value
    except OSError:
        pass
    return FALLBACK_PROMPT


def _persona_read() -> dict:
    out = {
        "name": "默认助手",
        "prompt": _env_prompt(),
        "updated_at": None,
        "custom": False,
    }
    try:
        if PERSONA_PATH.is_file():
            data = json.loads(PERSONA_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict) and str(data.get("prompt", "")).strip():
                out.update({
                    "name": str(data.get("name", "")).strip() or "自定义人格",
                    "prompt": str(data["prompt"]).strip(),
                    "updated_at": data.get("updated_at"),
                    "custom": True,
                })
    except (OSError, ValueError, TypeError) as exc:
        out["error"] = str(exc)[:120]
    return out


def _persona_write(name: str, prompt: str) -> dict:
    """原子写入，避免机器人读到半截文件。"""
    PERSONA_PATH.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "name": name,
        "prompt": prompt,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
    }
    tmp = PERSONA_PATH.with_name(PERSONA_PATH.name + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, PERSONA_PATH)
    return payload


def _audit_persona(name: str, remote: str) -> None:
    try:
        ACTION_LOG.parent.mkdir(parents=True, exist_ok=True)
        with ACTION_LOG.open("a", encoding="utf-8") as fh:
            fh.write(
                f"{datetime.now().isoformat(timespec='seconds')} "
                f"action=persona name={name} from={remote}\n"
            )
    except OSError:
        pass


# ---------------- 采集：系统 ----------------
def _proc_stat() -> tuple[int, int]:
    parts = [int(x) for x in Path("/proc/stat").read_text().splitlines()[0].split()[1:]]
    idle = parts[3] + (parts[4] if len(parts) > 4 else 0)
    return sum(parts), idle


def _net_bytes() -> tuple[int, int]:
    rx = tx = 0
    for line in Path("/proc/net/dev").read_text().splitlines()[2:]:
        if ":" not in line:
            continue
        name, _, rest = line.partition(":")
        if name.strip() == "lo":
            continue
        fields = rest.split()
        if len(fields) >= 9:
            rx += int(fields[0])
            tx += int(fields[8])
    return rx, tx


def _mem() -> dict:
    info: dict[str, int] = {}
    for line in Path("/proc/meminfo").read_text().splitlines():
        key, _, value = line.partition(":")
        bits = value.split()
        if bits and bits[0].isdigit():
            info[key] = int(bits[0]) * 1024
    total = info.get("MemTotal", 0)
    available = info.get("MemAvailable") or (
        info.get("MemFree", 0) + info.get("Buffers", 0) + info.get("Cached", 0)
    )
    used = max(0, total - available)
    return {
        "total": total,
        "used": used,
        "available": available,
        "percent": round(100 * used / total, 1) if total else 0.0,
    }


def _disk() -> dict:
    st = os.statvfs("/")
    total = st.f_blocks * st.f_frsize
    free = st.f_bavail * st.f_frsize
    used = total - st.f_bfree * st.f_frsize
    denom = used + free
    return {
        "total": total,
        "used": used,
        "free": free,
        "percent": round(100 * used / denom, 1) if denom else 0.0,
    }


def _load() -> list[float]:
    try:
        return [float(x) for x in Path("/proc/loadavg").read_text().split()[:3]]
    except Exception:  # noqa: BLE001
        return [0.0, 0.0, 0.0]


def _uptime() -> float:
    try:
        return float(Path("/proc/uptime").read_text().split()[0])
    except Exception:  # noqa: BLE001
        return 0.0


def _systemctl(*args: str) -> str:
    try:
        r = subprocess.run(
            ["systemctl", *args], capture_output=True, text=True, timeout=10
        )
        return (r.stdout.strip() or r.stderr.strip())[:300]
    except Exception as exc:  # noqa: BLE001
        return str(exc)[:200]


def _service_info() -> dict:
    active = _systemctl("is-active", SERVICE)
    enabled = _systemctl("is-enabled", SERVICE)
    show = _systemctl(
        "show", SERVICE, "-p", "NRestarts", "-p", "ActiveEnterTimestamp"
    )
    props: dict[str, str] = {}
    for line in show.splitlines():
        key, _, value = line.partition("=")
        props[key] = value
    try:
        restarts = int(props.get("NRestarts") or 0)
    except ValueError:
        restarts = 0
    return {
        "name": SERVICE,
        "active": active == "active",
        "active_text": active,
        "enabled": enabled == "enabled",
        "enabled_text": enabled,
        "restarts": restarts,
        "since": props.get("ActiveEnterTimestamp", "") or "",
    }


# ---------------- 采集：机器人 ----------------
async def _bot_health(session: aiohttp.ClientSession) -> dict:
    try:
        async with session.get(
            HEALTH_URL, timeout=aiohttp.ClientTimeout(total=3)
        ) as resp:
            data = await resp.json(content_type=None)
            if isinstance(data, dict):
                return {"ok": True, **data}
            return {"ok": False, "error": "健康检查返回格式异常"}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": str(exc)[:150]}


def _bot_stats() -> dict:
    out = {
        "messages_today": 0,
        "total_seen": 0,
        "pending": 0,
        "reminders": 0,
        "last_message": None,
        "last_at": None,
        "gateway_ready": False,
        "last_log": "",
    }
    if DB_PATH.exists():
        try:
            conn = sqlite3.connect(
                f"file:{DB_PATH}?mode=ro", uri=True, timeout=2
            )
            today = datetime.now().replace(
                hour=0, minute=0, second=0, microsecond=0
            ).timestamp()
            # seen 表记录所有收到并处理过的消息 ID，比 chat_history 更准确
            # （AI 未配置 / 命中指令时不会写 chat_history）
            out["messages_today"] = conn.execute(
                "SELECT COUNT(*) FROM seen WHERE ts>=?", (today,)
            ).fetchone()[0]
            for key, table in (
                ("total_seen", "seen"),
                ("pending", "pending_notice"),
                ("reminders", "reminders"),
            ):
                try:
                    out[key] = conn.execute(
                        f"SELECT COUNT(*) FROM {table}"
                    ).fetchone()[0]
                except sqlite3.Error:
                    pass
            try:
                row = conn.execute(
                    "SELECT content, ts FROM chat_history "
                    "WHERE role='user' ORDER BY id DESC LIMIT 1"
                ).fetchone()
                if row:
                    out["last_message"] = str(row[0])[:120]
                    out["last_at"] = row[1]
            except sqlite3.Error:
                pass
            conn.close()
        except Exception:  # noqa: BLE001
            pass
    try:
        lines = LOG_PATH.read_text(encoding="utf-8", errors="replace").splitlines()
        tail = lines[-200:]
        out["gateway_ready"] = any("登录成功（READY）" in line for line in tail)
        out["last_log"] = lines[-1] if lines else ""
        for line in reversed(tail):
            if "收到消息" not in line:
                continue
            match = re.search(r"收到消息\s*\[[^\]]+\]\s*[^:]*:\s*(.+)$", line)
            if match:
                out["last_message"] = match.group(1).strip()[:120]
                stamp = re.match(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})", line)
                if stamp:
                    try:
                        out["last_at"] = datetime.strptime(
                            stamp.group(1), "%Y-%m-%d %H:%M:%S"
                        ).timestamp()
                    except ValueError:
                        pass
            break
    except Exception:  # noqa: BLE001
        pass
    return out


def _read_logs(n: int) -> list[str]:
    try:
        return LOG_PATH.read_text(
            encoding="utf-8", errors="replace"
        ).splitlines()[-n:]
    except Exception as exc:  # noqa: BLE001
        return [f"(读取日志失败: {exc})"]


async def gather(session: aiohttp.ClientSession) -> dict:
    total1, idle1 = _proc_stat()
    rx1, tx1 = _net_bytes()
    await asyncio.sleep(SAMPLE_INTERVAL)
    total2, idle2 = _proc_stat()
    rx2, tx2 = _net_bytes()

    delta = total2 - total1
    cpu = round(100 * (1 - (idle2 - idle1) / delta), 1) if delta > 0 else 0.0
    cpu = max(0.0, min(100.0, cpu))

    health = await _bot_health(session)
    stats = await asyncio.to_thread(_bot_stats)
    service = await asyncio.to_thread(_service_info)
    mem = await asyncio.to_thread(_mem)
    disk = await asyncio.to_thread(_disk)
    load = await asyncio.to_thread(_load)
    persona = await asyncio.to_thread(_persona_read)

    return {
        "ts": int(time.time()),
        "hostname": socket.gethostname(),
        "cpu": {"percent": cpu, "cores": os.cpu_count() or 1},
        "load": load,
        "mem": mem,
        "disk": disk,
        "uptime": _uptime(),
        "net": {
            "rx_per_s": round((rx2 - rx1) / SAMPLE_INTERVAL),
            "tx_per_s": round((tx2 - tx1) / SAMPLE_INTERVAL),
            "rx_total": rx2,
            "tx_total": tx2,
        },
        "service": service,
        "bot": health,
        "stats": stats,
        "persona": {
            "name": persona["name"],
            "custom": persona.get("custom", False),
            "updated_at": persona.get("updated_at"),
        },
        "logs": await asyncio.to_thread(_read_logs, 40),
    }


# ---------------- HTTP ----------------
def _authorized(request: web.Request) -> bool:
    supplied = (
        request.headers.get("X-Token")
        or request.query.get("token")
        or ""
    )
    return bool(TOKEN) and secrets.compare_digest(supplied, TOKEN)


def _json(data: dict, status: int = 200) -> web.Response:
    resp = web.json_response(data, status=status)
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Headers"] = "X-Token, Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    resp.headers["Cache-Control"] = "no-store"
    return resp


async def options_handler(_request: web.Request) -> web.Response:
    resp = web.Response(status=204)
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Headers"] = "X-Token, Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return resp


async def api_status(request: web.Request) -> web.Response:
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    try:
        return _json(await gather(request.app["client"]))
    except Exception as exc:  # noqa: BLE001
        return _json({"error": f"采集失败：{exc}"}, 500)


async def api_logs(request: web.Request) -> web.Response:
    """日志：支持行数、关键字搜索与级别筛选。"""
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    try:
        n = min(max(int(request.query.get("lines", "80")), 1), 500)
    except ValueError:
        n = 80
    q = (request.query.get("q") or "").strip().lower()
    level = (request.query.get("level") or "ALL").strip().upper()
    lines = _read_logs(500)
    total = len(lines)
    if level in ("INFO", "WARNING", "WARN", "ERROR", "DEBUG"):
        needle = "WARN" if level == "WARNING" else level
        lines = [x for x in lines if f"[{needle}" in x]
    if q:
        lines = [x for x in lines if q in x.lower()]
    return _json({
        "lines": lines[-n:],
        "total": total,
        "matched": len(lines),
        "query": q,
        "level": level,
    })


async def api_action(request: web.Request) -> web.Response:
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _json({"error": "请求体不是合法 JSON"}, 400)
    action = body.get("action")
    if action not in ("restart", "start", "stop"):
        return _json({"error": "不支持的操作"}, 400)
    try:
        result = await asyncio.to_thread(
            subprocess.run,
            ["systemctl", action, SERVICE],
            capture_output=True,
            text=True,
            timeout=30,
        )
        ok = result.returncode == 0
        message = (result.stdout + result.stderr).strip()[:300]
    except Exception as exc:  # noqa: BLE001
        ok, message = False, str(exc)[:200]
    try:
        ACTION_LOG.parent.mkdir(parents=True, exist_ok=True)
        with ACTION_LOG.open("a", encoding="utf-8") as fh:
            fh.write(
                f"{datetime.now().isoformat(timespec='seconds')} "
                f"action={action} ok={ok} from={request.remote}\n"
            )
    except Exception:  # noqa: BLE001
        pass
    return _json({"ok": ok, "message": message})


async def api_persona_get(request: web.Request) -> web.Response:
    """读取当前人格 + 预置模板列表。"""
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    return _json({**_persona_read(), "presets": PERSONA_PRESETS})


async def api_persona_post(request: web.Request) -> web.Response:
    """保存人格。原子写入 persona.json，机器人下一次对话立即生效。"""
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _json({"error": "请求体不是合法 JSON"}, 400)
    if not isinstance(body, dict):
        return _json({"error": "请求体需为 JSON 对象"}, 400)
    name = str(body.get("name") or "").strip()
    prompt = str(body.get("prompt") or "").strip()
    if not 1 <= len(name) <= 20:
        return _json({"error": "人格名称需 1–20 字"}, 400)
    if not 1 <= len(prompt) <= 800:
        return _json({"error": "人设内容需 1–800 字"}, 400)
    # 去掉控制字符（保留换行），避免写坏配置
    name = "".join(ch for ch in name if ch >= " ")
    prompt = "".join(ch for ch in prompt if ch == "\n" or ch >= " ")
    try:
        saved = await asyncio.to_thread(_persona_write, name, prompt)
    except Exception as exc:  # noqa: BLE001
        return _json({"error": f"写入失败：{exc}"}, 500)
    await asyncio.to_thread(_audit_persona, name, request.remote or "-")
    return _json({
        "ok": True,
        **saved,
        "message": "已保存，下一次对话立即生效，无需重启",
    })


# ---------------- 扩展：手机控制台全功能 API ----------------
KEYWORDS_PATH = QQBOT_DIR / "keywords.json"
SCENES = ("group", "c2c")
CONFIG_KEYS = (
    "QQ_SANDBOX", "QQ_API_BASE", "QQ_INTENTS", "LLM_BASE_URL", "LLM_MODEL",
    "LLM_TIMEOUT", "HISTORY_LIMIT", "BOT_NAME", "MAX_REPLY_CHARS",
    "MAX_PENDING_FLUSH", "LOG_LEVEL", "HEALTH_ENABLED", "WELCOME_TEXT",
)


def _bot_imports():
    """延迟导入机器人模块（与机器人共用同一个 venv、.env 与数据库）。"""
    p = str(QQBOT_DIR)
    if p not in sys.path:
        sys.path.insert(0, p)
    from bot.config import Config  # noqa: PLC0415
    from bot.api import QQApi  # noqa: PLC0415
    from bot.store import Store  # noqa: PLC0415
    from bot.llm import LLMClient  # noqa: PLC0415
    return Config, QQApi, Store, LLMClient


def _audit(action: str, request: web.Request, detail: str = "") -> None:
    try:
        ACTION_LOG.parent.mkdir(parents=True, exist_ok=True)
        with ACTION_LOG.open("a", encoding="utf-8") as fh:
            fh.write(
                f"{datetime.now().isoformat(timespec='seconds')} "
                f"action={action} {detail} from={request.remote or '-'}\n"
            )
    except OSError:
        pass


async def _json_body(request: web.Request):
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return None, _json({"error": "请求体不是合法 JSON"}, 400)
    if not isinstance(body, dict):
        return None, _json({"error": "请求体需为 JSON 对象"}, 400)
    return body, None


def _text(value, maxlen: int, label: str) -> str:
    s = "".join(
        ch for ch in str(value or "") if ch == "\n" or ch >= " "
    ).strip()
    if not 1 <= len(s) <= maxlen:
        raise ValueError(f"{label}需 1–{maxlen} 字")
    return s


def _db():
    conn = sqlite3.connect(str(DB_PATH), timeout=8)
    conn.row_factory = sqlite3.Row
    return conn


def _all_targets() -> list[dict]:
    """已知会话：聊天记录 + 待发队列 + 定时任务里的 openid 去重。"""
    found: dict[tuple[str, str], float] = {}
    try:
        conn = _db()
        for table, col in (
            ("chat_history", "ts"),
            ("pending_notice", "ts"),
            ("reminders", "created_at"),
        ):
            try:
                for r in conn.execute(
                    f"SELECT scene,target_id,MAX({col}) FROM {table} "
                    "GROUP BY scene,target_id"
                ):
                    key = (str(r[0]), str(r[1]))
                    ts = float(r[2] or 0)
                    if key not in found or ts > found[key]:
                        found[key] = ts
            except sqlite3.Error:
                pass
        conn.close()
    except Exception:  # noqa: BLE001
        return []
    return [
        {"scene": k[0], "target": k[1], "last_at": v}
        for k, v in sorted(found.items(), key=lambda x: -x[1])[:100]
    ]


def _keywords_read() -> dict:
    try:
        data = json.loads(KEYWORDS_PATH.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return {str(k): str(v) for k, v in data.items()}
    except (OSError, ValueError, TypeError):
        pass
    try:
        for line in (QQBOT_DIR / ".env").read_text(
            encoding="utf-8"
        ).splitlines():
            if line.strip().startswith("KEYWORD_RULES="):
                parsed = json.loads(line.partition("=")[2].strip())
                if isinstance(parsed, dict):
                    return {str(k): str(v) for k, v in parsed.items()}
    except (OSError, ValueError, TypeError):
        pass
    return {}


def _keywords_write(rules: dict) -> None:
    KEYWORDS_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = KEYWORDS_PATH.with_name(KEYWORDS_PATH.name + ".tmp")
    tmp.write_text(
        json.dumps(rules, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    os.chmod(tmp, 0o600)
    os.replace(tmp, KEYWORDS_PATH)


def _valid_cron(expr: str) -> bool:
    parts = expr.split()
    if len(parts) != 5:
        return False
    try:
        from apscheduler.triggers.cron import CronTrigger
        CronTrigger.from_crontab(expr)
        return True
    except ImportError:
        return all(re.fullmatch(r"[\d*/,\-]+", p) for p in parts)
    except Exception:  # noqa: BLE001
        return False


async def _push_active(scene, target, content, session, dry_run=False) -> dict:
    """发主动消息；被平台拒绝时按机器人同款逻辑转入待发队列。"""
    if dry_run:
        return {"ok": True, "dry_run": True, "delivered": False,
                "message": "预演模式，未实际发送"}
    Config, QQApi, Store, _ = _bot_imports()
    cfg = Config.from_env()
    cfg.validate()
    api = QQApi(cfg, session)
    result = await api.send(scene=scene, target_id=target, content=content)
    if result.ok:
        return {"ok": True, "delivered": True, "message": "已直接送达"}
    store = Store(cfg.db_path)
    try:
        store.add_pending(scene, target, content)
    finally:
        store.close()
    return {
        "ok": True, "delivered": False, "code": result.code,
        "message": (
            f"主动消息受限（code={result.code} {result.message}），"
            "已转入待发队列，下次有人发言时自动带出"
        ),
    }


async def api_config(request: web.Request) -> web.Response:
    """机器人配置摘要（密钥一律不返回，AppID 打码）。"""
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    out = {"qqbot_dir": str(QQBOT_DIR), "db": str(DB_PATH), "env": {},
           "app_id": "未设置", "app_secret_set": False, "llm_enabled": False,
           "sandbox": False, "error": None}
    try:
        kv = {}
        for line in (QQBOT_DIR / ".env").read_text(
            encoding="utf-8"
        ).splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            kv[k.strip()] = v.strip().strip('"').strip("'")
        out["env"] = {k: kv[k] for k in CONFIG_KEYS if k in kv}
        aid = kv.get("QQ_APP_ID", "")
        out["app_id"] = (
            aid[:4] + "****" + aid[-4:] if len(aid) > 8
            else ("已设置" if aid else "未设置")
        )
        out["app_secret_set"] = bool(kv.get("QQ_APP_SECRET"))
        out["llm_enabled"] = bool(kv.get("LLM_API_KEY"))
        out["sandbox"] = str(kv.get("QQ_SANDBOX", "false")).lower() in {
            "1", "true", "yes", "on"
        }
    except OSError:
        out["error"] = "未找到机器人 .env"
    out["persona"] = _persona_read()["name"]
    out["keywords"] = len(_keywords_read())
    out["keywords_managed"] = KEYWORDS_PATH.exists()
    out["apk"] = APK_NAME
    return _json(out)


async def api_targets(request: web.Request) -> web.Response:
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    return _json({"targets": await asyncio.to_thread(_all_targets)})


async def api_history(request: web.Request) -> web.Response:
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    scene = (request.query.get("scene") or "").strip()
    target = (request.query.get("target") or "").strip()
    if not target:
        return _json({"error": "缺少 target"}, 400)
    try:
        limit = min(max(int(request.query.get("limit", "40")), 1), 100)
    except ValueError:
        limit = 40
    try:
        conn = _db()
        rows = [
            {"role": r["role"], "content": r["content"], "ts": r["ts"]}
            for r in conn.execute(
                "SELECT role,content,ts FROM chat_history "
                "WHERE scene=? AND target_id=? ORDER BY id DESC LIMIT ?",
                (scene, target, limit),
            )
        ]
        conn.close()
    except sqlite3.Error as exc:
        return _json({"error": str(exc)[:150]}, 500)
    rows.reverse()
    return _json({"items": rows, "scene": scene, "target": target})


async def api_history_clear(request: web.Request) -> web.Response:
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    body, err = await _json_body(request)
    if err:
        return err
    scene = str(body.get("scene") or "")
    target = str(body.get("target") or "")
    if not target:
        return _json({"error": "缺少 target"}, 400)
    try:
        conn = _db()
        cur = conn.execute(
            "DELETE FROM chat_history WHERE scene=? AND target_id=?",
            (scene, target),
        )
        conn.commit()
        n = cur.rowcount
        conn.close()
    except sqlite3.Error as exc:
        return _json({"error": str(exc)[:150]}, 500)
    _audit("history_clear", request, f"target={target[-8:]} rows={n}")
    return _json({"ok": True, "deleted": n, "message": f"已清空 {n} 条上下文"})


async def api_chat_test(request: web.Request) -> web.Response:
    """App 内试聊：走真实大模型 + 当前人格，不写入 QQ 会话数据库。"""
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    body, err = await _json_body(request)
    if err:
        return err
    try:
        msg = _text(body.get("message"), 500, "消息")
    except ValueError as exc:
        return _json({"error": str(exc)}, 400)
    hist = body.get("history") or []
    if not isinstance(hist, list):
        return _json({"error": "history 需为数组"}, 400)
    messages = []
    for h in hist[-20:]:
        if not isinstance(h, dict):
            continue
        role = str(h.get("role") or "user")
        if role not in ("user", "assistant"):
            continue
        try:
            messages.append(
                {"role": role, "content": _text(h.get("content"), 1000, "上下文")}
            )
        except ValueError:
            continue
    messages.append({"role": "user", "content": msg})
    try:
        Config, _, _, LLMClient = _bot_imports()
        cfg = Config.from_env()
        if not cfg.llm_api_key:
            return _json({"error": "机器人未配置 LLM_API_KEY，无法试聊"}, 400)
        cli = LLMClient(cfg, request.app["client"])
        reply = await asyncio.wait_for(
            cli.chat(messages), timeout=max(cfg.llm_timeout, 10) + 20
        )
    except Exception as exc:  # noqa: BLE001
        return _json({"error": f"大模型调用失败：{exc}"}, 502)
    _audit("chat_test", request, f"len={len(msg)}")
    return _json({
        "ok": True,
        "reply": reply or "（模型未返回内容）",
        "persona": _persona_read()["name"],
        "model": cfg.llm_model,
    })


async def api_notify(request: web.Request) -> web.Response:
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    body, err = await _json_body(request)
    if err:
        return err
    scene = str(body.get("scene") or "")
    if scene not in SCENES:
        return _json({"error": "scene 需为 group 或 c2c"}, 400)
    try:
        target = _text(body.get("target"), 128, "目标 openid")
        content = _text(body.get("content"), 1000, "通知内容")
    except ValueError as exc:
        return _json({"error": str(exc)}, 400)
    dry = bool(body.get("dry_run"))
    try:
        result = await _push_active(
            scene, target, content, request.app["client"], dry
        )
    except Exception as exc:  # noqa: BLE001
        return _json({"error": f"发送失败：{exc}"}, 502)
    _audit("notify", request,
           f"scene={scene} target={target[-8:]} dry={dry} "
           f"delivered={result.get('delivered')}")
    return _json(result)


async def api_broadcast(request: web.Request) -> web.Response:
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    body, err = await _json_body(request)
    if err:
        return err
    try:
        content = _text(body.get("content"), 1000, "广播内容")
    except ValueError as exc:
        return _json({"error": str(exc)}, 400)
    dry = bool(body.get("dry_run"))
    targets = (await asyncio.to_thread(_all_targets))[:50]
    sent = queued = 0
    errors = []
    if not dry:
        for t in targets:
            try:
                r = await _push_active(
                    t["scene"], t["target"], content, request.app["client"]
                )
                if r.get("delivered"):
                    sent += 1
                else:
                    queued += 1
            except Exception as exc:  # noqa: BLE001
                errors.append(str(exc)[:80])
    _audit("broadcast", request,
           f"targets={len(targets)} dry={dry} sent={sent}")
    return _json({
        "ok": True, "total": len(targets), "sent": sent, "queued": queued,
        "dry_run": dry, "errors": errors[:3],
    })


async def api_queue_get(request: web.Request) -> web.Response:
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    try:
        conn = _db()
        items = [dict(r) for r in conn.execute(
            "SELECT id,scene,target_id,content,ts FROM pending_notice "
            "ORDER BY id ASC LIMIT 200"
        )]
        conn.close()
    except sqlite3.Error as exc:
        return _json({"error": str(exc)[:150]}, 500)
    return _json({"items": items, "count": len(items)})


async def api_queue_post(request: web.Request) -> web.Response:
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    body, err = await _json_body(request)
    if err:
        return err
    action = str(body.get("action") or "")
    deleted = 0
    message = ""
    try:
        conn = _db()
        if action == "delete":
            rid = int(body.get("id") or 0)
            cur = conn.execute("DELETE FROM pending_notice WHERE id=?", (rid,))
            conn.commit()
            deleted, message = cur.rowcount, "已删除"
        elif action == "clear":
            cur = conn.execute("DELETE FROM pending_notice")
            conn.commit()
            deleted, message = cur.rowcount, "队列已清空"
        elif action == "retry":
            rid = int(body.get("id") or 0)
            row = conn.execute(
                "SELECT scene,target_id,content FROM pending_notice WHERE id=?",
                (rid,),
            ).fetchone()
            conn.close()
            if not row:
                return _json({"error": "记录不存在"}, 404)
            r = await _push_active(
                row["scene"], row["target_id"], row["content"],
                request.app["client"],
            )
            if r.get("delivered"):
                conn = _db()
                conn.execute("DELETE FROM pending_notice WHERE id=?", (rid,))
                conn.commit()
                conn.close()
                deleted, message = 1, "重试成功，已从队列移除"
            else:
                message = "重试仍未送达，保留在队列"
        else:
            conn.close()
            return _json({"error": "不支持的操作"}, 400)
        try:
            conn.close()
        except Exception:  # noqa: BLE001
            pass
    except ValueError as exc:
        return _json({"error": str(exc)[:150]}, 400)
    except sqlite3.Error as exc:
        return _json({"error": str(exc)[:150]}, 500)
    _audit("queue_" + action, request, f"rows={deleted}")
    return _json({"ok": True, "deleted": deleted, "message": message})


def _reminder_rows() -> list[dict]:
    try:
        conn = _db()
        rows = [dict(r) for r in conn.execute(
            "SELECT id,scene,target_id,content,cron,enabled,created_at "
            "FROM reminders ORDER BY id ASC"
        )]
        conn.close()
        return rows
    except sqlite3.Error:
        return []


async def api_reminders_get(request: web.Request) -> web.Response:
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    return _json({"items": await asyncio.to_thread(_reminder_rows)})


async def api_reminders_post(request: web.Request) -> web.Response:
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    body, err = await _json_body(request)
    if err:
        return err
    action = str(body.get("action") or "")
    if action not in ("add", "toggle", "delete"):
        return _json({"error": "不支持的操作"}, 400)
    scene = target = cron = content = ""
    rid = 0
    enabled = 0
    try:
        if action == "add":
            scene = str(body.get("scene") or "")
            if scene not in SCENES:
                return _json({"error": "scene 需为 group 或 c2c"}, 400)
            target = _text(body.get("target"), 128, "目标 openid")
            cron = _text(body.get("cron"), 60, "cron 表达式")
            content = _text(body.get("content"), 500, "提醒内容")
            if not _valid_cron(cron):
                return _json({"error": "cron 不是合法的 5 段表达式"}, 400)
        else:
            rid = int(body.get("id") or 0)
            enabled = 1 if body.get("enabled") else 0
    except (ValueError, TypeError) as exc:
        return _json({"error": str(exc)}, 400)
    message = ""
    try:
        conn = _db()
        if action == "add":
            cur = conn.execute(
                "INSERT INTO reminders"
                "(scene,target_id,content,cron,enabled,created_at) "
                "VALUES(?,?,?,?,1,?)",
                (scene, target, content, cron, time.time()),
            )
            conn.commit()
            message = f"已添加 #{cur.lastrowid}，机器人 3 秒内自动加载"
        elif action == "toggle":
            cur = conn.execute(
                "UPDATE reminders SET enabled=? WHERE id=?", (enabled, rid)
            )
            conn.commit()
            message = ("已启用" if enabled else "已暂停") + (
                "" if cur.rowcount else "（未找到该任务）"
            )
        else:
            cur = conn.execute("DELETE FROM reminders WHERE id=?", (rid,))
            conn.commit()
            message = f"已删除 {cur.rowcount} 条"
        conn.close()
    except sqlite3.Error as exc:
        return _json({"error": str(exc)[:180]}, 500)
    _audit("reminder_" + action, request, message[:60])
    return _json({
        "ok": True, "message": message,
        "items": await asyncio.to_thread(_reminder_rows),
    })


async def api_keywords_get(request: web.Request) -> web.Response:
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    rules = await asyncio.to_thread(_keywords_read)
    managed = KEYWORDS_PATH.exists()
    return _json({
        "rules": rules, "file": str(KEYWORDS_PATH),
        "managed": managed,
        "source": "file" if managed else "env",
    })


async def api_keywords_post(request: web.Request) -> web.Response:
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    body, err = await _json_body(request)
    if err:
        return err
    action = str(body.get("action") or "")
    rules = _keywords_read()
    if action == "add":
        try:
            keyword = _text(body.get("keyword"), 50, "关键词")
            answer = _text(body.get("answer"), 500, "回复内容")
        except ValueError as exc:
            return _json({"error": str(exc)}, 400)
        if len(rules) >= 50 and keyword not in rules:
            return _json({"error": "最多 50 条规则"}, 400)
        rules[keyword] = answer
    elif action == "delete":
        keyword = str(body.get("keyword") or "")
        if keyword not in rules:
            return _json({"error": "规则不存在"}, 404)
        rules.pop(keyword, None)
    elif action == "clear":
        rules = {}
    else:
        return _json({"error": "不支持的操作"}, 400)
    try:
        await asyncio.to_thread(_keywords_write, rules)
    except OSError as exc:
        return _json({"error": f"写入失败：{exc}"}, 500)
    _audit("keyword_" + action, request, f"count={len(rules)}")
    return _json({
        "ok": True, "rules": rules, "count": len(rules),
        "message": "已保存，机器人下一条消息立即生效，无需重启",
    })


async def api_audit(request: web.Request) -> web.Response:
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    try:
        lines = ACTION_LOG.read_text(
            encoding="utf-8", errors="replace"
        ).splitlines()[-120:]
    except OSError:
        lines = []
    return _json({"lines": lines})


async def api_group(request: web.Request) -> web.Response:
    """群管理：禁言 / 解禁 / 撤回（官方接口需要手填 openid）。"""
    if not _authorized(request):
        return _json({"error": "unauthorized"}, 401)
    body, err = await _json_body(request)
    if err:
        return err
    action = str(body.get("action") or "")
    if action not in ("mute", "unmute", "recall"):
        return _json({"error": "不支持的操作"}, 400)
    try:
        group = _text(body.get("group"), 128, "群 openid")
        if action == "recall":
            mid = _text(body.get("message_id"), 128, "消息 ID")
            member, minutes = "", 0
        else:
            member = _text(body.get("member"), 128, "成员 openid")
            mid = ""
            minutes = max(1, min(int(body.get("minutes") or 10), 43200))
    except (ValueError, TypeError) as exc:
        return _json({"error": str(exc)}, 400)
    try:
        Config, QQApi, _, _ = _bot_imports()
        cfg = Config.from_env()
        cfg.validate()
        api = QQApi(cfg, request.app["client"])
        if action == "recall":
            status, data = await api.recall(group, mid)
        elif action == "mute":
            status, data = await api.mute_member(
                group, member, minutes * 60, "add"
            )
        else:
            status, data = await api.mute_member(group, member, 0, "del")
    except Exception as exc:  # noqa: BLE001
        return _json({"error": f"调用失败：{exc}"}, 502)
    ok = 200 <= status < 300 and not (
        isinstance(data, dict) and data.get("code")
    )
    _audit("group_" + action, request, f"ok={ok}")
    return _json({
        "ok": ok, "status": status,
        "data": data if isinstance(data, dict) else {"raw": str(data)[:200]},
    })


async def spa(_request: web.Request) -> web.Response:
    return web.FileResponse(
        ROOT / "index.html",
        headers={
            "Content-Type": "text/html; charset=utf-8",
            "Cache-Control": "no-cache",
        },
    )


async def manifest(_request: web.Request) -> web.Response:
    return web.FileResponse(
        ROOT / "manifest.webmanifest",
        headers={"Content-Type": "application/manifest+json; charset=utf-8"},
    )


async def sw(_request: web.Request) -> web.Response:
    return web.FileResponse(
        ROOT / "sw.js",
        headers={
            "Content-Type": "application/javascript; charset=utf-8",
            "Service-Worker-Allowed": "/",
            "Cache-Control": "no-cache",
        },
    )


async def icon(request: web.Request) -> web.Response:
    name = request.match_info["name"]
    if name not in ("icon-192.png", "icon-512.png"):
        raise web.HTTPNotFound()
    return web.FileResponse(
        ROOT / name, headers={"Content-Type": "image/png"}
    )


async def download_page(_request: web.Request) -> web.Response:
    """安卓客户端下载页（公开，无需 Token）。"""
    return web.FileResponse(
        ROOT / "download.html",
        headers={
            "Content-Type": "text/html; charset=utf-8",
            "Cache-Control": "no-cache",
        },
    )


async def apk_file(request: web.Request) -> web.Response:
    """APK 直链（公开，无需 Token）。仅服务 app/ 目录下的 .apk 文件。"""
    name = request.match_info["name"]
    path = APK_DIR / name
    if not name.endswith(".apk") or not path.is_file():
        raise web.HTTPNotFound()
    return web.FileResponse(
        path,
        headers={
            "Content-Type": "application/vnd.android.package-archive",
            "Content-Disposition": f'attachment; filename="{name}"',
            "Cache-Control": "no-cache",
        },
    )


async def client_session_ctx(app: web.Application):
    app["client"] = aiohttp.ClientSession()
    yield
    await app["client"].close()


def make_app() -> web.Application:
    app = web.Application()
    # 手机控制台「QQ 机器人设置」全量功能
    import ext_settings
    ext_settings.setup({
        "json": _json,
        "authorized": _authorized,
        "audit": _audit,
        "qqbot_dir": QQBOT_DIR,
        "root": ROOT,
        "service": SERVICE,
    })
    ext_settings.register(app)
    app.cleanup_ctx.append(client_session_ctx)
    app.router.add_get("/", spa)
    app.router.add_get("/index.html", spa)
    app.router.add_get("/api/status", api_status)
    app.router.add_get("/api/logs", api_logs)
    app.router.add_post("/api/action", api_action)
    app.router.add_get("/api/persona", api_persona_get)
    app.router.add_post("/api/persona", api_persona_post)
    # 扩展：手机控制台全功能
    app.router.add_get("/api/config", api_config)
    app.router.add_get("/api/targets", api_targets)
    app.router.add_get("/api/history", api_history)
    app.router.add_post("/api/history/clear", api_history_clear)
    app.router.add_post("/api/chat/test", api_chat_test)
    app.router.add_post("/api/notify", api_notify)
    app.router.add_post("/api/broadcast", api_broadcast)
    app.router.add_get("/api/queue", api_queue_get)
    app.router.add_post("/api/queue", api_queue_post)
    app.router.add_get("/api/reminders", api_reminders_get)
    app.router.add_post("/api/reminders", api_reminders_post)
    app.router.add_get("/api/keywords", api_keywords_get)
    app.router.add_post("/api/keywords", api_keywords_post)
    app.router.add_get("/api/audit", api_audit)
    app.router.add_post("/api/group", api_group)
    app.router.add_route("OPTIONS", "/{tail:.*}", options_handler)
    app.router.add_get("/manifest.webmanifest", manifest)
    app.router.add_get("/sw.js", sw)
    app.router.add_get("/{name:icon-(192|512)\\.png}", icon)
    app.router.add_get("/app/", download_page)
    app.router.add_get("/app", download_page)
    app.router.add_get(r"/app/{name:[\w.\-]+\.apk}", apk_file)
    return app


if __name__ == "__main__":
    print(f"[monitor] listening on {HOST}:{PORT}", flush=True)
    web.run_app(make_app(), host=HOST, port=PORT, access_log=None)
