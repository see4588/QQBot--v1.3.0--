"""手机控制台 · QQ 机器人「设置」全量功能。

提供：
  /api/settings           读取完整配置 schema + 当前值（密钥不回传）
  /api/settings           POST 批量保存 .env（备份、校验、可选重启）
  /api/settings/backups   备份列表
  /api/settings/rollback  回滚
  /api/capabilities       机器人功能开关（热生效）
  /api/commands           指令清单
  /api/platform           开放平台：机器人资料 / 网关 / 频道 / 菜单 / 指令面板
  /api/platform/group     群资料 / 成员 / 入群申请 / 黑名单 / 禁言 / 审批策略
  /api/platform/join      入群申请审批
  /api/platform/menu      自定义菜单保存
  /api/platform/call      白名单内的通用官方 API 调用（覆盖其余设置项）

所有接口由主程序注入鉴权与审计函数，密钥一律不写入日志。
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
from datetime import datetime
from pathlib import Path

import aiohttp
from aiohttp import web

_CTX: dict = {}


def setup(ctx: dict) -> None:
    """由 server.py 注入 json / authorized / audit / qqbot_dir / service。"""
    _CTX.update(ctx)


def _json(data, status=200):
    return _CTX["json"](data, status)


def _auth(request: web.Request) -> bool:
    return _CTX["authorized"](request)


def _audit(action: str, request: web.Request, detail: str = "") -> None:
    _CTX["audit"](action, request, detail)


def _env_path() -> Path:
    return Path(_CTX["qqbot_dir"]) / ".env"


def _caps_path() -> Path:
    return Path(_CTX["qqbot_dir"]) / "capabilities.json"


def _backup_dir() -> Path:
    return Path(_CTX["root"]) / "backups"


# ---------------------------------------------------------------- 配置定义
SETTING_GROUPS = [
    {"id": "basic", "name": "基础", "desc": "机器人身份、欢迎语、消息行为"},
    {"id": "access", "name": "接入", "desc": "QQ 开放平台凭据与事件订阅"},
    {"id": "ai", "name": "AI", "desc": "大模型、系统提示词、上下文"},
    {"id": "runtime", "name": "运行", "desc": "日志、健康检查、数据路径"},
    {"id": "plugins", "name": "插件", "desc": "识图 / 积分 / 娱乐 / 工具 插件的开关与接入配置"},
    {"id": "voice", "name": "语音", "desc": "BreezeBlue 语音合成：音色、语气、自动语音"},
    {"id": "advanced", "name": "高级", "desc": "接口地址、关键词规则、人格路径"},
]

BOOL_TRUE = {"1", "true", "yes", "on"}
SENSITIVE_KEYS = ("QQ_APP_SECRET", "LLM_API_KEY", "VISION_API_KEY", "TTS_API_KEY")
# 由 systemd unit 以 Environment= 固定，改 .env 不会生效，因此只读展示
SYSTEMD_FIXED = {
    "QQ_DB_PATH": "systemd 单元已固定为 /opt/qqbot/data/bot.db",
    "LOG_DIR": "systemd 单元已固定为 /opt/qqbot/logs",
}


def _s(key, group, label, typ, help_text, default="", **kw):
    item = {
        "key": key, "group": group, "label": label, "type": typ,
        "help": help_text, "default": default, "restart": True,
    }
    item.update(kw)
    return item


SETTINGS_SCHEMA = [
    # 基础
    _s("BOT_NAME", "basic", "机器人名称", "text",
       "用在 /状态、欢迎语与指令菜单里的名字", "小助手", placeholder="小助手"),
    _s("WELCOME_TEXT", "basic", "欢迎语", "textarea",
       "入群 / 加好友时自动发送，{name} 会替换成机器人名称",
       "大家好，我是{name}～ @我或私聊我都能聊天，发 /帮助 查看全部功能。"),
    _s("BOT_ADMIN_OPENIDS", "basic", "管理员 OpenID", "text",
       "多个用英文逗号分隔；群主/管理员身份也会自动识别", "",
       placeholder="留空表示仅群主/群管理员"),
    _s("MAX_REPLY_CHARS", "basic", "单条回复上限", "number",
       "超长自动截断，避免被平台拒绝", "1500", min=50, max=4000, unit="字"),
    _s("MAX_PENDING_FLUSH", "basic", "待发通知带出条数", "number",
       "主动消息发送失败后，借下一条被动回复带出的最大条数", "3",
       min=0, max=20, unit="条"),
    _s("KEYWORD_RULES", "basic", "关键词规则（JSON）", "json",
       "命中「包含」即回复；手机「自动化 → 关键词回复」写入的 keywords.json 优先级更高",
       '{"你好":"你好呀～"}'),
    # 接入
    _s("QQ_APP_ID", "access", "AppID", "text",
       "QQ 开放平台应用 ID（机器人设置 → 开发设置）", "", placeholder="你的QQ机器人AppID"),
    _s("QQ_APP_SECRET", "access", "AppSecret", "password",
       "应用密钥，留空表示不修改；修改后需重启机器人", "", sensitive=True),
    _s("QQ_SANDBOX", "access", "沙箱环境", "bool",
       "开启后连接沙箱域名；机器人正式上线后请关闭", "true"),
    _s("QQ_INTENTS", "access", "事件订阅 intents", "intents",
       "勾选需要订阅的事件，会自动换算成数值；未开通的 intent 会报 4014", "33554432"),
    # AI
    _s("LLM_API_KEY", "ai", "大模型 API Key", "password",
       "留空表示不修改；清空后 AI 聊天会降级为指令提示", "", sensitive=True),
    _s("LLM_BASE_URL", "ai", "接口地址", "text",
       "任何 OpenAI 兼容服务，DeepSeek 为 https://api.deepseek.com/v1",
       "https://api.deepseek.com/v1"),
    _s("LLM_MODEL", "ai", "模型", "text",
       "DeepSeek 可用 deepseek-flash / deepseek-v4-pro", "deepseek-flash",
       options=[["deepseek-flash", "deepseek-flash（快·便宜）"],
                ["deepseek-v4-pro", "deepseek-v4-pro（更强）"],
                ["deepseek-chat", "deepseek-chat（兼容别名）"]]),
    _s("LLM_SYSTEM_PROMPT", "ai", "系统提示词", "textarea",
       "当 persona.json 存在时以其为准；此处为兜底提示词",
       "你是 QQ 上的智能助手。回答要简洁、友好、口语化。"),
    _s("LLM_TIMEOUT", "ai", "请求超时", "number",
       "大模型单次请求超时时间", "60", min=5, max=300, unit="秒"),
    _s("HISTORY_LIMIT", "ai", "上下文条数", "number",
       "每个会话保留的历史消息条数，越大越耗 token", "12", min=0, max=50, unit="条"),
    # 运行
    _s("LOG_LEVEL", "runtime", "日志级别", "select",
       "DEBUG 会产生大量日志，建议保持 INFO", "INFO",
       options=[["DEBUG", "DEBUG"], ["INFO", "INFO"],
                ["WARNING", "WARNING"], ["ERROR", "ERROR"]]),
    _s("HEALTH_ENABLED", "runtime", "健康检查端点", "bool",
       "本机 127.0.0.1:8080/healthz，监控台依赖它采集业务状态", "true"),
    _s("HEALTH_HOST", "runtime", "健康检查地址", "text",
       "仅监听本机时保持 127.0.0.1", "127.0.0.1"),
    _s("HEALTH_PORT", "runtime", "健康检查端口", "number",
       "修改后监控台 config.json 的 health_url 也需同步", "8080",
       min=1, max=65535, unit="端口"),
    _s("QQ_DB_PATH", "runtime", "数据库路径", "text",
       "SQLite 数据文件位置", "/app/data/bot.db", readonly=True),
    _s("LOG_DIR", "runtime", "日志目录", "text",
       "bot.log 所在目录", "/app/logs", readonly=True),
    # 高级
    _s("QQ_API_BASE", "advanced", "API 域名", "text",
       "留空则按沙箱开关自动选择 api.sgroup.qq.com / api.bot.qq.com", "",
       placeholder="留空 = 自动"),
    _s("QQ_TOKEN_URL", "advanced", "Token 接口", "text",
       "获取 access_token 的地址，一般不用改",
       "https://bots.qq.com/app/getAppAccessToken"),
    _s("PERSONA_PATH", "advanced", "人格文件路径", "text",
       "留空则使用项目根目录 persona.json", "", placeholder="留空 = 默认"),
    _s("KEYWORD_RULES", "advanced", "关键词规则（.env 兜底）", "json",
       "与「基础」分组里的 KEYWORD_RULES 是同一项", '{}', duplicate=True),
    # 插件
    _s("VISION_ENABLED", "plugins", "识图功能总开关", "bool",
       "关闭后机器人不再识别图片", "true"),
    _s("VISION_USE_OCR", "plugins", "本地 OCR 兜底", "bool",
       "开启后无视觉模型时也能识别图中文字（需服务器装 Tesseract）", "true"),
    _s("VISION_BASE_URL", "plugins", "视觉模型接口", "text",
       "OpenAI 兼容多模态接口，如 https://api.openai.com/v1；留空则只用 OCR", "",
       placeholder="https://api.openai.com/v1"),
    _s("VISION_API_KEY", "plugins", "视觉模型 Key", "password",
       "多模态接口密钥，留空表示不修改", "", sensitive=True),
    _s("VISION_MODEL", "plugins", "视觉模型名", "text",
       "如 gpt-4o-mini / qwen-vl-plus，留空用接口默认", "", placeholder="gpt-4o-mini"),
    _s("WEATHER_DEFAULT_CITY", "plugins", "默认天气城市", "text",
       "/天气 不带城市时使用", "北京", placeholder="北京"),
    # 语音
    _s("TTS_ENABLED", "voice", "语音总开关", "bool",
       "关闭后不再合成任何语音；还需在「功能」页打开自动语音开关", "false"),
    _s("TTS_API_KEY", "voice", "BreezeBlue API Key", "password",
       "留空表示不修改；在 BreezeBlue 控制台开发者页获取", "", sensitive=True),
    _s("TTS_VOICE_ID", "voice", "音色 ID", "text",
       "必填：在控制台 Voice 页复制真实 ID（形如 voc_xxx），留空则自动关闭语音；"
       "也可调 GET /v1/voices 列出账号音色", "",
       placeholder="voc_xxxxxxxxxxxx（Voice 页复制）"),
    _s("TTS_MODEL", "voice", "语音模型", "text",
       "BreezeBlue 模型名", "breeze-tts-2"),
    _s("TTS_INSTRUCTIONS", "voice", "语气引导", "textarea",
       "用中文写「怎么演」：语气/情绪/语速，如「语速稍慢、温柔带笑意，像在关心朋友」。"
       "必须与回复正文同语言，音色本身由音色 ID 决定", ""),
    _s("TTS_GUIDANCE_SCALE", "voice", "语气引导强度", "select",
       "数值越大越听语气引导的话，但过高可能让音色失真；4.0 为官方推荐值",
       "4.0",
       options=[["1.0", "1.0（弱，贴近原音色）"], ["2.0", "2.0"],
                ["3.0", "3.0"], ["4.0", "4.0（官方推荐）"],
                ["5.0", "5.0（强）"]]),
    _s("TTS_BASE_URL", "voice", "接口地址", "text",
       "BreezeBlue API 根地址，一般不用改", "https://api.breeze.blue/v1"),
    _s("TTS_MAX_CHARS", "voice", "转语音字数上限", "number",
       "超过此长度的 AI 回复只发文字，避免长语音刷屏", "300",
       min=20, max=1000, unit="字"),
    _s("TTS_TIMEOUT", "voice", "合成超时", "number",
       "单次语音合成请求超时", "30", min=5, max=120, unit="秒"),
    _s("TTS_SERVE_HOST", "voice", "兜底回传地址", "text",
       "仅二进制直传失败时才用到，填公网 IP/域名；默认 127.0.0.1 表示不启用",
       "127.0.0.1"),
    _s("TTS_SERVE_PORT", "voice", "兜底回传端口", "number",
       "URL 回拉模式的临时文件端口，需在防火墙/安全组放行", "18080",
       min=1, max=65535, unit="端口"),
]

# 去掉重复展示项（仅保留第一次出现）
_seen = set()
SETTINGS_SCHEMA = [
    x for x in SETTINGS_SCHEMA
    if not (x["key"] in _seen or _seen.add(x["key"]))
]

SCHEMA_BY_KEY = {x["key"]: x for x in SETTINGS_SCHEMA}

# 事件订阅位（QQ 开放平台 v2 intents）
INTENT_BITS = [
    {"bit": 0, "name": "GUILDS", "label": "频道创建/更新/解散", "note": "频道"},
    {"bit": 1, "name": "GUILD_MEMBERS", "label": "频道成员变动", "note": "频道"},
    {"bit": 9, "name": "GUILD_MESSAGES", "label": "频道消息（已废弃）", "note": "频道"},
    {"bit": 12, "name": "DIRECT_MESSAGE", "label": "频道私信", "note": "频道"},
    {"bit": 25, "name": "GROUP_AND_C2C_EVENT", "label": "群@消息 / 单聊 / 加群退群", "note": "必开"},
    {"bit": 26, "name": "INTERACTION", "label": "互动事件（按钮/菜单）", "note": "互动"},
    {"bit": 27, "name": "MESSAGE_AUDIT", "label": "消息审核", "note": "审核"},
    {"bit": 30, "name": "PUBLIC_GUILD_MESSAGES", "label": "频道全量消息", "note": "频道"},
]

COMMANDS = [
    {"cmd": "/帮助", "alias": "/help /菜单 /menu", "desc": "显示全部指令", "admin": False, "cap": "commands"},
    {"cmd": "/状态", "alias": "/status /info", "desc": "运行时间、AI、定时任务、待发数", "admin": False, "cap": "commands"},
    {"cmd": "/清空", "alias": "/clear /重置", "desc": "清空当前会话聊天上下文", "admin": False, "cap": "commands"},
    {"cmd": "/关键词", "alias": "—", "desc": "查看关键词自动回复规则", "admin": False, "cap": "keywords"},
    {"cmd": "/通知 <内容>", "alias": "—", "desc": "向当前会话发一条主动通知", "admin": True, "cap": "commands"},
    {"cmd": "/广播 <内容>", "alias": "—", "desc": "广播到所有已知会话", "admin": True, "cap": "commands"},
    {"cmd": "/提醒 列表", "alias": "/提醒", "desc": "查看定时提醒", "admin": False, "cap": "reminder"},
    {"cmd": "/提醒 添加 <cron> :: <内容>", "alias": "—", "desc": "新增定时提醒，如 0 9 * * *", "admin": True, "cap": "reminder"},
    {"cmd": "/提醒 删除|暂停|恢复 <id>", "alias": "—", "desc": "管理定时提醒", "admin": True, "cap": "reminder"},
    {"cmd": "/禁言 <分钟> @成员", "alias": "—", "desc": "群内禁言指定成员", "admin": True, "cap": "group_admin"},
    {"cmd": "/解禁 <openid>", "alias": "—", "desc": "解除禁言", "admin": True, "cap": "group_admin"},
    {"cmd": "/撤回", "alias": "/recall", "desc": "撤回触发指令的那条消息", "admin": True, "cap": "group_admin"},
    {"cmd": "/识图 [问题]", "alias": "/看图 /ocr", "desc": "识别图片（直接发图也可自动识别）", "admin": False, "cap": "vision"},
    {"cmd": "/签到", "alias": "—", "desc": "每日签到，连续天数越多奖励越多", "admin": False, "cap": "checkin"},
    {"cmd": "/积分", "alias": "—", "desc": "查看我的积分余额与连续天数", "admin": False, "cap": "checkin"},
    {"cmd": "/排行榜", "alias": "/积分榜", "desc": "积分榜前 10", "admin": False, "cap": "checkin"},
    {"cmd": "/打赏 @成员 <数量>", "alias": "—", "desc": "把积分转给别人", "admin": False, "cap": "checkin"},
    {"cmd": "/抽签", "alias": "—", "desc": "随机抽一签", "admin": False, "cap": "fun"},
    {"cmd": "/运势 [星座]", "alias": "—", "desc": "今日运势百分比", "admin": False, "cap": "fun"},
    {"cmd": "/掷骰子 [n]d[m]", "alias": "/掷骰", "desc": "掷骰子，默认 1d6", "admin": False, "cap": "fun"},
    {"cmd": "/猜拳 [出拳]", "alias": "—", "desc": "和机器人划拳", "admin": False, "cap": "fun"},
    {"cmd": "/成语 [词语]", "alias": "—", "desc": "成语接龙", "admin": False, "cap": "fun"},
    {"cmd": "/翻译 <文字>", "alias": "—", "desc": "中英互译（需 AI）", "admin": False, "cap": "tools"},
    {"cmd": "/天气 [城市]", "alias": "—", "desc": "查询城市天气", "admin": False, "cap": "tools"},
    {"cmd": "/计算 <表达式>", "alias": "/算", "desc": "安全算术计算", "admin": False, "cap": "tools"},
    {"cmd": "/百科 <词条>", "alias": "—", "desc": "一句话百科（需 AI）", "admin": False, "cap": "tools"},
]

CAP_DEFS = [
    {"key": "ai_chat", "name": "AI 聊天", "desc": "未命中指令/关键词时交给大模型回复"},
    {"key": "keywords", "name": "关键词自动回复", "desc": "命中关键词直接返回固定文案"},
    {"key": "commands", "name": "斜杠指令", "desc": "/帮助 /状态 /清空 等全部指令"},
    {"key": "welcome", "name": "入群/加好友欢迎语", "desc": "新成员进群或添加机器人时自动打招呼"},
    {"key": "pending_flush", "name": "待发通知带出", "desc": "主动消息失败后借下一条回复补发"},
    {"key": "reminder", "name": "定时提醒", "desc": "cron 定时任务与其指令"},
    {"key": "group_admin", "name": "群管理指令", "desc": "/禁言 /解禁 /撤回"},
    {"key": "dedupe", "name": "消息去重", "desc": "忽略平台重复推送（建议开启）"},
    {"key": "vision", "name": "识图（图片识别）", "desc": "识别图片：本地 OCR + 可选多模态大模型"},
    {"key": "checkin", "name": "签到积分", "desc": "/签到 /积分 /排行榜 /打赏"},
    {"key": "fun", "name": "娱乐插件", "desc": "/抽签 /运势 /掷骰子 /猜拳 /成语接龙"},
    {"key": "tools", "name": "实用工具", "desc": "/翻译 /天气 /计算 /百科"},
    {"key": "tts_auto", "name": "AI 回复自动语音",
     "desc": "每条 AI 回复额外发一条语音（需配置 TTS_API_KEY 并开启语音总开关）"},
]

PLUGINS = [
    {
        "key": "vision", "name": "识图 / 图片识别", "cap": "vision",
        "desc": "识别用户发来的图片。配了 OpenAI 兼容多模态接口就「看图说话」，"
                "没配也能用本地 Tesseract OCR 提取图中文字。直接在群里/私聊发图会触发自动识别。",
        "commands": ["/识图 [问题]", "/看图 [问题]", "/ocr [问题]"],
        "config": ["VISION_ENABLED", "VISION_USE_OCR", "VISION_BASE_URL",
                   "VISION_API_KEY", "VISION_MODEL"],
    },
    {
        "key": "checkin", "name": "签到积分", "cap": "checkin",
        "desc": "群/私聊都能签到攒积分，连续天数越多奖励越高，可查看排行榜、把积分转给别人。",
        "commands": ["/签到", "/积分", "/排行榜", "/打赏 @成员 <数量>"],
        "config": [],
    },
    {
        "key": "fun", "name": "娱乐", "cap": "fun",
        "desc": "抽签、今日运势、掷骰子、石头剪刀布、成语接龙，活跃群气氛。",
        "commands": ["/抽签", "/运势 [星座]", "/掷骰子 [n]d[m]",
                     "/猜拳 [出拳]", "/成语 [词语]"],
        "config": [],
    },
    {
        "key": "tools", "name": "实用工具", "cap": "tools",
        "desc": "翻译、天气、安全计算、一句话百科，日常小工具。天气用 wttr.in，无需额外 Key。",
        "commands": ["/翻译 <文字>", "/天气 [城市]", "/计算 <表达式>", "/百科 <词条>"],
        "config": ["WEATHER_DEFAULT_CITY"],
    },
    {
        "key": "tts", "name": "AI 语音（BreezeBlue TTS）", "cap": "tts_auto",
        "desc": "把 AI 文字回复合成成语音消息发出来。默认走 QQ 二进制直传，无需公网地址或开端口；未填 API Key 时自动静默关闭，不影响文字聊天。",
        "commands": [],
        "config": ["TTS_ENABLED", "TTS_API_KEY", "TTS_VOICE_ID", "TTS_MODEL",
                   "TTS_INSTRUCTIONS", "TTS_GUIDANCE_SCALE", "TTS_MAX_CHARS", "TTS_BASE_URL",
                   "TTS_TIMEOUT", "TTS_SERVE_HOST", "TTS_SERVE_PORT"],
    },
]
CAP_KEYS = [x["key"] for x in CAP_DEFS]

# 通用 API 透传白名单前缀（防止被用来访问非 QQ 官方接口）
CALL_PREFIXES = (
    "/v2/", "/users/", "/gateway", "/guilds/", "/channels/",
    "/interactions/",
)


# ---------------------------------------------------------------- .env 读写
def _unquote(raw: str) -> str:
    """与 bot/config.py 的解析规则保持一致：JSON 双引号或单引号包裹。"""
    if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] == '"':
        try:
            val = json.loads(raw)
            return val if isinstance(val, str) else raw[1:-1]
        except (ValueError, TypeError):
            return raw[1:-1]
    if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] == "'":
        return raw[1:-1].replace("\\'", "'")
    return raw


def _quote(value: str) -> str:
    """仅当值含空白 / 引号 / # 时用 JSON 双引号包裹，保证可无损还原。"""
    if value == "":
        return '""'
    if any(ch in value for ch in ' \t\r\n#"\'') or value.startswith(";"):
        return json.dumps(value, ensure_ascii=False)
    return value


def _read_env_lines() -> list[str]:
    p = _env_path()
    if not p.is_file():
        return []
    return p.read_text(encoding="utf-8").splitlines()


def _read_env() -> dict:
    out: dict[str, str] = {}
    for line in _read_env_lines():
        s = line.strip()
        if not s or s.startswith("#") or "=" not in s:
            continue
        k, _, v = s.partition("=")
        out[k.strip()] = _unquote(v.strip())
    return out


def _mask(value: str) -> str:
    if not value:
        return ""
    if len(value) <= 8:
        return value[:2] + "****"
    return value[:4] + "****" + value[-4:]


def _settings_values() -> tuple[dict, dict]:
    kv = _read_env()
    values, masked = {}, {}
    for item in SETTINGS_SCHEMA:
        key = item["key"]
        val = kv.get(key, item.get("default", ""))
        if key in SENSITIVE_KEYS:
            values[key] = "__SET__" if val else ""
            masked[key] = _mask(val)
        else:
            values[key] = val
            masked[key] = ""
    return values, masked


def _validate_value(item: dict, value: str) -> str | None:
    """返回错误信息，None 表示通过。"""
    key, typ = item["key"], item["type"]
    if any(ch in value for ch in "\r\n\x00"):
        return f"{key} 不能包含换行或控制字符"
    if len(value) > 4000:
        return f"{key} 内容过长（上限 4000 字）"
    if typ == "bool":
        if value.strip().lower() not in BOOL_TRUE | {"0", "false", "no", "off"}:
            return f"{key} 只能是 true / false"
    elif typ == "number":
        try:
            n = int(value)
        except (ValueError, TypeError):
            return f"{key} 必须是整数"
        lo, hi = item.get("min", -10**9), item.get("max", 10**9)
        if not lo <= n <= hi:
            return f"{key} 需在 {lo}–{hi} 之间"
    elif typ == "select":
        allowed = [o[0] for o in item.get("options", [])]
        if value not in allowed:
            return f"{key} 取值不合法"
    elif typ == "intents":
        try:
            n = int(value)
        except (ValueError, TypeError):
            return f"{key} 必须是整数"
        if not 0 <= n <= (1 << 31) - 1:
            return f"{key} 超出范围"
    elif typ == "json":
        if value.strip():
            try:
                parsed = json.loads(value)
            except (ValueError, TypeError):
                return f"{key} 不是合法 JSON"
            if not isinstance(parsed, dict):
                return f"{key} 需为 JSON 对象"
    elif typ in ("text", "password", "textarea"):
        if typ == "text" and value and not value.startswith(("http://", "https://")):
            pass  # 普通文本，不做限制
    if key in ("QQ_API_BASE", "QQ_TOKEN_URL", "LLM_BASE_URL", "VISION_BASE_URL") and value:
        if not value.startswith(("http://", "https://")):
            return f"{key} 必须以 http(s):// 开头"
    return None


def _write_env(changes: dict[str, str]) -> list[str]:
    """保留注释与顺序，逐行替换已有键；新键追加到末尾。返回实际改动键。"""
    lines = _read_env_lines()
    out, seen = [], set()
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("#") or "=" not in stripped:
            out.append(line)
            continue
        key = stripped.partition("=")[0].strip()
        if key in changes:
            out.append(f"{key}={_quote(changes[key])}")
            seen.add(key)
        else:
            out.append(line)
    missing = [k for k in changes if k not in seen]
    if missing:
        if out and out[-1].strip():
            out.append("")
        out.append("# ↓ 由手机控制台新增的配置项")
        for k in missing:
            out.append(f"{k}={_quote(changes[k])}")
    p = _env_path()
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text("\n".join(out).rstrip() + "\n", encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, p)
    return list(changes)


def _backup_env() -> str:
    d = _backup_dir()
    d.mkdir(parents=True, exist_ok=True)
    name = ".env." + datetime.now().strftime("%Y%m%d-%H%M%S") + ".bak"
    dst = d / name
    shutil.copy2(_env_path(), dst)
    os.chmod(dst, 0o600)
    files = sorted(d.glob(".env.*.bak"), key=lambda x: x.name, reverse=True)
    for old in files[12:]:
        old.unlink(missing_ok=True)
    return name


def _list_backups() -> list[dict]:
    d = _backup_dir()
    if not d.is_dir():
        return []
    rows = []
    for f in sorted(d.glob(".env.*.bak"), key=lambda x: x.name, reverse=True):
        st = f.stat()
        rows.append({
            "file": f.name,
            "size": st.st_size,
            "at": datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds"),
        })
    return rows


async def _restart_bot() -> tuple[bool, str]:
    try:
        r = await asyncio.to_thread(
            __import__("subprocess").run,
            ["systemctl", "restart", _CTX["service"]],
            capture_output=True, text=True, timeout=30,
        )
        return r.returncode == 0, (r.stdout + r.stderr).strip()[:200]
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)[:200]


# ---------------------------------------------------------------- 能力开关
def _read_caps() -> dict:
    try:
        data = json.loads(_caps_path().read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except (OSError, ValueError, TypeError):
        pass
    return {}


def _write_caps(data: dict) -> None:
    p = _caps_path()
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, p)


# ---------------------------------------------------------------- 开放平台
async def _platform_token(session: aiohttp.ClientSession, kv: dict) -> str:
    app_id = kv.get("QQ_APP_ID", "").strip()
    secret = kv.get("QQ_APP_SECRET", "").strip()
    if not app_id or not secret:
        raise RuntimeError("未配置 QQ_APP_ID / QQ_APP_SECRET")
    url = kv.get("QQ_TOKEN_URL", "").strip() or "https://bots.qq.com/app/getAppAccessToken"
    async with session.post(
        url,
        json={"appId": app_id, "clientSecret": secret},
        timeout=aiohttp.ClientTimeout(total=15),
    ) as r:
        raw = await r.text()
    try:
        data = json.loads(raw) if raw else {}
    except ValueError:
        data = {}
    token = data.get("access_token") if isinstance(data, dict) else None
    if not token:
        raise RuntimeError("获取 access_token 失败：" + str(data)[:160])
    return token


def _platform_base(kv: dict) -> str:
    explicit = kv.get("QQ_API_BASE", "").strip()
    if explicit:
        return explicit.rstrip("/")
    sandbox = str(kv.get("QQ_SANDBOX", "false")).strip().lower() in BOOL_TRUE
    return "https://api.sgroup.qq.com" if sandbox else "https://api.bot.qq.com"


async def _platform_call(
    session: aiohttp.ClientSession, base: str, token: str,
    method: str, path: str, body=None,
) -> dict:
    kwargs = {
        "headers": {"Authorization": f"QQBot {token}"},
        "timeout": aiohttp.ClientTimeout(total=15),
    }
    if body is not None:
        kwargs["json"] = body
    async with session.request(method, base + path, **kwargs) as r:
        raw = await r.text()
        try:
            data = json.loads(raw) if raw else {}
        except ValueError:
            data = {"raw": raw[:500]}
    err = data.get("err_code") if isinstance(data, dict) else None
    ok = r.status < 400 and err in (None, 0)
    return {"ok": ok, "status": r.status, "data": data}


def _safe_openid(value: str) -> bool:
    return bool(re.fullmatch(r"[A-Za-z0-9_\-]{4,128}", value or ""))


def _safe_path(path: str) -> bool:
    return (
        isinstance(path, str) and path.startswith(CALL_PREFIXES)
        and ".." not in path and " " not in path
        and not path.startswith("//")
    )


# ---------------------------------------------------------------- HTTP 处理
async def api_settings_get(request: web.Request) -> web.Response:
    if not _auth(request):
        return _json({"error": "unauthorized"}, 401)
    values, masked = await asyncio.to_thread(_settings_values)
    caps = await asyncio.to_thread(_read_caps)
    return _json({
        "ok": True,
        "groups": SETTING_GROUPS,
        "schema": SETTINGS_SCHEMA,
        "values": values,
        "masked": masked,
        "sensitive": list(SENSITIVE_KEYS),
        "fixed": SYSTEMD_FIXED,
        "intents_bits": INTENT_BITS,
        "commands": COMMANDS,
        "cap_defs": CAP_DEFS,
        "plugins": PLUGINS,
        "caps": {k: bool(caps.get(k, True)) for k in CAP_KEYS},
        "backups": await asyncio.to_thread(_list_backups),
        "env_path": str(_env_path()),
        "service": _CTX["service"],
    })


async def api_settings_post(request: web.Request) -> web.Response:
    if not _auth(request):
        return _json({"error": "unauthorized"}, 401)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _json({"error": "请求体不是合法 JSON"}, 400)
    if not isinstance(body, dict) or not isinstance(body.get("values"), dict):
        return _json({"error": "缺少 values 对象"}, 400)
    restart = bool(body.get("restart", True))
    raw_values = body["values"]

    changes: dict[str, str] = {}
    errors: list[str] = []
    for key, value in raw_values.items():
        item = SCHEMA_BY_KEY.get(key)
        if not item or item.get("readonly"):
            continue
        value = "" if value is None else str(value)
        if key in SENSITIVE_KEYS and value in ("", "__SET__"):
            continue  # 空 = 保持原密钥不变
        err = _validate_value(item, value)
        if err:
            errors.append(err)
            continue
        changes[key] = value.strip() if item["type"] in (
            "text", "password", "number", "select", "intents"
        ) else value
    if errors:
        return _json({"error": "；".join(errors[:5])}, 400)
    if not changes:
        return _json({"ok": True, "changed": [], "message": "没有需要保存的改动",
                      "restarted": False})
    try:
        backup = await asyncio.to_thread(_backup_env)
        await asyncio.to_thread(_write_env, changes)
    except Exception as exc:  # noqa: BLE001
        return _json({"error": f"写入 .env 失败：{exc}"}, 500)
    _audit("settings.save", request,
           "keys=" + ",".join(changes) + " backup=" + backup)
    restarted, msg = False, ""
    if restart:
        restarted, msg = await _restart_bot()
        _audit("settings.restart", request, f"ok={restarted}")
    return _json({
        "ok": True, "changed": list(changes), "backup": backup,
        "restarted": restarted, "message": msg,
        "tip": "已保存并重启，网关约 2–5 秒后重新 READY" if restarted
               else "已保存；部分配置需重启机器人后生效",
    })


async def api_settings_backups(request: web.Request) -> web.Response:
    if not _auth(request):
        return _json({"error": "unauthorized"}, 401)
    return _json({"ok": True, "items": await asyncio.to_thread(_list_backups)})


async def api_settings_rollback(request: web.Request) -> web.Response:
    if not _auth(request):
        return _json({"error": "unauthorized"}, 401)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _json({"error": "请求体不是合法 JSON"}, 400)
    name = str((body or {}).get("file", ""))
    if not re.fullmatch(r"\.env\.\d{8}-\d{6}\.bak", name):
        return _json({"error": "备份文件名不合法"}, 400)
    src = _backup_dir() / name
    if not src.is_file():
        return _json({"error": "备份不存在"}, 404)
    try:
        await asyncio.to_thread(_backup_env)
        await asyncio.to_thread(shutil.copy2, src, _env_path())
        os.chmod(_env_path(), 0o600)
    except Exception as exc:  # noqa: BLE001
        return _json({"error": f"回滚失败：{exc}"}, 500)
    _audit("settings.rollback", request, "file=" + name)
    ok, msg = await _restart_bot()
    return _json({"ok": True, "restarted": ok, "message": msg, "file": name})


async def api_capabilities_get(request: web.Request) -> web.Response:
    if not _auth(request):
        return _json({"error": "unauthorized"}, 401)
    caps = await asyncio.to_thread(_read_caps)
    return _json({
        "ok": True, "defs": CAP_DEFS,
        "caps": {k: bool(caps.get(k, True)) for k in CAP_KEYS},
        "managed": _caps_path().exists(),
    })


async def api_capabilities_post(request: web.Request) -> web.Response:
    if not _auth(request):
        return _json({"error": "unauthorized"}, 401)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _json({"error": "请求体不是合法 JSON"}, 400)
    incoming = (body or {}).get("caps")
    if not isinstance(incoming, dict):
        return _json({"error": "缺少 caps 对象"}, 400)
    current = await asyncio.to_thread(_read_caps)
    changed = []
    for k, v in incoming.items():
        if k in CAP_KEYS:
            current[k] = bool(v)
            changed.append(k)
    try:
        await asyncio.to_thread(_write_caps, current)
    except Exception as exc:  # noqa: BLE001
        return _json({"error": f"写入失败：{exc}"}, 500)
    _audit("capabilities.save", request, "keys=" + ",".join(changed))
    return _json({"ok": True, "changed": changed, "caps": current,
                  "message": "已保存，机器人下一次处理消息时立即生效，无需重启"})


async def api_commands(request: web.Request) -> web.Response:
    if not _auth(request):
        return _json({"error": "unauthorized"}, 401)
    return _json({"ok": True, "items": COMMANDS, "cap_defs": CAP_DEFS})


async def api_platform(request: web.Request) -> web.Response:
    """一次性拉取开放平台侧机器人设置：资料 / 网关 / 频道 / 菜单 / 指令面板 / 审批策略。"""
    if not _auth(request):
        return _json({"error": "unauthorized"}, 401)
    kv = await asyncio.to_thread(_read_env)
    session: aiohttp.ClientSession = request.app["client"]
    try:
        token = await _platform_token(session, kv)
    except Exception as exc:  # noqa: BLE001
        return _json({"ok": False, "error": str(exc), "base": _platform_base(kv),
                      "items": {}})
    base = _platform_base(kv)
    calls = [
        ("me", "GET", "/users/@me"),
        ("gateway", "GET", "/gateway"),
        ("guilds", "GET", "/users/@me/guilds"),
        ("menu", "GET", "/v2/menu"),
        ("panels", "GET", "/v2/panels"),
        ("approval_strategy", "GET", "/v2/groups/join_approval_strategy"),
    ]

    async def one(item):
        name, method, path = item
        try:
            return name, await _platform_call(session, base, token, method, path)
        except Exception as exc:  # noqa: BLE001
            return name, {"ok": False, "error": str(exc)[:200], "data": {}}

    pairs = await asyncio.gather(*(one(x) for x in calls))
    items = {k: v for k, v in pairs}
    return _json({
        "ok": True, "base": base, "sandbox": base.endswith("sgroup.qq.com"),
        "items": items,
        "labels": {
            "me": "机器人资料", "gateway": "WebSocket 网关", "guilds": "已加入频道",
            "menu": "自定义菜单（单聊）", "panels": "指令面板",
            "approval_strategy": "入群自动审批策略",
        },
    })


async def api_platform_group(request: web.Request) -> web.Response:
    if not _auth(request):
        return _json({"error": "unauthorized"}, 401)
    openid = (request.query.get("openid") or "").strip()
    if not _safe_openid(openid):
        return _json({"error": "群 OpenID 不合法"}, 400)
    kv = await asyncio.to_thread(_read_env)
    session: aiohttp.ClientSession = request.app["client"]
    try:
        token = await _platform_token(session, kv)
    except Exception as exc:  # noqa: BLE001
        return _json({"ok": False, "error": str(exc)})
    base = _platform_base(kv)
    g = f"/v2/groups/{openid}"
    calls = [
        ("info", "GET", g + "/info"),
        ("bot_state", "GET", g + "/bot_state"),
        ("members", "GET", g + "/members"),
        ("join_requests", "GET", g + "/join_request_list"),
        ("blacklist", "GET", g + "/member_blacklist"),
        ("restrict", "GET", g + "/restrict_chat_setting"),
        ("strategy", "GET", "/v2/groups/join_approval_strategy"),
    ]

    async def one(item):
        name, method, path = item
        try:
            return name, await _platform_call(session, base, token, method, path)
        except Exception as exc:  # noqa: BLE001
            return name, {"ok": False, "error": str(exc)[:200], "data": {}}

    pairs = await asyncio.gather(*(one(x) for x in calls))
    return _json({
        "ok": True, "openid": openid, "base": base,
        "items": {k: v for k, v in pairs},
        "labels": {
            "info": "群基本信息", "bot_state": "机器人在群内状态",
            "members": "群成员列表", "join_requests": "入群申请",
            "blacklist": "群黑名单", "restrict": "群禁言状态",
            "strategy": "自动审批策略",
        },
    })


async def api_platform_join(request: web.Request) -> web.Response:
    if not _auth(request):
        return _json({"error": "unauthorized"}, 401)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _json({"error": "请求体不是合法 JSON"}, 400)
    body = body or {}
    group = str(body.get("group_openid", "")).strip()
    member = str(body.get("member_openid", "")).strip()
    op = str(body.get("op", "approve")).strip()
    if not _safe_openid(group) or not _safe_openid(member):
        return _json({"error": "群 / 成员 OpenID 不合法"}, 400)
    if op not in ("approve", "decline"):
        return _json({"error": "op 只能是 approve / decline"}, 400)
    payload = {"op": op}
    rid = str(body.get("join_request_id", "")).strip()
    if rid:
        if len(rid) > 256:
            return _json({"error": "申请 ID 过长"}, 400)
        payload["join_request_id"] = rid
    if op == "decline":
        reason = str(body.get("reject_reason", "")).strip()
        if reason:
            payload["reject_reason"] = reason[:200]
        payload["add_to_member_blacklist"] = bool(
            body.get("add_to_member_blacklist", False)
        )
    kv = await asyncio.to_thread(_read_env)
    session: aiohttp.ClientSession = request.app["client"]
    try:
        token = await _platform_token(session, kv)
        res = await _platform_call(
            session, _platform_base(kv), token, "POST",
            f"/v2/groups/{group}/approval_join_request/{member}", payload,
        )
    except Exception as exc:  # noqa: BLE001
        return _json({"ok": False, "error": str(exc)[:200]})
    _audit("platform.join", request,
           f"group={group[-6:]} member={member[-6:]} op={op}")
    return _json({**res, "op": op})


async def api_platform_menu(request: web.Request) -> web.Response:
    """保存单聊自定义菜单（PUT /v2/menu）。"""
    if not _auth(request):
        return _json({"error": "unauthorized"}, 401)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _json({"error": "请求体不是合法 JSON"}, 400)
    menu = (body or {}).get("menu")
    if not isinstance(menu, dict):
        return _json({"error": "menu 需为对象，形如 {\"items\":[...]}"}, 400)
    items = menu.get("items", [])
    if not isinstance(items, list) or len(items) > 10:
        return _json({"error": "items 最多 10 项"}, 400)
    kv = await asyncio.to_thread(_read_env)
    session: aiohttp.ClientSession = request.app["client"]
    try:
        token = await _platform_token(session, kv)
        res = await _platform_call(
            session, _platform_base(kv), token, "PUT", "/v2/menu", {"menu": menu},
        )
    except Exception as exc:  # noqa: BLE001
        return _json({"ok": False, "error": str(exc)[:200]})
    _audit("platform.menu", request, f"items={len(items)} ok={res.get('ok')}")
    return _json(res)


async def api_platform_call(request: web.Request) -> web.Response:
    """白名单内通用调用：把开放平台其余设置项也搬到手机。"""
    if not _auth(request):
        return _json({"error": "unauthorized"}, 401)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _json({"error": "请求体不是合法 JSON"}, 400)
    body = body or {}
    method = str(body.get("method", "GET")).upper()
    path = str(body.get("path", ""))
    payload = body.get("body")
    if method not in ("GET", "POST", "PUT", "PATCH", "DELETE"):
        return _json({"error": "不支持的 HTTP 方法"}, 400)
    if not _safe_path(path):
        return _json({"error": "路径不在开放平台接口白名单内"}, 400)
    if payload is not None and not isinstance(payload, (dict, list)):
        return _json({"error": "body 需为 JSON 对象或数组"}, 400)
    kv = await asyncio.to_thread(_read_env)
    session: aiohttp.ClientSession = request.app["client"]
    try:
        token = await _platform_token(session, kv)
        res = await _platform_call(
            session, _platform_base(kv), token, method, path, payload,
        )
    except Exception as exc:  # noqa: BLE001
        return _json({"ok": False, "error": str(exc)[:200]})
    _audit("platform.call", request, f"{method} {path[:80]}")
    return _json(res)


def register(app: web.Application) -> None:
    """注册全部路由。"""
    app.router.add_get("/api/settings", api_settings_get)
    app.router.add_post("/api/settings", api_settings_post)
    app.router.add_get("/api/settings/backups", api_settings_backups)
    app.router.add_post("/api/settings/rollback", api_settings_rollback)
    app.router.add_get("/api/capabilities", api_capabilities_get)
    app.router.add_post("/api/capabilities", api_capabilities_post)
    app.router.add_get("/api/commands", api_commands)
    app.router.add_get("/api/platform", api_platform)
    app.router.add_get("/api/platform/group", api_platform_group)
    app.router.add_post("/api/platform/join", api_platform_join)
    app.router.add_post("/api/platform/menu", api_platform_menu)
    app.router.add_post("/api/platform/call", api_platform_call)
