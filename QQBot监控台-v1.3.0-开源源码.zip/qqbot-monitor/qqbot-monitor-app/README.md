# 服务器监督 · 安卓客户端（APK）

一个**真正可安装的原生 Android 安装包**（不是网页快捷方式 / PWA）：独立图标、全屏运行、自动记住 Token，把手机端监控台装进 App。

---

## 一、立刻安装（手机操作）

1. 手机浏览器打开：**`http://你的服务器公网IP或域名/app/`**
2. 点 **「下载 APK（20.6 KB）」**
3. 若提示「禁止安装未知来源应用」→ 点「设置」→ 允许**当前浏览器**安装未知应用 → 返回
4. 点开下载的 APK → **安装** → 打开
5. 首次打开，点右上角 **⚙** 填入监控台访问 Token（在服务器执行 `cd /opt/monitor && bash deploy.sh token` 查看；也可从部署时的聊天记录获取）。App 会永久记住，之后不用再输

> APK 直链：`http://你的服务器公网IP或域名/app/QQBotMonitor-v1.1.0.apk`
> 在电脑上打开本页，可点「复制下载地址」再发到手机浏览器。

---

## 二、规格

| 项 | 值 |
|---|---|
| 包名 | `com.qqbot.monitor` |
| 版本 | `1.1.0`（versionCode `2`） |
| 文件大小 | 21,071 字节（20.6 KB） |
| 最低系统 | Android 7.0（API 24） |
| 目标系统 | Android 14（API 34） |
| 申请权限 | 仅 `INTERNET`、`ACCESS_NETWORK_STATE` |
| 签名 | 自签名证书，APK Signature Scheme **v2 + v3** |
| 文件 SHA-256 | `e0cf3d7348c4a77d311bc6380a3fb89e1228d4d45e26a63540cc8c758d7833ae` |
| 证书 SHA-256 | ``（自签名证书指纹，bash build.sh 后由 keytool 生成）`` |
| 第三方依赖 | **零**（纯 Android SDK，无 androidx、无 Gradle、无广告/统计 SDK） |

---

## 三、App 内功能

- **全屏 WebView** 加载监控台；`localStorage` 持久保存 Token，重启 App 不用重填
- **顶部进度条**，ActionBar 标题跟随网页
- 右上角 **⋮ 菜单**：刷新 / 服务器地址 / 下载·更新客户端 / 清除缓存
- **加载失败不白屏**：中文错误页，可「重新加载」或直接「修改服务器地址」
- **返回键**：先页内后退，连按两次退出
- 点 APK 下载链接自动交给系统浏览器 / 下载管理器
- 已显式放行 **HTTP 明文**（`usesCleartextTraffic` + `network_security_config`），内网/自签地址可用
- 网页版检测到自己在 App 内时，会自动隐藏「安装安卓客户端」横条，设置面板改为显示客户端版本

---

## 四、工程结构

```
qqbot-monitor-app/
├── AndroidManifest.xml          # 包名/权限/明文放行/启动 Activity
├── java/com/qqbot/monitor/
│   └── MainActivity.java        # 原生 WebView 壳（全部逻辑）
├── res/
│   ├── values/strings.xml       # 应用名
│   ├── xml/network_security_config.xml
│   └── mipmap-xxxhdpi/ic_launcher.png
├── build.sh                     # 一键构建（aapt2 → javac → d8 → zipalign → apksigner）
├── keystore/qqbot-monitor.jks   # 签名证书（重要，见第六节）
├── build/                       # 构建中间产物
└── dist/
    ├── QQBotMonitor-v1.1.0.apk  # ← 最终可安装 APK
    └── info.json                # 版本/大小/哈希
```

---

## 五、一键重新构建

不需要 Android Studio、不需要 Gradle。环境要求：

- JDK 11+（本机构建用 OpenJDK 20）
- Android SDK **build-tools 34**（提供 `aapt2` / `d8` / `zipalign` / `apksigner`）
- Android SDK **platforms/android-34**（提供 `android.jar`）

```bash
cd qqbot-monitor-app
ANDROID_SDK=/opt/android-sdk bash build.sh
```

构建链：`aapt2 compile` → `aapt2 link` → `javac --release 8` → `d8 --min-api 24`
→ 合并 `classes.dex` → `zipalign` → `keytool` 生成证书 → `apksigner` v1/v2 签名 → `apksigner verify`。

产物：`dist/QQBotMonitor-v1.1.0.apk` 与 `dist/info.json`。

> 如果 SDK 目录不同，用 `ANDROID_SDK=...` 指定；脚本会检查工具是否齐全。

---

## 六、签名证书（务必保留）

`keystore/qqbot-monitor.jks`

| 项 | 值 |
|---|---|
| 别名 | `qqbotmonitor` |
| 存储/密钥密码 | 首次构建随机生成并保存到 `keystore/.ks_pass`（已加入 `.gitignore`）；也可用环境变量 `KS_PASS` 指定 |
| 算法 / 有效期 | RSA 2048 / 10000 天 |
| DN | `CN=QQBot Monitor, OU=WorkBuddy, O=WorkBuddy, L=Beijing, ST=Beijing, C=CN` |

**`build.sh` 只在 keystore 不存在时生成证书**，密码持久化在 `keystore/.ks_pass`，所以重复构建签名完全一致，新 APK 可以直接**覆盖安装**。开源仓库不含 keystore 与密码文件，请自行生成并离线备份。
若丢失或删除了这份 keystore，重新生成的证书不同，已安装的用户必须**先卸载旧版**才能装新版。请把它和工程一起备份。

---

## 七、改成自己的服务器 / 更新版本

改服务器地址或发新版时，需要同步这几处：

1. `java/com/qqbot/monitor/MainActivity.java` → `DEFAULT_URL`（默认 `http://你的服务器公网IP或域名/`）
2. `server-monitor/download.html` → 版本号、大小、SHA-256、下载链接
3. `server-monitor/server.py` → `APK_NAME` 常量（若 APK 改名）
4. `server-monitor/index.html` → 下载横条文案（可选）

然后：

```bash
# 1) 重新构建
cd qqbot-monitor-app && bash build.sh

# 2) 上传到服务器
scp dist/QQBotMonitor-v1.1.0.apk root@<IP>:/opt/monitor/app/
scp ../server-monitor/download.html root@<IP>:/opt/monitor/download.html

# 3) 重启监控服务（下载页与 APK 由它提供）
ssh root@<IP> 'systemctl restart qqbot-monitor'
```

App 的 ⋮ 菜单「下载/更新客户端」会打开 `http://<当前服务器>/app/`，跟随你在 App 里设置的地址。

---

## 八、常见问题

| 现象 | 处理 |
|---|---|
| 「解析软件包时出现问题」 | 确认下载完整（21,071 字节，SHA-256 见上）；用系统「文件管理器」打开而不是第三方压缩软件 |
| 「禁止安装未知来源应用」 | 系统设置 → 应用与通知 → 特殊权限 → 安装未知应用 → 允许当前浏览器/文件管理器 |
| 提示「未知开发者 / 应用未经验证」 | 自签名 APK 的正常提示，确认来源是自己服务器后继续 |
| 打开后连接失败 | 确认手机能访问 `http://你的服务器公网IP或域名/`；在 ⋮ → 服务器地址检查；错误页可直接改地址 |
| 数据不刷新 / 显示旧页面 | ⋮ → 清除缓存，或在 ⚙ 里确认 Token |
| 换过 Token 后 401 | 在 App 的 ⚙ 里重新填新 Token |
| 装不上（系统版本太低） | 需要 Android 7.0 及以上 |
| 升级提示「签名不一致」 | 说明用了不同 keystore，先卸载旧版再装 |

---

## 九、安全说明

- 这是**自签名**安装包，未上架任何应用商店；请只在确认来源为自己服务器时安装，**不要转发 APK 或下载页链接**。
- 监控台使用 **HTTP 明文**，Token 在公网传输；App 内已放行明文，但也意味着不要在不信任的网络里长期使用，有条件建议后续套 HTTPS。
- App 只访问你配置的服务器地址，无其他网络请求、无第三方 SDK、无埋点、无后台常驻服务。
- 想换 Token：改 `/opt/monitor/config.json` 后 `bash deploy.sh restart`，并在 App 的 ⚙ 里同步更新。


## v1.1.0 更新

App 本身是 WebView 壳，无需重装即可看到新功能（服务器网页已更新）；本次仍提供 v1.1.0 安装包，
versionCode 升到 2、沿用同一签名证书，可直接覆盖安装。手机端「设置」现已包含 QQ 机器人的
全部配置项、事件订阅、能力开关、开放平台设置与指令清单，详见 `server-monitor/README.md` 附录。


## v1.2.0 更新
覆盖安装即可。手机端「设置」新增 **插件** 中心：识图（图片识别）、签到积分、娱乐、实用工具
四个插件可独立开关，并可在「配置 → 插件」分组填写视觉模型接口与默认天气城市。详见
`server-monitor/README.md`。
