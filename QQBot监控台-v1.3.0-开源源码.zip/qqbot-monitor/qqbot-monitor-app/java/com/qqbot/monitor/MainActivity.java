package com.qqbot.monitor;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

/**
 * 服务器监督 · 安卓客户端
 *
 * 一个零依赖（不使用 androidx）的 WebView 壳：
 *  - 全屏加载监控台，localStorage 持久保存访问 Token
 *  - 支持在 App 内修改服务器地址（SharedPreferences 持久化）
 *  - 加载失败给出可操作的错误页（重试 / 改地址）
 *  - 返回键：页内后退，双击退出
 *  - 下载链接交给系统浏览器 / 下载管理器处理
 */
public class MainActivity extends Activity {

    private static final String PREF = "monitor_pref";
    private static final String KEY_URL = "server_url";
    private static final String DEFAULT_URL = "http://你的服务器公网IP或域名/";
    private static final String BG = "#0a0f1e";
    private static final String VERSION = "1.3.0";

    private WebView web;
    private ProgressBar progress;
    private SharedPreferences pref;
    private String currentUrl = DEFAULT_URL;
    private long lastBack = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        pref = getSharedPreferences(PREF, MODE_PRIVATE);
        currentUrl = normalize(pref.getString(KEY_URL, DEFAULT_URL));

        getWindow().setStatusBarColor(Color.parseColor(BG));
        getWindow().setNavigationBarColor(Color.parseColor(BG));
        ActionBar bar = getActionBar();
        if (bar != null) {
            bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#111828")));
            bar.setTitle("服务器监督");
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor(BG));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor(BG));
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 4);
        plp.gravity = Gravity.TOP;
        root.addView(progress, plp);

        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // 关键：让页面能把 Token 存进 localStorage
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setUserAgentString(s.getUserAgentString() + " QQBotMonitor/" + VERSION);

        web.addJavascriptInterface(new Bridge(), "MonitorApp");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                return false;   // 所有导航都留在 WebView 内
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                progress.setVisibility(View.GONE);
                // 供网页识别「已在 App 内」，隐藏下载横条
                v.evaluateJavascript(
                        "try{if(window.MonitorApp){document.body.classList.add('in-app')}}catch(e){}",
                        null);
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) {
                    showError(String.valueOf(err.getErrorCode()) + " · "
                            + String.valueOf(err.getDescription()));
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (p < 100) {
                    progress.setVisibility(View.VISIBLE);
                    progress.setProgress(p);
                } else {
                    progress.setVisibility(View.GONE);
                }
            }

            @Override
            public void onReceivedTitle(WebView v, String title) {
                ActionBar b = getActionBar();
                if (b != null && title != null && !title.isEmpty()) {
                    b.setTitle(title);
                }
            }
        });

        // 点击 APK 下载链接 -> 交给系统浏览器/下载管理器
        web.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent,
                                        String contentDisposition,
                                        String mimetype, long contentLength) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    toast("请在浏览器中打开下载：" + url);
                }
            }
        });

        load(currentUrl);
    }

    private void load(String url) {
        currentUrl = url;
        progress.setVisibility(View.VISIBLE);
        web.loadUrl(url);
    }

    /** 主页地址对应的下载页（跟随用户自定义的服务器地址）。 */
    private String downloadPage() {
        try {
            Uri u = Uri.parse(currentUrl);
            String port = u.getPort() > 0 ? ":" + u.getPort() : "";
            return u.getScheme() + "://" + u.getHost() + port + "/app/";
        } catch (Exception e) {
            return DEFAULT_URL + "app/";
        }
    }

    private static String normalize(String u) {
        if (u == null) return DEFAULT_URL;
        u = u.trim();
        if (u.isEmpty()) return DEFAULT_URL;
        if (!u.startsWith("http://") && !u.startsWith("https://")) {
            u = "http://" + u;
        }
        if (!u.endsWith("/")) u += "/";
        return u;
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace("\"", "&quot;");
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    /** 主框架加载失败时的可操作错误页。 */
    private void showError(String reason) {
        String html =
            "<!DOCTYPE html><html lang='zh-CN'><head><meta charset='utf-8'>"
          + "<meta name='viewport' content='width=device-width,initial-scale=1'>"
          + "<title>连接失败</title><style>"
          + "*{box-sizing:border-box}body{margin:0;min-height:100vh;background:#0a0f1e;color:#e9eef9;"
          + "font-family:-apple-system,'PingFang SC','Microsoft YaHei',sans-serif;"
          + "display:flex;align-items:center;justify-content:center;padding:26px}"
          + ".b{max-width:420px;width:100%;background:#151d33;border:1px solid rgba(255,255,255,.08);"
          + "border-radius:18px;padding:26px 22px;text-align:center}"
          + ".ic{font-size:44px;margin-bottom:10px}h2{font-size:19px;margin:0 0 12px}"
          + "p{font-size:12.5px;line-height:1.8;color:#8b9bb9;margin:8px 0;word-break:break-all}"
          + "b{color:#e9eef9}button{width:100%;margin-top:10px;padding:12px;border-radius:11px;"
          + "border:1px solid rgba(56,226,201,.35);background:rgba(56,226,201,.14);color:#38e2c9;"
          + "font-size:14px;font-weight:700}button.sec{background:rgba(255,255,255,.05);"
          + "border-color:rgba(255,255,255,.1);color:#e9eef9}"
          + ".tip{margin-top:16px;font-size:11px;color:#5b6b8c}"
          + "</style></head><body><div class='b'>"
          + "<div class='ic'>⚠</div><h2>连接不到服务器</h2>"
          + "<p>" + escape(reason) + "</p>"
          + "<p>当前地址：<b>" + escape(currentUrl) + "</b></p>"
          + "<button onclick='location.reload()'>重新加载</button>"
          + "<button class='sec' onclick='MonitorApp.openSettings()'>修改服务器地址</button>"
          + "<p class='tip'>也可以在右上角 ⋮ 菜单里选择「服务器地址」。<br>"
          + "请确认服务器在线、手机已联网；HTTP 地址已在 App 内放行。</p>"
          + "</div></body></html>";
        web.loadDataWithBaseURL(currentUrl, html, "text/html", "utf-8", currentUrl);
    }

    private void showUrlDialog() {
        final EditText et = new EditText(this);
        et.setText(currentUrl);
        et.setSingleLine(true);
        et.setTextColor(Color.parseColor("#e9eef9"));
        et.setHintTextColor(Color.parseColor("#5b6b8c"));
        et.setHint("http://服务器IP 或域名");

        LinearLayout wrap = new LinearLayout(this);
        wrap.setPadding(48, 16, 48, 0);
        wrap.addView(et, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        new AlertDialog.Builder(this)
                .setTitle("服务器地址")
                .setMessage("修改后会自动重新加载；已保存的 Token 会保留。")
                .setView(wrap)
                .setPositiveButton("保存并加载", (d, w) -> {
                    String u = normalize(et.getText().toString());
                    if (u.isEmpty()) {
                        toast("地址不能为空");
                        return;
                    }
                    pref.edit().putString(KEY_URL, u).apply();
                    // 移除旧的 mon_base，让网页用 location.origin 自动跟上新地址
                    web.evaluateJavascript(
                            "try{localStorage.removeItem('mon_base')}catch(e){}",
                            new ValueCallback<String>() {
                                @Override
                                public void onReceiveValue(String value) {
                                    load(u);
                                }
                            });
                })
                .setNegativeButton("取消", null)
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem refresh = menu.add(0, 1, 0, "刷新");
        refresh.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        menu.add(0, 2, 1, "服务器地址");
        menu.add(0, 3, 2, "下载/更新客户端");
        menu.add(0, 4, 3, "清除缓存");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 1:
                load(currentUrl);
                return true;
            case 2:
                showUrlDialog();
                return true;
            case 3:
                load(downloadPage());
                return true;
            case 4:
                web.clearCache(true);
                web.reload();
                toast("缓存已清除");
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastBack < 2000L) {
            super.onBackPressed();
        } else {
            lastBack = now;
            toast("再按一次退出");
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }

    /** 暴露给网页的极简 JS 桥。 */
    private class Bridge {
        @JavascriptInterface
        public void retry() {
            runOnUiThread(() -> load(currentUrl));
        }

        @JavascriptInterface
        public void openSettings() {
            runOnUiThread(MainActivity.this::showUrlDialog);
        }

        @JavascriptInterface
        public String getServerUrl() {
            return currentUrl;
        }

        @JavascriptInterface
        public String getVersion() {
            return VERSION;
        }
    }
}
