#!/usr/bin/env bash
# 服务器监督 · 安卓客户端一键构建
# 不依赖 Gradle / Android Studio，仅需 Android build-tools + platform + JDK。
# 用法：ANDROID_SDK=/opt/android-sdk bash build.sh
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SDK="${ANDROID_SDK:-/opt/android-sdk}"
BT="$SDK/android-14"
AJ="$SDK/platforms/android-34/android.jar"
OUT="$HERE/build"
DIST="$HERE/dist"
KS="$HERE/keystore/qqbot-monitor.jks"
PASS_FILE="$HERE/keystore/.ks_pass"
ALIAS="qqbotmonitor"
VERSION="1.3.0"

# 签名密码：优先用环境变量 KS_PASS；否则首次构建随机生成并落盘，
# 之后每次读取同一份，保证重复构建签名一致。密码文件已在 .gitignore 中排除。
if [ -z "${KS_PASS:-}" ]; then
  if [ -f "$PASS_FILE" ]; then
    KS_PASS="$(cat "$PASS_FILE")"
  else
    KS_PASS="$(openssl rand -hex 16)"
    mkdir -p "$(dirname "$PASS_FILE")"
    printf '%s' "$KS_PASS" > "$PASS_FILE"
    chmod 600 "$PASS_FILE"
    echo "[i] 已生成随机签名密码 -> keystore/.ks_pass（请勿提交到仓库）"
  fi
fi
APK="$DIST/QQBotMonitor-v${VERSION}.apk"

for f in "$BT/aapt2" "$BT/d8" "$BT/zipalign" "$BT/apksigner" "$AJ"; do
  [ -e "$f" ] || { echo "缺少：$f（可设置 ANDROID_SDK）"; exit 1; }
done

echo "[1/8] 清理"
rm -rf "$OUT"; mkdir -p "$OUT/flat" "$OUT/classes" "$OUT/dex" "$DIST" "$(dirname "$KS")"

echo "[2/8] 编译资源 (aapt2 compile)"
"$BT/aapt2" compile --dir "$HERE/res" -o "$OUT/flat/"

echo "[3/8] 链接资源与 Manifest (aapt2 link)"
mapfile -t FLATS < <(find "$OUT/flat" -name '*.flat' | sort)
"$BT/aapt2" link -o "$OUT/base.apk" -I "$AJ" \
  --manifest "$HERE/AndroidManifest.xml" \
  --auto-add-overlay "${FLATS[@]}"

echo "[4/8] 编译 Java (javac --release 8)"
javac --release 8 -classpath "$AJ" -encoding UTF-8 \
  -d "$OUT/classes" "$HERE/java/com/qqbot/monitor/MainActivity.java"

echo "[5/8] class -> dex (d8)"
mapfile -t CLASSES < <(find "$OUT/classes" -name '*.class' | sort)
"$BT/d8" --lib "$AJ" --min-api 24 --output "$OUT/dex" "${CLASSES[@]}"

echo "[6/8] 合并 classes.dex + zipalign"
cp "$OUT/base.apk" "$OUT/unaligned.apk"
(cd "$OUT/dex" && zip -q -j "$OUT/unaligned.apk" classes.dex)
"$BT/zipalign" -f 4 "$OUT/unaligned.apk" "$OUT/aligned.apk"

echo "[7/8] 生成签名证书并签名 (v1 + v2)"
if [ ! -f "$KS" ]; then
  keytool -genkeypair -keystore "$KS" -alias "$ALIAS" \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass "$KS_PASS" -keypass "$KS_PASS" \
    -dname "CN=QQBot Monitor, OU=OSS, O=QQBot Monitor Contributors, L=Beijing, ST=Beijing, C=CN" \
    >/dev/null 2>&1
fi
"$BT/apksigner" sign \
  --ks "$KS" --ks-key-alias "$ALIAS" \
  --ks-pass "pass:$KS_PASS" --key-pass "pass:$KS_PASS" \
  --v1-signing-enabled true --v2-signing-enabled true \
  --out "$APK" "$OUT/aligned.apk"

echo "[8/8] 验证"
"$BT/apksigner" verify --verbose "$APK"
unzip -l "$APK" | grep -E "classes\.dex|resources\.arsc|AndroidManifest\.xml" || true
SIZE=$(stat -c%s "$APK")
SHA=$(sha256sum "$APK" | cut -d' ' -f1)
printf '{"version":"%s","size":%s,"sha256":"%s","package":"com.qqbot.monitor","apk":"QQBotMonitor-v%s.apk","min_sdk":24,"target_sdk":34}\n' \
  "$VERSION" "$SIZE" "$SHA" "$VERSION" > "$DIST/info.json"
echo "DONE -> $APK ($SIZE bytes)"
cat "$DIST/info.json"
