# 安全策略

## 支持版本

| 版本 | 状态 |
| --- | --- |
| v1.3.x | ✅ 支持 |
| ≤ v1.2.x | ⚠️ 建议升级 |

## 报告漏洞

请通过仓库的 **Security Advisory**（私密报告）提交；若不便使用，可开一个不含漏洞细节的 Issue 说明「已发现安全问题，请私信」。**不要在公开 Issue、截图或聊天里粘贴任何密钥、Token 或服务器地址。**

报告请包含：影响版本、复现步骤、潜在影响、建议修复方向。确认后会尽快发布修复版本。

## 本仓库不包含的内容

开源仓库**刻意不含**任何真实部署凭据，请不要把运行时的敏感文件提交回来：

| 类别 | 文件 / 值 |
| --- | --- |
| 机器人凭据 | `qq-bot/.env`（AppSecret、大模型 Key、TTS Key） |
| 控制台凭据 | `server-monitor/config.json`（访问 Token） |
| 运行时数据 | `data/`、`logs/`、`*.db` |
| 签名与产物 | `keystore/`、`*.jks`、`build/`、`dist/`、`*.apk` |
| 标识信息 | 真实公网 IP、QQ AppID、APK SHA-256、证书指纹 |

模板文件 `.env.example` / `config.json.example` 中所有敏感值均为空或公开示例值。

## 凭据处理机制

- 设置接口对 `SENSITIVE_KEYS` 中的字段只返回 `__SET__` 占位符和首尾掩码，永不回传明文；保存时空值表示「保持原密钥不变」。
- 访问 Token 只保存在浏览器 `localStorage` / 安卓 `SharedPreferences`，不上传服务器。
- 安卓签名密码首次构建时随机生成，保存在 `keystore/.ks_pass`（已加入 `.gitignore`），请离线备份并严格保管；丢失 keystore 会导致用户无法覆盖安装。
- 建议 `.env` 权限设为 `600`，服务器使用 SSH 密钥登录。

## 已知设计取舍（部署者需自行加固）

1. **默认 HTTP 明文**：访问 Token 在公网传输。生产环境请套一层 HTTPS（Nginx + Let's Encrypt、Cloudflare 或 SSH 隧道）。
2. **单 Token 鉴权**：控制台所有接口依赖同一个 `X-Token`；请定期用 `bash deploy.sh token --reset` 轮换，不要与其他服务复用同一字符串。
3. **自签名 APK**：安卓包使用自签名证书，安装时系统会有提示；请从自己的官方渠道分发并核对 SHA-256。
4. **第三方服务**：QQ 官方机器人 API、大模型服务、BreezeBlue TTS 均为独立第三方，需自行注册、遵守其条款并承担调用费用。

## 加固清单

- [ ] 云控制台重置 root 弱口令 / 改用 SSH 密钥
- [ ] 控制台启用 HTTPS
- [ ] 轮换监控台 Token，且不与 SSH 密码相同
- [ ] `.env` / `config.json` 权限 `600`，确认未被 git 跟踪
- [ ] 安全组只放行必要端口
- [ ] 定期备份 keystore 与 `.env`（离线、加密）
